
(function ($) {
	"use strict";
		
		
		// Main Menu responsive
		$('.main-menu nav').meanmenu({
			meanScreenWidth: "991",
			meanMenuContainer: '.mobile-menu',
			meanMenuOpen: '<i class="fa fa-bars"></i>',
			meanMenuClose: '<i class="fa fa-close"></i>'
		}); 
		
			
		//Dropdown Menu effect
		jQuery(document).ready(function($){	   
	   
	   // Menu sticky
	   $(window).on('scroll',function() {    
		   var scroll = $(window).scrollTop();
		   if (scroll < 20) {
			$("#sticky-header").removeClass("sticky-menu");
		   }else{
			$("#sticky-header").addClass("sticky-menu");
		   }
		});
				
		
		// Scroll To Top
		$("#toTop").scrollToTop(600);
	
	   
    });

	// Preloader
	var overlay = document.getElementById("overlay");
		window.addEventListener('load', function(){
		  overlay.style.display = 'none';
	});

	
	var swiper = new Swiper('.swiper-container', {
      pagination: {
        el: '.swiper-pagination',
        dynamicBullets: true,
      },
		loop:true,
		grabCursor: true,
    });
	
	
	
	 
}(jQuery));	




