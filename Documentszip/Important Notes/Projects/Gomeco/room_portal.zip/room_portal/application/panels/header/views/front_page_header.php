<!DOCTYPE html>
<html>
<!-- Copied from http://gomeco.com/home by Cyotek WebCopy 1.6.0.551, Monday, 8 October 2018, 10:09:54 AM -->
 <head>
	<meta charset="UTF-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
	<meta name="csrf-token" content="K3bn18nNVPBx4i5Pnw48h0ugxbDmAu20mRe0Scfo">
   
    <title>Meeting and Conference Room Scheduling Software | Gomeco</title>
		
	
	
	<link href="<?php echo $this->config->base_url();?>r/css/bootstrap.min.css" rel="stylesheet">
	<!-- Font Icon CSS -->
	<link href="<?php echo $this->config->base_url();?>r/css/font-awesome.min.css" rel="stylesheet">
	<!-- Meanmenu CSS -->
	<link href="<?php echo $this->config->base_url();?>r/css/meanmenu.css" rel="stylesheet">
	<!-- Main CSS -->
	<link href="<?php echo $this->config->base_url();?>r/css/style.css" rel="stylesheet">
	
	
	
	
	
	<!-- Css Ends-->
</head><body class="">
    <!-- Header Area -->
<header class="header-area" id="sticky-header">
	<div class="navbar navbar-default" role="navigation">
		<div class="container-fluid">
			<div class="row">
				<div class="col-md-3">
					<div class="logo">
						<a href="<?php echo $this->config->base_url();?>"><img src="<?php echo $this->config->base_url();?>r/images/front_logo.png" alt=""></a>
					</div>
				</div>
				<div class="col-md-9">
					<div class="main-menu text-right">
						<nav>
							<ul class="menu">
								<li><a href="<?php echo $this->config->base_url();?>demorequest">Request a Demo</a></li>
								<li><a href="<?php echo $this->config->base_url();?>pricing">Features & Pricing</a></li>
								<?php if(isset($this->session->user_id)){
									?>
									<li><a href="<?php echo $this->config->base_url();?>rooms/view">Dashboard</a></li>
									
									<li><a href="<?php echo $this->config->base_url();?>login_content/logout">Signout</a></li>
									<?php
								}else{ ?>
								<li><a href="<?php echo $this->config->base_url();?>signup">Signup</a></li>
								<li><a href="<?php echo $this->config->base_url();?>login"><?php print_r($this->session->user_id); ?>Login</a></li>
									<?php } ?>
														</ul></nav>
					</div>
					<div class="mobile-menu"></div>
				</div>
			</div>
		</div>
	</div>
</header><!-- /Header Area -->	
<div class="page-wrapper">