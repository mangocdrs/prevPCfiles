<?php
if (!defined('BASEPATH')) exit('No direct script access allowed');

class Header extends MX_Controller {

    public function index() {

        exit;
    }
	
	public function frontheader() {

       $this->load->view('front_page_header');
    }
	
	public function homepage(){
		$this -> load -> model('rooms_content/rooms_content_model');
		$service_account = $this->rooms_content_model->get_service_account_detail();
		
		if(!isset($service_account[0])){
			$this->session->set_userdata("organization_name","City of Abbotsford");
			$this->session->set_userdata("organization_type","name");
		}else{
			if($service_account[0]->type == "image"){
				$this->session->set_userdata("organization_image",base_url()."uploads/logo/".$service_account[0]->image);
			}	
			$this->session->set_userdata("organization_type",$service_account[0]->type);
			$this->session->set_userdata("organization_name",$service_account[0]->organization_name);
		}
		
		$this->load->view('home_page_header');
	}
	public function user(){
		$this->load->view('user_header.php');
	}
	
}
?>
