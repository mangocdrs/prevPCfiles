<?php

if (!defined('BASEPATH'))
	exit('No direct script access allowed');

class Admin_content extends MY_Controller {

	public function __construct(){
		parent::__construct();

	}

	public function index() {
		$data['error_message']=$this->session->flashdata('error_message');
		$data['success_message']=$this->session->flashdata('success_message');
		$data['user_add_data']=$this->session->flashdata('user_add_data');
        
		// print_r($data);
        $this -> load -> view('login_content',$data);
	}
	
	public function login_validate() {
		$this -> load -> helper('login_content/login_content');
		$this -> load -> model('login_content/login_content_model');
		
		
		$validate_login = login_validation();
		if ($validate_login) {
			//$validate = $this -> login_content_model -> validate();
			
			$validate = $this -> login_content_model -> validate();
			if ($validate) {
					
				$data=array(
				"username"=>$validate->email,
				"first_name"=>$validate->first_name,
				"last_name"=>$validate->last_name,
				"user_type"=>$validate->user_type,
				"location_unique_id" => "",
				"is_booked"=> 0,
				"booked_date" =>0,
				"booked_time"=>0 
				);
				$this->session->set_userdata($data);
				$this -> session -> set_flashdata('success_message', "Login Successfully");
				if($validate->user_type == "client"){
					header("Location:" . $this -> config -> base_url() . "rooms");
				}else{
					header("Location:" . $this -> config -> base_url() . "rooms/view");
				}
				exit;
			} else {
				$this -> session -> set_flashdata('user_add_data', array());	
				header("Location:" . $_SERVER['HTTP_REFERER']);
				exit;
			}
		} else {
			$this -> session -> set_flashdata('error_message', "Validation Failed");
			header("Location:" . $_SERVER['HTTP_REFERER']);
			exit;
		}

	}

	public function logout() {
			
		$this -> session -> userdata('user_type') == '';
		$this -> session -> unset_userdata('username');
		$this->session->unset_userdata('first_name');				
	    $this->session->unset_userdata('last_name');				
	    $this->session->unset_userdata('user_type');				
	    $this->session->unset_userdata('location_unique_id');				
	    $this->session->unset_userdata('is_booked');
		$this->session->unset_userdata('booked_date');				
		$this->session->unset_userdata('booked_time');				
		
		unset($this -> session -> userdata);
		$this -> session -> sess_destroy();
		header("Location:" . $this -> config -> base_url() . "login");
		exit ;
	}

}
