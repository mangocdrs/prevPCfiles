<?php
if (!defined('BASEPATH')) exit('No direct script access allowed');

class Rooms_content extends MY_Controller {
	

	public function __construct(){
		parent::__construct();
	}
	
	public function select_room(){
			
		$access=$this->check_client();
		$this->panels_check_permission($access);
	
		$this -> load -> model('rooms_content/rooms_content_model');
		$rooms = $this->rooms_content_model->get_user_rooms();
		$data['error_message']=$this->session->flashdata('error_message');
		$data['success_message']=$this->session->flashdata('success_message');
		$data['user_add_data']=$this->session->flashdata('user_add_data');
    
		$data['rooms']=$rooms;
		
		$this->load->view("select_room",$data);
	}
	
	
	public function submit_selected_room(){
		$access=$this->check_client();
		$this->panels_check_permission($access);
		
		$room_name=$this->input->post('select_room');
		$this -> load -> model('rooms_content/rooms_content_model');
		$rooms = $this->rooms_content_model->get_user_rooms($room_name);
		$service_account = $this->rooms_content_model->get_service_account_detail();
		if(!isset($service_account[0])){
			$this -> session -> set_flashdata('error_message', "Please Updated Service Account Detail");
			header("Location:" . $this -> config -> base_url() . "rooms");
			exit;
		}
		
		$username_room = $rooms[0]->email;
		$password = base64_decode($service_account[0]->password);
		$email = $service_account[0]->email;
		
		$this->session->set_userdata("room_display_name",$rooms[0]->name);
		$this->session->set_userdata("room_location",$room_name);
		$this->session->set_userdata("room_name",$username_room);
		$this->session->set_userdata("username_room",$username_room);
		$this->session->set_userdata("set_booked_difference",$service_account[0]->meeting_cancel_time);
		
		$this->session->set_userdata("service_account_email",$email);
		$this->session->set_userdata("service_account_password",$password);
		
		
		header("Location:" . $this -> config -> base_url() . "rooms/view");
	}
	
	
	public function roomsschedule($call = NULL){
		
			
		$access=$this->check_client();
		$this->panels_check_permission($access);
		
		
		
		$username = $this->session->userdata("service_account_email");
		$password = $this->session->userdata("service_account_password");
		$username_room = $this->session->userdata("username_room");
		// $set_booked_difference = $this->session->userdata("set_booked_difference");
		$this -> load -> model('rooms_content/rooms_content_model');
		$service_account = $this->rooms_content_model->get_service_account_detail();
		$set_booked_difference = $service_account[0]->meeting_cancel_time;
		if($set_booked_difference == 0){
			$set_booked_difference = 1440;
		}
		
		$meeting_converted_start_time = date("Y-m-d\TH:i:s", strtotime(UTC_TIME_DIFF));
		$this->load->library("EwsCustom");
		$resp = $this->ewscustom->get_event($username_room,$username,$password,$meeting_converted_start_time,date("Y-m-d", strtotime(' +1 day'))."T23:59:60Z");
		
		
		$data = array(
			"room_status"=> "Available",
			"meeting_name"=> ""
		);
		
		$index = 0;
		$available_minutes=0;
		$next_min_time="";
		$session_room_name=$this->session->userdata("room_name");
		$selected_room=$session_room_name;                       
		
		
		if($resp){
			foreach ($resp as $key => $value) {
				
				$room_name= strtolower($value->organizer->email);
				// exit;
				$start = date('Y-m-d H:i:s', $value->start);
				
				$start = date('Y-m-d H:i:s', strtotime($start." ".UTC_TIME_DIFF_add));
				
				$start_date_ews = strtotime($start);
				$start_time = explode(" ", $start);
				$start = $start_time[0];
				$start_time = $start_time[1];
				
				
				$end = date('Y-m-d H:i:s', $value->end);
				$end = date('Y-m-d H:i:s', strtotime($end." ".UTC_TIME_DIFF_add));
				$end_date_ews = strtotime($end);
				$end_time = explode(" ", $end);
				$end = $end_time[1];
				$end_time = $end_time[1];
				
				$current_date=date("Y-m-d");
				$current_time=date("H:i:s");
				
				$current_datetime = strtotime(date("Y-m-d H:i:s"));
			
				$c_start_time =	date('g:ia', strtotime($start_time));
				$c_end_time =	date('g:ia', strtotime($end_time));
			
				// if($room_name==$session_room_name && $start_date_ews<=$current_datetime && $end_date_ews>$current_datetime){
				if($start_date_ews<=$current_datetime && $end_date_ews>$current_datetime){
					// echo "<pre>";
					// print_r($value);exit;
					$is_booked=$this->session->userdata("is_booked");
					$session_meeting_id=$this->session->userdata("session_meeting_id");
					
					$booked_date=$this->session->userdata("booked_date");
					$booked_time=$this->session->userdata("booked_time");
					
					if($is_booked==0 || ($is_booked==1 && $session_meeting_id!= $value->id)){
							
						if($is_booked==1 && $session_meeting_id!= $value->id){
							$this->session->set_userdata('is_booked',0);
							$this->session->set_userdata('session_meeting_id',$value->id);
						}	
							
						$current_strottime = strtotime($current_time);
						$start_strottime = strtotime($start_time);
						$booked_difference=round(abs($current_strottime - $start_strottime) / 60,0);
						if($booked_difference<$set_booked_difference){
							$data['room_status']="booked";
							$data['meeting_name']=$value->subject;
							$data['start_time']=$c_start_time;
							$data['end_time']=$c_end_time;
							$data['meeting_id']=$value->id;
							$data['changekey']=$value->changekey;
							$data['start_date_ews']=$start_date_ews;
							$data['end_date_ews']=$end_date_ews;
							break;
						}
						else{
						
							$meeting_id=$value->id;
							$changekey=$value->changekey;
						
							// $this->ewscustom->cancel_event($username,$password,$meeting_id,$changekey);
							
							$meeting_converted_start_time = date("Y-m-d\TH:i:s", strtotime(UTC_TIME_DIFF));
							$update_list = array();
							$update_list['subject'] = "Not Checked In";
							$update_list['end'] = $meeting_converted_start_time;
							$this->ewscustom->update_event($username_room,$username,$password,$meeting_id,$changekey,$update_list);
		
							
							$this->session->set_userdata('is_booked',0);
							header("location: ".$this->config->base_url()."rooms/view");
							exit;
						}
					}
					else{
						$data['room_status']="in_use";
						$data['meeting_name']=$value->subject;
						$data['start_time']=$c_start_time;
						$data['end_time']=$c_end_time;
						$data['meeting_id']=$value->id;
						$data['changekey']=$value->changekey;
						$data['start_date_ews']=$start_date_ews;
						$data['end_date_ews']=$end_date_ews;
						break;
					}
				
				}else if($current_date==$start){
					if($current_datetime < $start_date_ews && ($next_min_time > $start_date_ews || $next_min_time=="") ){
						$next_min_time=$start_date_ews;
						$selected_room=$room_name;
						
						$adv_meeting_id = $value->id;
						$adv_changekey = $value->changekey;
						$adv_subject = $value->subject;
						$adv_start_time = $c_start_time;
						$adv_end_time = $c_end_time;
						$adv_start_date_ews = $start_date_ews;
						$adv_end_date_ews = $end_date_ews;
			
						
					}
				}
			}
		}
		// if($next_min_time!="" && $selected_room==$session_room_name){
		if($next_min_time!=""){
			
			$next_min_time_con = date('Y-m-d H:i:s', $next_min_time);
			$next_min_time_con = explode(" ", $next_min_time_con);
			$next_min_time_con = $next_min_time_con[1];
			
			$available_minutes=round(abs(strtotime($current_time) - strtotime($next_min_time_con)) / 60,0);
			$available_minute = 0;
			if($available_minutes>120){
				$hours=round(abs($available_minutes) / 60,2);
				if($this->containsDecimal($hours)==true){
					$hour_int=explode(".", $hours);
					$available_minutes=$hour_int[0]."+ hours";
					$available_minute = $hour_int[0]*60;
				}else{
					
					$available_minutes=$hours. "hours";
					$available_minute = $hours*60;
			
				}
				
			}else{
				$available_minute = $available_minutes;
				$available_minutes .=" minutes";
			}
			if($available_minute <= 10 && $available_minute >= 0){
					
				$data['room_status']="booked";
				$data['meeting_name']=$adv_subject;
				$data['start_time']=$adv_start_time;
				$data['end_time']=$adv_end_time;
				$data['meeting_id']=$adv_meeting_id;
				$data['changekey']=$adv_changekey;
				$data['start_date_ews']=$adv_start_date_ews;
				$data['end_date_ews']=$adv_end_date_ews;
			}
		}
		
		$data['available_minutes']=$available_minutes;
		$data['error_message']=$this->session->flashdata('error_message');
		$data['success_message']=$this->session->flashdata('success_message');
		
		
		if($call == "ajax"){
			echo json_encode($data);
			// exit;	
		}else{
			$this->load->view('roomsschedule',$data);
		}
		
		
	}
	
	
	public function sync_room_screen(){
		$this->roomsschedule("ajax");
	}
	

	
		public function submit_current_schedule($call = NULL){
			$data=array();
			$minutes="+".$this->input->post("schedule_time")."  minutes";
			$session_room_name=$this->session->userdata("room_name");
			
			$meeting_converted_diff_start_time = date("H:i:s");
			$meeting_converted_diff_end_time = date("H:i:s", strtotime($minutes));
			
			$username = $this->session->userdata("service_account_email");
			$password = $this->session->userdata("service_account_password");
			$username_room = $this->session->userdata("username_room");
		
			$meeting_converted_start_time = date("Y-m-d\TH:i:s", strtotime(UTC_TIME_DIFF));
		
			
			$this->load->library("EwsCustom");
			$resp = $this->ewscustom->get_event($username_room,$username,$password,$meeting_converted_start_time,date("Y-m-d", strtotime(' +1 day'))."T23:59:60Z");
		
			$index = 0;
			$available_minutes=0;
			$count=0;
		
			foreach ($resp as $key => $value) {
				$id=$value->id;
				$room_name=strtolower($value->organizer->email);
				$start = date('Y-m-d H:i:s', $value->start);
				$start = date('Y-m-d H:i:s', strtotime($start." ".UTC_TIME_DIFF_add));
				$start_time = explode(" ", $start);
				$start = $start_time[0];
				$start_time = $start_time[1];
						
						
				// if($room_name==$session_room_name && $start_time >=  $meeting_converted_diff_start_time && $start_time <= $meeting_converted_diff_end_time ){
				if($start_time >=  $meeting_converted_diff_start_time && $start_time <= $meeting_converted_diff_end_time ){
				
					$count=1;
					break;
				}
			}
			
			
			if($count==0){
				$meeting_converted_start_time = date("Y-m-d\TH:i:s", strtotime(UTC_TIME_DIFF));
				$meeting_converted_end_time = date("Y-m-d\TH:i:s", strtotime(UTC_TIME_DIFF." ".$minutes));
			
				$this->load->library("EwsCustom");
				$session_meeting_id = $this->ewscustom->create_event($username_room,$username,$password,"Impromptu Meeting",$meeting_converted_start_time,$meeting_converted_end_time,$this->session->userdata("room_location"));
				$this->session->set_userdata('is_booked',1);
				$this->session->set_userdata('session_meeting_id',$session_meeting_id);
			
			}else{
				
				$this->session->set_flashdata('error_message','Meeting Conflict.');
			}
		
			
			if($call == "ajax"){
				echo json_encode("Scheduled");
				// exit;	
			}else{
				header("location: ".$this->config->base_url()."rooms/view");
				exit;
			}
			
		}
	
	public function submit_ajax_current_schedule(){
		$this->submit_current_schedule("ajax");
	}
	
	
	
	
	public function submit_cancel_schedule(){
			
		$meeting_id=$this->input->post("meeting_id");
		$changekey=$this->input->post("changekey");
		
		$username = $this->session->userdata("service_account_email");
		$password = $this->session->userdata("service_account_password");
		$username_room = $this->session->userdata("username_room");
		
		$this->load->library("EwsCustom");
		// $this->ewscustom->cancel_event($username,$password,$meeting_id,$changekey);
		// $this->ewscustom->update_event($username,$password,$meeting_id,$changekey);
		
		// $minutes="-1 minutes";
		$meeting_converted_start_time = date("Y-m-d\TH:i:s", strtotime(UTC_TIME_DIFF." ".$minutes));
		
		
		$update_list = array();
		$update_list['end'] = $meeting_converted_start_time;
		
		// echo $meeting_converted_start_time;
		// echo date("Y-m-d\TH:i:s", strtotime(UTC_TIME_DIFF));
		// exit;
		$this->ewscustom->update_event($username_room,$username,$password,$meeting_id,$changekey,$update_list);
		
		
		
		$this->session->set_userdata('is_booked',0);
		
		header("location: ".$this->config->base_url()."rooms/view");
		exit;
		
	}
	

	
	
	public function containsDecimal( $value ) {
    	if ( strpos( $value, "." ) !== false ) {
        	return true;
    	}
    	return false;
	}
	
	public function get_today_schedule(){
		$this->load->library("EwsCustom");
		$username = $this->session->userdata("service_account_email");
		$password = $this->session->userdata("service_account_password");
		$username_room = $this->session->userdata("username_room");
		
		$resp = $this->ewscustom->get_event($username_room,$username,$password,date("Y-m-d")."00:00:00",date("Y-m-d")."23:59:59");
	
		$data = array();
		$index = 0;
		if($resp){
			// echo "<pre>";
			// print_r($resp);
			// exit;
			foreach ($resp as $key => $value) {
				$room_name=strtolower($value->organizer->email);
				$room_user_name=strtolower($value->organizer->name);
				$session_room_name=$this->session->userdata("room_name");
			
			// if($room_name==$session_room_name){
				$old_date_timestamp = $value->start;
				
				$organizer=strtolower($value->organizer->email);  
				
				$start = date('Y-m-d H:i:s', $value->start);
				$start = date('Y-m-d H:i:s', strtotime($start." ".UTC_TIME_DIFF_add));
				$start_date_ews = strtotime($start);
				$start_time = explode(" ", $start);
				$start = $start_time[0];
				$start_time = $start_time[1];
				
				
				$end = date('Y-m-d H:i:s', $value->end);
				$end = date('Y-m-d H:i:s', strtotime($end." ".UTC_TIME_DIFF_add));
				$end_date_ews = strtotime($end);
				$end_time = explode(" ", $end);
				$end = $end_time[1];
				$end_time = $end_time[1];
				
				 
				 
				 
				$data['today'][$index] = array(
					      "name"=> $value->subject,
					      "startdate"=> $start,
					      "enddate"=> $end,
					      "starttime"=> date('g:ia', strtotime($start_time)),
					      "endtime"=>date('g:ia', strtotime($end_time)),
					      "organizer"=> ucwords($room_user_name)
					   );
			// }
			
				$index++;
		    }	
	    }
		echo json_encode($data);
		// exit;
	}
	
	
	public function extend_current_schedule($call = NULL){
		$session_room_name=$this->session->userdata("room_name");
		
		
		$meeting_id=$this->input->post("meeting_id");
		$changekey=$this->input->post("changekey");
		
		$start_date_ews=$this->input->post("start_date_ews");
		$start_date_ews = date('Y-m-d H:i:s', $start_date_ews);
		
		$end_date_ews=$this->input->post("end_date_ews");
		$end_date_ews = date('Y-m-d H:i:s', $end_date_ews);
		
		
		$new_start_date_time_stamp = strtotime($end_date_ews);
		$new_start_date = date('Y-m-d', $new_start_date_time_stamp);
		$new_start_time = date('H:i:s', $new_start_date_time_stamp);
		
		$current_date=date("Y-m-d");
		$current_time=date("H:i:s");
		$current_datetime = strtotime(date("Y-m-d H:i:s"));
				
		
		$minutes="+".$this->input->post("schedule_time")."  minutes";
		
		$endTime = strtotime($minutes, strtotime($new_start_time));
		$new_end_time= date('H:i:s', $endTime);
		
		$username = $this->session->userdata("service_account_email");
		$password = $this->session->userdata("service_account_password");
		$username_room = $this->session->userdata("username_room");
		
		$meeting_converted_diff_end_time = date("Y-m-d\TH:i:s", strtotime($minutes));
			
		$this->load->library("EwsCustom");
		$resp = $this->ewscustom->get_event($username_room,$username,$password,$meeting_converted_diff_end_time,date("Y-m-d", strtotime(' +1 day'))."T23:59:60Z");
		
		$index = 0;
		$available_minutes=0;
		$next_min_time="";
		$count=0;
		
		foreach ($resp as $key => $value) {
			$id=$value->id;
			
			if($meeting_id!=$id){
					
				$room_name=strtolower($value->organizer->email);
				$session_room_name=$this->session->userdata("room_name");
				
				$start = date('Y-m-d H:i:s', $value->start);
				$start = date('Y-m-d H:i:s', strtotime($start." ".UTC_TIME_DIFF_add));
				$start_time = explode(" ", $start);
				$start = $start_time[0];
				$start_time = $start_time[1];
				
				// if($room_name==$session_room_name && $start_time >= $new_start_time && $start_time <= $new_end_time ){
				if($start_time >= $new_start_time && $start_time <= $new_end_time ){
				
					$count=1;
					break;
				}
			}
		}
		
		if($count==0){
			$start_date_ews = str_replace(" ", "T", trim($start_date_ews));
			
			$meeting_converted_start_time = date("Y-m-d\TH:i:s", strtotime($start_date_ews." ".UTC_TIME_DIFF));
			$meeting_converted_end_time = date("Y-m-d\TH:i:s", strtotime($new_start_date."T".$new_end_time." ".UTC_TIME_DIFF));
			
			$update_list = array();
			$update_list['end'] = $meeting_converted_end_time;
		
			$this->ewscustom->update_event($username_room,$username,$password,$meeting_id,$changekey,$update_list);
		
			
			// $this->ewscustom->cancel_event($username,$password,$meeting_id,$changekey);
			// $this->ewscustom->create_event($username,$password,"Impromptu Meeting",$meeting_converted_start_time,$meeting_converted_end_time,$this->session->userdata("room_name"));
		}
		else{
			
			$this->session->set_flashdata('error_message','Meeting Conflict.');
		}
		
		if($call == "ajax"){
			echo json_encode("done");
			// exit;
		}else{
			header("location: ".$this->config->base_url()."rooms/view");exit;
		}
	}

	public function submit_ajax_extend_schedule(){
		
		$this->extend_current_schedule("ajax");
	}


	
	public function get_rooms_list(){
			
			
		$meeting_converted_diff_start_time = date("H:i:s");
		$current_date=date("Y-m-d");
		$session_room_name=$this->session->userdata("room_name");
		
		$username = $this->session->userdata("service_account_email");
		$password = $this->session->userdata("service_account_password");
		$username_room = $this->session->userdata("username_room");
		
		$this->load->library("EwsCustom");
		
		$index = 0;
		$available_minutes=0;
		$count=0;
		
		$this -> load -> model('rooms_content/rooms_content_model');
		$rooms = $this->rooms_content_model->get_user_rooms();
		foreach ($rooms as $key_room => $value_room) {
			$status="Available";
			$username_room = $value_room->email;
			// $password = base64_decode($value_room->password);
			$meeting_converted_diff_end_time =  date("Y-m-d\TH:i:s", strtotime(UTC_TIME_DIFF));
			// echo $meeting_converted_diff_end_time;
			
			$resp = $this->ewscustom->get_event($username_room,$username,$password,$meeting_converted_diff_end_time,date("Y-m-d", strtotime(' +1 day'))."T23:59:60Z");
			// echo "dfdf";
			// echo "<pre>";
			// print_r($resp);
			// exit;
			foreach ($resp as $key => $value) {
				$id=$value->id;
				$room_name=strtolower($value->organizer->email);
				$start = date('Y-m-d H:i:s', $value->start);
				$start = date('Y-m-d H:i:s', strtotime($start." ".UTC_TIME_DIFF_add));
				$start_time = explode(" ", $start);
				$start = $start_time[0];
				$start_time = $start_time[1];
							
				$end = date('Y-m-d H:i:s', $value->end);
				$end = date('Y-m-d H:i:s', strtotime($end." ".UTC_TIME_DIFF_add));
				$end_date_ews = strtotime($end);
				$end_time = explode(" ", $end);
				$end = $end_time[1];
				$end_time = $end_time[1];			
							
					// if($room_name == $value_room->email && $start_time <=  $meeting_converted_diff_start_time && $end_time >= $meeting_converted_diff_start_time && $start == $current_date){
					if($start_time <=  $meeting_converted_diff_start_time && $end_time >= $meeting_converted_diff_start_time && $start == $current_date){
						$status="In Use";
						break;
					}else{
						$status="Available";
					}
				}// inner foreach
				
				$data[$index] = array(
			    	"name"=> $value_room->name,
			      	"status"=> $status,
			      	"current"=> ""
			   );
			   if($index==0){
				   	$data[$index]['capacity']=$value_room->capacity;
					$data[$index]['location']=$value_room->unique_name;
			   }
			   else{
				   	$data[$index]['capacity']=$value_room->capacity;
					$data[$index]['location']=$value_room->unique_name;
			   }
			   if($session_room_name == $value_room->email){
			   		$data[$index]['current']="Current";
			   }
			   $index +=1;
		}//outer foreach
		// echo "<pre>";
		// print_r($data);
		// exit;
		echo json_encode($data);exit;
			
	}
	
	public function submit_report_bug(){
		
		$this -> load -> model('rooms_content/rooms_content_model');
		
		$room_name = $this->session->userdata("room_display_name");
		$room_location = $this->session->userdata("room_location");
		
		$issue=$this->input->post('selectgroupforreport');
		$subject = "Room Issue";
		// $email = "hashar.mangocoders@gmail.com";
		
		
		$rooms = $this->rooms_content_model->get_user_rooms($room_location);
		
		
		$message = "<b>Room Name:</b> '$room_name'<br>
					<b>Room Location:</b> '$room_location'<br>
					<b>Issue:</b> '$issue'";
		
		$sender_email = $rooms[0]->email;;
		$email = $rooms[0]->support_email;
		
		$from = $this->session->userdata('organization_name');
		$this -> load -> library('Cphpmailer');
		$oMail = new Cphpmailer();

		$oMail -> Subject = stripslashes($subject);
		$oMail -> MsgHTML(mb_convert_encoding($message, "HTML-ENTITIES", "UTF-8"));
		$oMail -> CharSet = "utf-8";
		$oMail -> AddAddress($email, "");
		$oMail -> SetFrom($sender_email, $from);
		$oMail -> AddReplyTo($sender_email, "");
		$oMail -> Mailer = 'sendmail';
		$email_status = $oMail -> Send();
		$this->session->set_flashdata('success_message','Thank you for reporting the issue, well look into it ASAP!');
		header("location: ".$this->config->base_url()."rooms/view");
		exit;
	}


	public function start_booked_meeting(){
		$meeting_id=$this->input->post("meeting_id");
		$changekey=$this->input->post("changekey");
		
		$username = $this->session->userdata("service_account_email");
		$password = $this->session->userdata("service_account_password");
		$username_room = $this->session->userdata("username_room");
		
		$this->load->library("EwsCustom");
		$meeting_converted_start_time = date("Y-m-d\TH:i:s", strtotime(UTC_TIME_DIFF));
		
		$update_list = array();
		$update_list['start'] = $meeting_converted_start_time;
		
		$this->ewscustom->update_event($username_room,$username,$password,$meeting_id,$changekey,$update_list);
		
		$this->session->set_userdata('is_booked',1);
		header("location: ".$this->config->base_url()."rooms/view");exit;
	}
	
	
	/////////////////////////// superadmin ///////////////////////////////////
	
	public function user_add_rooms_view(){
		$access=$this->check_user();
		$this->panels_check_permission($access);
		$success_message=$this->session->flashdata('success_message');
		$error_message=$this->session->flashdata('error_message');
		$user_add_data=$this->session->flashdata('user_add_data');
    	$data['error_message']= $error_message;
		$data['success_message']= $success_message;
		$data['user_add_data']=$user_add_data;
		
		$this->load->view('user_create_rooms_content',$data);
	}
	


	public function add_new_room(){
		$access=$this->check_user();
		$this->panels_check_permission($access);
		
		$this -> load -> helper('rooms_content/rooms_content');
		$this->load->model('rooms_content/rooms_content_model');
		
		$validation=roomvalidation();
			if($validation){
					
				$result=$this->rooms_content_model->add_room();
				if($result){
					$this->session->set_flashdata('success_message', "Room Added Successfully");
					header("Location:" . $this -> config -> base_url() . "rooms/view");
				}
				else{
					header("Location:" . $_SERVER['HTTP_REFERER']);
				}
			}
			else{
				$this->session->set_flashdata('error_message','Validation Error');
				header("Location:" . $_SERVER['HTTP_REFERER']);
			}
			exit;
	}


	public function user_view_all_rooms(){
		
		$access=$this->check_user();
		$this->panels_check_permission($access);
		
		$success_message=$this->session->flashdata('success_message');
		$error_message=$this->session->flashdata('error_message');
		$user_add_data=$this->session->flashdata('user_add_data');
    	$data['error_message']= $error_message;
		$data['success_message']= $success_message;
		$data['user_add_data']=$user_add_data;	
		
		
		$this -> load -> model('rooms_content/rooms_content_model');
		$this->load->library("pagination");
		$offset = ($this->uri->segment(3) != '' ? $this -> uri -> segment(3): 1);
		if($this->input->post('per_page')){
			$per_page = $this->input->post('per_page');
		}else{
			$per_page = 10;
		}
		$totalrooms=$this->rooms_content_model->get_all_rooms_count();
		$url= $this -> config -> base_url() ."rooms/view"; 
    
		$pagination_detail = $this->pagination->pagination($totalrooms, $per_page, $offset, $url);
		$data['paginglinks'] = $pagination_detail['paginationLinks'];
		$data['pagermessage'] = $pagination_detail ['paginationMessage'];
		
		$result=$this->rooms_content_model->get_all_rooms_detail($offset,$per_page);
		$data['total']=$totalrooms;
		
		$data['rooms']=$result;
		
		
		if(ROOMS_LIMIT == 1){
			$data['room_limit'] = ROOMS_LIMIT." Room";
		}else{
			$data['room_limit'] = ROOMS_LIMIT." Rooms";
		}
		
		
		if($totalrooms <= 1){
			$data['total_rooms'] = $totalrooms." Room";
		}else{
			$data['total_rooms'] = $totalrooms." Rooms";
		}
		
		
		$remaining_rooms = ROOMS_LIMIT - $totalrooms;
		if($remaining_rooms <= 1){
			$data['remaining_rooms'] = $remaining_rooms." Room";
		}else{
			$data['remaining_rooms'] = $remaining_rooms." Rooms";
		}
		
		
		$this->load->view('user_view_rooms_content',$data);
	}

	
	public function user_edit_rooms(){
		
		$access=$this->check_user();
		$this->panels_check_permission($access);
		$this -> load -> model('rooms_content/rooms_content_model');
		
		$success_message=$this->session->flashdata('success_message');
		$error_message=$this->session->flashdata('error_message');
		$user_add_data=$this->session->flashdata('user_add_data');
    	$data['error_message']= $error_message;
		$data['success_message']= $success_message;
		$data['user_add_data']=$user_add_data;
		$roomid=$this->input->get('roomid');
		
		$result=$this->rooms_content_model->getroombyid($roomid);
		if(count($result)==0){
			header("Location:" . $this -> config -> base_url() . "rooms/view");
			exit;
		}
		$data['result']=$result;
		$this->load->view('user_edit_rooms_content',$data);
	}
	

		
	
	public function user_update_room(){
			
		$this -> load -> helper('rooms_content/rooms_content');
		$this->load->model('rooms_content/rooms_content_model');
		
		$validation=roomeditvalidation();
		if($validation){
			
			$result=$this->rooms_content_model->update_room($user_id);
			
			if($result!=0){
				$this->session->set_flashdata('success_message','Room Update Successfully');
			
				header("Location:" . $this -> config -> base_url() . "rooms/view");
			}else{
				$this->session->set_flashdata('error_message','Room Not Updated');
				
				header("Location:" . $_SERVER['HTTP_REFERER']);
			}
		}
		else{
			$this->session->set_flashdata('error_message','Form Validation Error');
			header("Location:" . $_SERVER['HTTP_REFERER']);
		}
	}


	public function user_detail_rooms(){
		
		$access=$this->check_user();
		$this->panels_check_permission($access);
		$this -> load -> model('rooms_content/rooms_content_model');
		
		$success_message=$this->session->flashdata('success_message');
		$error_message=$this->session->flashdata('error_message');
		$user_add_data=$this->session->flashdata('user_add_data');
    	$data['error_message']= $error_message;
		$data['success_message']= $success_message;
		$data['user_add_data']=$user_add_data;
		$roomid=$this->input->get('roomid');
		// echo $roomid;
		// exit;
		$room=$this->rooms_content_model->getroombyid($roomid);
		if(count($room)==0){
			header("Location:" . $this -> config -> base_url() . "rooms/view");
			exit;
		}
		
		$room_stats=$this->rooms_content_model->get_room_stats($roomid);
		
		$data['stats']=$room_stats;
		$data['room']=$room;
		
		
		$this->load->library("pagination");
		$offset = ($this->uri->segment(3) != '' ? $this -> uri -> segment(3): 1);
		if($this->input->post('per_page')){
			$per_page = $this->input->post('per_page');
		}else{
			$per_page = 10;
		}
		$totalrooms=$this->rooms_content_model->get_all_room_meetings_count($roomid);
		$url= $this -> config -> base_url() ."rooms/detail"; 
    	
		$pagination_detail = $this->pagination->pagination($totalrooms, $per_page, $offset, $url, "roomid=".$roomid);
		$data['paginglinks'] = $pagination_detail['paginationLinks'];
		$data['pagermessage'] = $pagination_detail ['paginationMessage'];
		
		$result=$this->rooms_content_model->get_all_room_meetings_detail($roomid,$offset,$per_page);
		$data['total']=$totalrooms;
		
		$data['room_detail']=$result;
		
		$this->load->view('user_detail_rooms_content',$data);
	}
	
	
	
	public function user_delete_room(){
		
		$access=$this->check_user();
		$this->panels_check_permission($access);
		$this -> load -> model('rooms_content/rooms_content_model');
		
		$roomid=$this->input->get('roomid');

		$room=$this->rooms_content_model->delete_room($roomid);
			$this->session->set_flashdata('success_message','Room Deleted Successfully');
			header("Location:" . $this -> config -> base_url() . "rooms/view");
		exit;
		

	}
	
	
	
	
}