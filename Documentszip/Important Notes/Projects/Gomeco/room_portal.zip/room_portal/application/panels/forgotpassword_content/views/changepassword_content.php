  <div class="basic-page">
			<div class="container">
				<div class="row">
					<div class="col-md-4 col-md-offset-1">
						<div class="basic-left">
							<h1>Recover Password</h1>
							<p>Don’t have an account? Signup</p>
						</div>
					</div>
					
   
					<div class="col-md-4 col-md-offset-1">
						<div class="basic-right">
													
						    
						    								 <form class="form-horizontal" id="form_reset_password" name="form_reset_password" method="POST" action="<?php echo $this->config->base_url();?>forgotpassword_content/change_password">
				              <input type="hidden" name="reset" value="<?php echo $this->input->get('reset'); ?>" />
								<div class="single-field">
									<p for="">New Password*</p>
									<input name="password" id="password" type="password" placeholder="Enter your password" >
								</div>
								<div class="single-field">
									<p for="">Confirm Password*</p>
									<input name="confirm_password" id="confirm_password" type="password" placeholder="Confirm password" >
								</div>
								<div class="single-field">
									<button type="submit">Reset Password <i class="fa fa-arrow-right"></i></button>
								</div>
							</form>
						</div>
					</div>
				</div>
			</div>
	</div>
