
    <div class="basic-page">
	<div class="container">
		<div class="row">
			
						
			<div class="col-md-4 col-md-offset-1">
				<div class="basic-left">
					<h1>Request a Demo</h1>
					<p>Tell us a little about yourself and your company so we can get you set up.</p>
				</div>
			</div>
			<div class="col-md-5 col-md-offset-1">
				<div class="basic-right">
					 <form class="form-horizontal" id="requestForm" name="requestForm" method="POST" action="<?php echo $this->config->base_url(); ?>request_content/submit_request">
				               
							
                   	<h3>A little about you</h3>
						<div class="single-field">
							<p for="">Full Name*</p>
							<input name="full_name" id="full_name" type="text" placeholder="Enter your First and Last Name" value="<?php print_r($user_add_data['full_name']) ?>" >
						</div>
						<div class="single-field">
							<p for="">Company role*</p>
							<input name="company_role" id="company_role" type="text" placeholder="Enter your Current title" value="<?php print_r($user_add_data['company_role']) ?>" >
						</div>
						
						<h3>Tell us about your company</h3>
						<p>* We do not currently support suppliers of software or services.</p>
						<div class="single-field">
							<p for="">Company name*</p>
							<input name="company_name" id="company_name" type="text" placeholder="Enter your company's name" value="<?php print_r($user_add_data['company_name']) ?>" >
						</div>
						<div class="single-field">
							<p for="">Company website*</p>
							<input name="company_website" id="company_website" type="text" placeholder="http://yourcompanywebsite.com" value="<?php print_r($user_add_data['company_website']) ?>" >
							
						</div>
						<h3>Your contact information</h3>
						<div class="single-field">
							<p for="">Phone</p>
							<input name="phone" id="phone" type="text" placeholder="Enter your phone number" value="<?php print_r($user_add_data['phone']) ?>" >
							
						</div>
						<div class="single-field">
							<p for="">Email*</p>
							<input name="email" type="email" placeholder="Enter your mail address"  id="email"  value="<?php print_r($user_add_data['email']) ?>" >
							
						</div>
						<div class="single-field">
							<input id="checkbox-2" name="check_auth" id="check_auth" class="checkbox-custom" name="authorized" type="checkbox" >
							<label for="checkbox-2" class="checkbox-custom-label">I am authorized to act on behalf of this company</label>
						</div>
						<div class="single-field submit-field">
							<button type="submit">Finish <i class="fa fa-arrow-right"></i></button>
							<p>* These fields are required</p>
						</div>
					</form>
				</div>
			</div>
		</div>
	</div>
</div>

