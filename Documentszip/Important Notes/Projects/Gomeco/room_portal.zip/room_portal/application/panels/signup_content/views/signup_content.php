
        <div class="basic-page">
			<div class="container">
				<div class="row">
					<div class="col-md-4 col-md-offset-1">
						<div class="basic-left">
							<h1>Sign up</h1>
							<p>Sign up for Account</p>
						</div>
					</div>
					<div class="col-md-4 col-md-offset-1">
						<div class="basic-right">
													
						    
						    							 <form class="form-horizontal" id="userSignUp" name="userSignUp" method="POST" action="<?php echo $this->config->base_url();?>signup_content/user_singup">
				              
				                <div class="single-field">
									<p for="">First Name</p>
									<input name="first_name" id="first_name" type="text" placeholder="Enter your First Name" value="<?php print_r($user_add_data['first_name']) ?>" >
								</div>
								
								<div class="single-field">
									<p for="">Last Name</p>
									<input name="last_name" id="last_name" type="text" placeholder="Enter your Last Name" value="<?php print_r($user_add_data['last_name']) ?>" >
								</div>
				              
								<div class="single-field">
									<p for="">Email*</p>
									<input name="email" id="email" type="email" placeholder="Enter your mail address" value="<?php print_r($user_add_data['email']) ?>" >
								</div>
								<div class="single-field">
									<p for="">Password*</p>
									<input name="password" id="password" type="password" placeholder="Enter your password" >
								</div>
								
								<div class="single-field">
									<p for="">Category</p>
									<select class="form-input" name="category" style="width: 100%">
										<option value="ews" <?php 
										if($user_add_data['category']=='ews'){ echo "selected";}
										?>>ews</option>
										<option  <?php 
										if($user_add_data['category']=='aws'){ echo "selected";}
										?> value="aws">aws</option>
										
									</select>
									
								</div>
								<div class="single-field">
									<button type="submit">Signup <i class="fa fa-arrow-right"></i></button>
									
								</div>
							</form>
						</div>
					</div>
				</div>
			</div>
	</div>