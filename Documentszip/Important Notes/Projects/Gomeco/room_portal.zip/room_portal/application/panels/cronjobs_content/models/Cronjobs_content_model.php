<?php

class Cronjobs_content_model extends MY_Model {
	public function __construct() {
		parent::__construct("rooms");
	}
	
	

	
	public function get_all_rooms(){

		$params=array(
			'select'=>"*",
			'from'=> "rooms",
		);
		$result=$this->find($params);
		return $result;
		/*******/
	}
	
	
	
	public function add_meeting($params){
		$this->insert($params,'meetings');
	}
	
	

	public function check_meeting_exist($meeting_id,$changekey){
		return $this->count("meeting_id = '$meeting_id' and change_key = '$changekey'",'meetings');
	}
	
}
?>
