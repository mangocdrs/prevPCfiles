<?php

class Pricing_content_model extends MY_Model {
	public function __construct() {
		
		parent::__construct("");
	}
	public function submit_request(){
		
		
	        $userinfo='';
			
			$full_name=$this->input->post('full_name');
		    $company_role=$this->input->post('company_role');
			$company_name=$this->input->post('company_name');
			$company_website=$this->input->post('company_website');
			$email=$this->input->post('email');
			$phone=$this->input->post('phone');
			
			$userinfo=$userinfo.'<br>Full Name: '.$full_name;
			$userinfo=$userinfo.'<br>Company Role: '.$company_role;
			$userinfo=$userinfo.'<br>Company Name: '.$company_name;
			$userinfo=$userinfo.'<br>Company Website: '.$company_website;
			$userinfo=$userinfo.'<br>Email: '.$email;
			$userinfo=$userinfo.'<br>Phone: '.$phone;
			
			
		    $email_content=$this ->get_email_template('demo_request');
			if(empty($email_content)){
				
		    	$email_contentt_full='New Demo Request '.$userinfo;
				
			}else{
				
				$email_contentt_full=$email_content->html_body.$userinfo;
				
			}
			
			$this ->send_email('Demo Request Recieved',$email_contentt_full,$email ,'Gameco','admin@gameco.com');
		    $this->session->set_flashdata('success_message','Your Request has been submitted');
		    return true;
		
		
		
	}
	
	





}
?>
