<?php
if (!defined('BASEPATH'))
	exit('No direct script access allowed');

class Tokens_content extends MY_Controller {

	public function __construct() {
		parent::__construct();

	}

	public function index() {
		exit ;
	}
	
	public function user_view_all_tokens() {
		
		require_once APPPATH . 'libraries/outlook_token/vendor/autoload.php';
		$authenticator = new Outlook\Authorizer\Authenticator(CLIEND_ID, CLIEND_SECRET, $redirectUri = $this->config->base_url()."refreshtoken/savetoken");

        $token = $authenticator->getToken();
        $loginurl= $authenticator->getLoginUrl();
	   
		
        $this->load->model('tokens_content_model');
		$success_message=$this->session->flashdata('success_message');
		$error_message=$this->session->flashdata('error_message');
		$user_add_data=$this->session->flashdata('user_add_data');
		//$data['regions']=$this-> tokens_content_model->get_regions();
    	$data['error_message']= $error_message;
		$data['success_message']= $success_message;
		$data['user_add_data']=$user_add_data;
		$token=$this->tokens_content_model->check_token();
		//print_r($token);
		if(!empty($token)){
			
			$refresh='yes';
		}
		else{
			
			$refresh='no';
		}
		$data['refresh']=$refresh;
		$data['loginurl']=$loginurl;
		$this -> load -> view('user_view_all_tokens', $data);

	}

	public function federal_admin_edit_category() {
		
		$access=$this->check_user();
		$this->panels_check_permission($access);

		$this->load->model('tokens_content_model');
		$data['regions']=$this-> tokens_content_model->get_regions();
		$user_id = $this->input->get('id');
		$data['result'] = $this-> tokens_content_model-> get_categories_by_id($user_id);

		$success_message=$this->session->flashdata('success_message');
		$error_message=$this->session->flashdata('error_message');
		$user_add_data=$this->session->flashdata('user_add_data');
    	$data['error_message']= $error_message;
		$data['success_message']= $success_message;
		$data['user_add_data']=$user_add_data;
		$this->load->view('federal_admin_update_category', $data);
	}

	public function user_add_token(){
		
		require_once APPPATH . 'libraries/outlook_token/vendor/autoload.php';
		$authenticator = new Outlook\Authorizer\Authenticator(CLIEND_ID, CLIEND_SECRET, $redirectUri = $this->config->base_url()."refreshtoken/savetoken");

        $token = $authenticator->getToken();
        $loginurl= $authenticator->getLoginUrl();
	   
		
        $this->load->model('tokens_content_model');
		$success_message=$this->session->flashdata('success_message');
		$error_message=$this->session->flashdata('error_message');
		$user_add_data=$this->session->flashdata('user_add_data');
		//$data['regions']=$this-> tokens_content_model->get_regions();
    	$data['error_message']= $error_message;
		$data['success_message']= $success_message;
		$data['user_add_data']=$user_add_data;
		$data['loginurl']=$loginurl;
		$this->load->view('user_add_token',$data);
	}
	
	public function user_save_token(){
		
	$code =$this->input->get('code'); //$_GET["code"];

    $curl = curl_init();

    curl_setopt_array($curl, array(
        CURLOPT_URL => "https://login.microsoftonline.com/common/oauth2/v2.0/token",
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_ENCODING => "",
        CURLOPT_MAXREDIRS => 10,
        CURLOPT_TIMEOUT => 30,
        CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
        CURLOPT_CUSTOMREQUEST => "POST",
        CURLOPT_HTTPHEADER => array(
            "Content-type"=>"application/x-www-form-urlencoded",
            "Content-Length"=>144
        ),
        CURLOPT_POSTFIELDS => array(
            "grant_type" => "authorization_code",
            "client_id" => CLIEND_ID,
            "client_secret" => CLIEND_SECRET,
            "code" => $code,
           
            "redirect_uri" => $this->config->base_url()."refreshtoken/savetoken"),
    ));

    $response = curl_exec($curl);
	
    $err = curl_error($curl);

    curl_close($curl);

    if ($err) {
        echo "cURL Error #:" . $err;
    } else {
    	
    	$this->load->model('tokens_content_model');
        $response_arr= json_decode($response);
     
	   $refresh_token=$response_arr->refresh_token;
	   $result_id=$this->tokens_content_model->insert_token($refresh_token);
	   if($result_id){
	   	
		$this->session->set_flashdata('success_message','Token Saved');
	    header("location:".$this->config->base_url().'refreshtoken/view');
	    exit;
	   }
	   else{
	   	
		$this->session->set_flashdata('error_message','Error Adding Token');
	    header("location:".$this->config->base_url().'refreshtoken/view');
	    exit;
	   }
	  
	}
		
	}

	

	
public function user_delete_token() {

		$this->load->model('tokens_content_model');
		$this->tokens_content_model->delete_token();
		$this->session->set_flashdata('success_message','Token Deleted Successfully');
		header("Location:" . $_SERVER['HTTP_REFERER']);
		exit;
		}	

}