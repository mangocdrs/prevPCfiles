<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

if ( ! function_exists('roomvalidation'))
{
	function roomvalidation($image = null){
		$CI =& get_instance();
		$CI->load->helper(array('form', 'url','file'));
    	$CI->load->library('form_validation');
	    $CI->form_validation->set_rules('room_name', 'Room Name', 'required');
		$CI->form_validation->set_rules('email', 'Username', 'required');
		// $CI->form_validation->set_rules('password', 'Password', 'required');
		$CI->form_validation->set_rules('room_unique_name', 'Room Unique Name', 'required');
		$CI->form_validation->set_rules('capacity', 'Capacity', 'required');
		$CI->form_validation->set_rules('info', 'Info', 'required');
		$CI->form_validation->set_rules('support_email', 'Support Email', 'required');
		
		if ($CI->form_validation->run() == FALSE){
                 
                 $data = array(	
	                 'room_name' => set_value('room_name'),
                     'room_unique_name' => set_value('room_unique_name'),
                 	 'email' => set_value('email'),
                     'support_email' => set_value('support_email'),
                     'capacity' => set_value('capacity'),
                     'info' => set_value('info'),
                     'error_message' => validation_errors(),
	                 'valid'=>0,
	            );
          
			}
            else
            {
                $data = array(
                'valid' => 1,
                'error_message' => "no validation error"
            	);
			}
			$CI->session->set_flashdata('user_add_data', $data);
			return $data['valid'];
	}
}


if ( ! function_exists('roomeditvalidation'))
{
	function roomeditvalidation($image = null){
		$CI =& get_instance();
		$CI->load->helper(array('form', 'url','file'));
    	$CI->load->library('form_validation');
	    $CI->form_validation->set_rules('room_name', 'Room Name', 'required');
		$CI->form_validation->set_rules('email', 'Username', 'required');
		// $CI->form_validation->set_rules('password', 'Password', 'required');
		$CI->form_validation->set_rules('room_unique_name', 'Room Unique Name', 'required');
		$CI->form_validation->set_rules('capacity', 'Capacity', 'required');
		$CI->form_validation->set_rules('info', 'Info', 'required');
		$CI->form_validation->set_rules('support_email', 'Support Email', 'required');
		
		if ($CI->form_validation->run() == FALSE){
                 
                 $data = array(	
	                 'room_name' => set_value('room_name'),
                     'room_unique_name' => set_value('room_unique_name'),
                 	 'email' => set_value('email'),
                     // 'password' => set_value('password'),
                     'support_email' => set_value('support_email'),
                     'capacity' => set_value('capacity'),
                     'info' => set_value('info'),
                     'error_message' => validation_errors(),
	                 'valid'=>0,
	            );
          
			}
            else
            {
                $data = array(
                'valid' => 1,
                'error_message' => "no validation error"
            	);
			}
			$CI->session->set_flashdata('user_add_data', $data);
			return $data['valid'];
	}
}

