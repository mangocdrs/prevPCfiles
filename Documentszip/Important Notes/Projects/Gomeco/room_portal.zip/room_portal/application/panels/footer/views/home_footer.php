<div class="modal fade" id="warrantyModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
		<div class="modal-dialog" role="document">
			<div class="modal-content today_schedule">
				<div class="modal-header"><h2>Today's Schedule</h2></div>
				<div class="modal-body" >
					
					<table class="table table-bordered" id="mytable">
						<thead>
							
						</thead>
						<tbody class="popup_body">
							
						</tbody>
					</table>
					<br> 
				</div>
				<div class="modal-footer">
					<button type="button" class="btn btn-primary button-popup-close model_close_today_schedule" data-dismiss="modal" aria-hidden="true">Close</button>
				</div>
			</div>
		</div>
		
	</div>
	
	<div class="modal fade" id="room_list" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
		<div class="modal-dialog" role="document">
			<div class="modal-content available_rooms">
				<div class="modal-header"><h2>Available Rooms</h2></div>
				<div class="modal-body" >
					
					<table class="table" id="mytable">
						<thead>
							
						</thead>
						<tbody class="popup_body">
							
						</tbody>
					</table>
					  
				</div>
				<div class="modal-footer">
					<button type="button" class="btn btn-primary button-popup-close model_close_room_list" data-dismiss="modal" aria-hidden="true">Close</button>
					</div>
			</div>
		</div>
		
	</div>

<!-- report a bug popup -->
<!-- cancel event popup-->
	
<div class="modal fade" id="report_form" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
		<div class="modal-dialog" role="document">
			<div class="modal-content">
				<div class="modal-header">
					<h2>What are you having an Issue with?</h2>
				</div>
				<!-- Modal Body -->
            <div class="modal-body report-options">
                
                <form role="form" name="submit_report_bug" method="POSt" action="<?php echo $this->config->base_url().'rooms_content/submit_report_bug'; ?>">
                  <div class="form-group">
                  
                  <!-- <div class="col-sm-4"> -->
                  		<div class="option-field">
                        	<input type="radio" id="light_issue" value="Light Issue" name="selectgroupforreport" >
                        	<label for="light_issue">Lights</label>
                        </div>
                        <div class="option-field">
                        	<input type="radio" id="temp_issue" value="Temp Issue" name="selectgroupforreport" >
                        	<label for="temp_issue">Temperature</label>
                        </div>
                        <div class="option-field">
                        	<input type="radio" id="power_issue" value="Power Issue" name="selectgroupforreport" >
                        	<label for="power_issue">Power</label>
                        </div>
                   
                   		<div class="option-field">
                        	<input type="radio" id="internet_issue" value="Internet Issue" name="selectgroupforreport" >
                        	<label for="internet_issue">Internet</label>
                        </div>
                        <div class="option-field">
                        	<input type="radio" id="cleaning_issue" value="Cleaning Issue" name="selectgroupforreport" >
                        	<label for="cleaning_issue">Cleaning</label>
                        </div>
                        <div class="option-field">
                        	<input type="radio" id="other_issue" value="Other Issue" name="selectgroupforreport" >
                        	<label for="other_issue">Other</label>
                   		</div>
                    <!-- </div> -->
                  </div>
                  
            </div>
            <div class="modal-footer">
            	<button type="button" class="btn btn-default button-popup-close" data-dismiss="modal" aria-hidden="true">Close</button>
            	<button type="submit" class="btn btn-success button-popup-close"  aria-hidden="true">Submit</button>
                  
            </div>
            </form>
			</div>
			
		</div>
		
	</div>
<!-- end of report a bug popup -->

<!-- space info popup -->
	
<div class="modal fade" id="space_info" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
		<div class="modal-dialog" role="document">
			<div class="modal-content">
				<div class="modal-header">
					<h2>Space Info</h2>
				</div>
				<!-- Modal Body -->
            <div class="modal-body">
                
                <h4 style="text-align: center; padding: 20px 0;"><?php echo $rooms->info;?></h4>
                  
            </div>
            <div class="modal-footer">
            	<button type="button" class="btn btn-primary button-popup-close" data-dismiss="modal" aria-hidden="true">Close</button>
            </div>
           
			</div>
			
		</div>
		
	</div>
<!-- end of space info popup -->


<footer>
		<div class="content-container">
			<ul>
				<!--<li><a data-toggle-"modal" data-target="#report_form" href="#"><img src="<?php echo $this->config->base_url(); ?>r/images/info-icon.png" alt="">Space Info</a></li>-->
				<li><a data-toggle="modal" data-target="#space_info" href="#"><img src="<?php echo $this->config->base_url(); ?>r/images/info-icon.png" alt="">Space Info</a></li>
				<li><a data-toggle="modal" data-target="#report_form" href="#"><img src="<?php echo $this->config->base_url(); ?>r/images/flag-icon.png" alt="">Report Issue</a></li>
				<li><a class="rooms_list model_open_room_list" href="#"><img src="<?php echo $this->config->base_url(); ?>r/images/search-icon.png" alt="">Find another Room</a></li>
				<li><a  class="today_schedule1 model_open_today_schedule" href="#"><img src="<?php echo $this->config->base_url(); ?>r/images/schedule-icon.png" alt="">Today's schedule</a></li>
			</ul>
		</div>
</footer>
<div class="loader-div-main rooms_list_view" style="display: none;">
<div class="loader-div">
	<div class="loader"><img src="<?php echo $this->config->base_url()?>r/images/abload.gif" /></div>
	<p class="text-loader">Gathering availability status...</p>
</div>
</div>

<div class="loader-div-main get_today_schedule_view" style="display: none;">
<div class="loader-div">
	<div class="loader"><img src="<?php echo $this->config->base_url()?>r/images/abload.gif" /></div>
	<p class="text-loader">Fetching updated schedule...</p>
</div>
</div>


<div class="loader-div-main submit1_click" style="display: none;">
<div class="loader-div">
	<div class="loader"><img src="<?php echo $this->config->base_url()?>r/images/abload.gif" /></div>
	<p class="text-loader">Booking your meeting...</p>
</div>
</div>


<div class="loader-div-main submit2_click" style="display: none;">
<div class="loader-div">
	<div class="loader"><img src="<?php echo $this->config->base_url()?>r/images/abload.gif" /></div>
	<p class="text-loader">Extending your reservation...</p>
</div>
</div>

<div class="loader-div-main button_end_meeting" style="display: none;">
<div class="loader-div">
	<div class="loader"><img src="<?php echo $this->config->base_url()?>r/images/abload.gif" /></div>
	<p class="text-loader">Updating schedule...</p>
</div>
</div>
<script>


// $('.model_close_today_schedule').click(function(){
	// $.unblockUI();
// });
// $('.model_close_room_list').click(function(){
	// $.unblockUI();
// });	 
// 
// $('.model_open_today_schedule').click(function(){
	 // $.blockUI();
// });
// $('.model_open_room_list').click(function(){
	 // $.blockUI();
// });	 

 $('.button-end-meeting').click(function(){
 	$('.button_end_meeting').show();
 });
 $('.today_schedule1').click(function(){
 	$('.get_today_schedule_view').show();
   	  	setTimeout(function(){ get_today_schedule_view(); }, 300);
 });
	function get_today_schedule_view(){
		
	
	 var url="<?php echo $this->config->base_url(); ?>rooms_content/get_today_schedule";
	  $.ajax({
	  		
   			url: url,
   			data: {
      			format: 'json'
   			},
		   	error: function(data) {
		   		console.log(data);
		   		alert("error");
		   	},
		   	dataType: 'json',
		   	success: function(data) { 
		   		
		   		$('.get_today_schedule_view').hide();

		   		$('#warrantyModal').modal();   
				
				var ind = 1;
				$("#mytable > tbody").html("");
				$('#mytable > tbody:last-child').append('<tr><td><b>Reserved By</b></td><td><b>Subject</b></td><td><b>Start Time</b></td><td><b>End Time</b></td></tr>');
				
				$.each(data['today'], function(index, itemData) {
					// alert(itemData['name']);
					$('#mytable > tbody:last-child').append('<tr><td>'+itemData['organizer']+'</td><td>'+itemData['name']+'</td><td>'+itemData['starttime']+'</td><td>'+itemData['endtime']+'</td></tr>');
					ind = ind + 1;
	  			});
		    },
		   	type: 'GET',
		   	async:false
		   	 // timeout: 5000
		});
		 
		// return false;
	};
    
    
    $('.rooms_list').click(function(){
   	  	$('.rooms_list_view').show();
   	  	setTimeout(function(){ rooms_list_view(); }, 300);
    });
    
  
   function rooms_list_view(){
   		var url="<?php echo $this->config->base_url(); ?>rooms_content/get_rooms_list";
	  $.ajax({
	  		
   			url: url,
   			data: {
      			format: 'json'
   			},
		   	error: function(data) {
		   		console.log(data);
		   		
		   	},
		   	dataType: 'json',
		   	success: function(data) { 
		   		
	   			$('.rooms_list_view').hide();
		   		$('#room_list').modal();   
				
				var ind = 1;
				$("#mytable > tbody").html("");
				$('#mytable > tbody:last-child').append('<tr><td><b>Room Name</b></td><td><b>Status</b></td><td><b>Capacity</b></td><td><b>Location</b></td></tr>');
				
				$.each(data, function(index, itemData) {
					// alert(itemData['name']);
					var status = "";
					if(itemData['status'] == "Available"){
						status = '<span class="available_rooms_span">Available</span>';
					}else{
						status = '<span class="in_use_rooms_span">In Use</span>';
					}
					if(itemData['current']!=""){
					$('#mytable > tbody:last-child').append('<tr><td>'+itemData['name']+'<span class="selected_room">'+itemData['current']+'</span></td><td>'+status+'</td><td>'+itemData['capacity']+'</td><td>'+itemData['location']+'</td></tr>');
					}
					else{
						$('#mytable > tbody:last-child').append('<tr><td>'+itemData['name']+'</td><td>'+status+'</td><td>'+itemData['capacity']+'</td><td>'+itemData['location']+'</td></tr>');
					}
					
					ind = ind + 1;
	  			});
		    },
		   	type: 'GET',
		   	async:false
		});
		
		// return false;
	}

</script>

