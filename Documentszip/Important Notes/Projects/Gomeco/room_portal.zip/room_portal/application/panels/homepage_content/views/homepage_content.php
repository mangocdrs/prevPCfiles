<?php // phpinfo();?>
		<div style="	background-position: top left;    background-repeat: no-repeat !important;    background-size: 100% !important;">
		
		<!-- Hero Area -->
		<div class="hero-area">
			<div class="container">
				<div class="row">
					<div class="col-md-5">
						<div class="hero-content">
							<h2>Scheduling for your office, just got simpler.</h2>
							<p>Our conference room displays are a simple tool that allow you to gain control of your office. Complete with analytics and insights that uncover usage and help optimize space.</p>
							<a href="<?php echo $this->config->base_url();?>demorequest" class="blue-btn">Request a Demo</a>
							<a href="tel:18889794552" class="black-btn">Call 1-888-979-4552</a>
						</div>
					</div>
					<div class="col-md-7">
						<div class="hero-tablet">
							<img src="<?php echo $this->config->base_url();?>r/images/tablet.png" alt="">
						</div>
					</div>
				</div>
			</div>
		</div><!-- /Hero Area -->
		
		
		<!-- Default Area -->
		<div class="default-area">
			<div class="container">
				<div class="row">
					<div class="col-md-7">
						<div class="product-img">
							<br><img src="<?php echo $this->config->base_url();?>r/images/rules.png" alt="">
						</div>
					</div>
					<div class="col-md-5">
						<div class="product-content">
							<h3>Avoid Conflict & Increase Availability</h3>
							<strong>See an empty room and not sure if its already booked? Not anymore. Gomeco enables you to book a room, right at the door. Check-ins confirm the meeting took place. If nobody shows up you have the option to automatically unbook the room, and free up the calander.</strong>
							<p>Just the tool we needed to manage our quick growth and save valuable time.”</p>
							<p>Sana from Sysco</p>
						</div>
					</div>
				</div>
			</div>
		</div><!-- /Default Area -->
		
		<!-- Default Area -->
		<div class="default-area">
			<div class="container">
				<div class="row">
					<div class="col-md-5">
						<div class="product-content">
						<br><br><br><br><br><br>
							<h3>More Data. No more Guesses.</h3>
							<strong>Over 95 KPIs help uncover workplace usage, including: popular rooms, equipment, average meeting length and attendee count.</strong>
							<p>"We didn't have an effecient way to quantify peak times per room or which of the office space types were being used most often. With Gomeco, we do.”</p>
							<p>Shahbaz from iDroid USA</p>
						</div>
					</div>
					<div class="col-md-5 col-md-offset-2">
						<div class="product-members">
							<div class="single-member">
								<div class="member-img">
									<img src="<?php echo $this->config->base_url();?>r/images/rm1.jpeg" alt="">
								</div>
								<div class="member-details">
									<h3>Most Available</h3>
									<p>This room wins for most active last week.<br>Suggest it to colleagues.</p>
								</div>
							</div>
							<div class="single-member">
								<div class="member-img">
									<img src="<?php echo $this->config->base_url();?>r/images/rm2.jpeg" alt="">
								</div>
								<div class="member-details">
									<h3>Underused</h3>
									<p>This room has low capacity usage.<br>Make sure big teams know about it.</p>
								</div>
							</div>
							<div class="single-member">
								<div class="member-img">
									<img src="<?php echo $this->config->base_url();?>r/images/rm3.jpeg" alt="">
								</div>
								<div class="member-details">
									<h3>Activity Spike</h3>
									<p>189% increase in meetings here.<br>Find out what changed.</p>
								</div>
							</div>
							<div class="single-member">
								<div class="member-img">
									<img src="<?php echo $this->config->base_url();?>r/images/rm4.jpeg" alt="">
								</div>
								<div class="member-details">
									<h3>Freed up</h3>
									<p>People aren't showing up.<br>Automatically remove abandoned meetings.</p>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div><!-- /Default Area -->
		</div>

		<!-- Default Area -->
		<div class="default-area map-area" style="background:url(http://gomeco.com/images/bg2.svg)">
			<div class="container">
				<div class="row">
					<div class="col-md-5 col-md-offset-3">
						<div class="map-guys row">
							<div class="col-sm-4">
								<div class="single-map-guys mt-15">
									<img src="<?php echo $this->config->base_url();?>r/images/member-1.jpeg" alt="">
									<h3>Meg Anderson</h3>
									<h4>Trimpac</h4>
								</div>
							</div>
							<div class="col-sm-4">
								<div class="single-map-guys mt-55">
									<img src="<?php echo $this->config->base_url();?>r/images/member-3.jpeg" alt="">
									<h3>Terry Wong</h3>
									<h4>Dyart Labs</h4>
								</div>
							</div>
							<div class="col-sm-4">
								<div class="single-map-guys">
									<img src="<?php echo $this->config->base_url();?>r/images/member-2.jpeg" alt="">
									<h3>Irum Hamid</h3>
									<h4>AIN Productions</h4>
								</div>
							</div>
						</div>
					</div>
					<div class="col-md-8">
						<div class="product-content">
							<h3>Get Local Support</h3>
							<strong>Gomeco has partners across regions, states, and continents, creating a support network that is capable of providing deployment, training and support efficiently.</strong>
							<p>"We were just trying a pilot, but the support made onboarding so seemless that before we knew it Gomeco was an essential part of our workflow.”</p>
							<p>Hamid from T C Sin & Associates</p>
						</div>
					</div>
				</div>
			</div>
		</div><!-- /Default Area -->
		
		<!-- Default Area -->
		<div class="default-area">
			<div class="container">
				<div class="row">
					<div class="col-md-6">
						<div class="product-content">
							<h3 class="mt-100">Gomeco works everywhere you do.</h3>
							<h5>Sync over the cloud or deploy on premises.</h5>	
						</div>
					</div>
					<div class="col-md-8 col-md-offset-1">
						<div class="product-content">
							<br><img src="<?php echo $this->config->base_url();?>r/images/icons.jpeg" alt="">
						</div>
					</div>
				</div>
			</div>
		</div><!-- /Default Area -->	
		
		<!-- Hero Area -->
		<div class="hero-area">
			<div class="container">
				<div class="row">
					<div class="col-md-5">
						<div class="hero-content">
							<h2>Let's reimagine a better workplace, together.</h2>
							<p>Ready to get started? Request a Demo or give us a call and we'll walk you through it.</p>
							<a href="<?php echo $this->config->base_url();?>demorequest" class="blue-btn">Request a Demo</a>
							<a href="tel:18889794552" class="black-btn">Call 1-888-979-4552</a>
						</div>
					</div>
					<div class="col-md-7">
						
					</div>
				</div>
			</div>
		</div><!-- /Hero Area -->
	