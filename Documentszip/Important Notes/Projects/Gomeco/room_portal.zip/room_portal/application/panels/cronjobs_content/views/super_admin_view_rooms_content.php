<?php if (isset($success_message) && $success_message!=""){ ?>
<script>
	setTimeout(function() {
	     $.bootstrapGrowl('<?php echo $success_message;?>', {
	         type: 'success',
	         align: 'center',
	         width: 'auto',
	         allow_dismiss: false
	     });
	 }, 1);
</script>
<?php } ?>
<?php
	if (isset($error_message) && $error_message!="" ){ 
		if(!isset($user_add_data['error_message'])){
		?>
	
	<script>
	       setTimeout(function() {
	            $.bootstrapGrowl('<?php echo $error_message;?>', {
	                type: 'danger',
	                align: 'center',
	                width: 'auto',
	                allow_dismiss: false
	            });
	        }, 1);
	    </script>
	   <?php
		
		}
		$error_message =  strip_tags($user_add_data['error_message']);
	    $error_message = str_replace(array("\r", "\n"), '', $error_message);
		$error_message= explode('.',$error_message);
	 	for($i=0; $i<count($error_message)-1; $i++){
  			$error = $error_message[$i];
        	if (isset($error)){ ?>
	        	
        		<script>
	       setTimeout(function() {
	            $.bootstrapGrowl("<?php echo $error;?>", {
	                type: 'danger',
	                align: 'center',
	                width: 'auto',
	                allow_dismiss: false
	            });
	        }, 1);
	    </script>
        		
        		
        	<?php }	}
		 } ?>
<div class="row">
                <div class="col-lg-12">
                    <div class="ibox float-e-margins">
                        <div class="ibox-title" style="height: 55px;">
                            <h5>All Rooms</h5>
                        	<a class="btn btn-primary pull-right" href="<?php echo $this->config->base_url();?>rooms/add" >Add Room</a>
                            
                        </div>
                        <div class="ibox-content">
							<table class="footable table table-stripped toggle-arrow-tiny" data-page-size="8">
                                <thead>
                                <tr>
                                    <th data-toggle="true">Room Name</th>
                                    <th data-toggle="true">Room Location</th>
                                    <th data-hide="all">Room Address</th>
                                    <th data-hide="all">Capacity</th>
                                    <th>Action</th>
                                </tr>
                                </thead>
                                <tbody>
                                
                               <?php if(!empty($rooms)){
									foreach ($rooms as $key) { ?>
								<tr>
                                    <td><a href="<?php echo $this->config->base_url();?>rooms/detail?roomid=<?php echo $key->Id; ?>"> <?php echo $key->name; ?></a></td>
                                    <td><?php echo $key->unique_name; ?></td>
                                    <td><?php echo $key->email; ?></td>
                                    <td><?php echo $key->capacity; ?></td>
                                    <td>
                                	<a href="<?php echo $this->config->base_url();?>rooms/edit?roomid=<?php echo $key->Id; ?>"class="btn btn-primary btn-xs" data-toggle="tooltip" title="Editar">
                                		<span class="glyphicon glyphicon-pencil"></span>
                                		</button>
                                	</a>
                                		</td>
                                </tr>
                                <?php }
									}else{ ?>
										
										<tr><b><td align="center" colspan="12"><b><?php echo "No Record Found"; ?></b></td></b></tr>
								<?php } ?>
								
                                </tbody>
                                	<td>Total Records <b> <?php echo $total; ?></b>
                                	</td>
                                
                                
                                <tfoot>
                                
                                	<?php if(!empty($rooms)){ ?>
                              
                                <tr>
                                	
                                    <td colspan="12">
                                        <div class="pagination_ci" style="float:right;"> <?php echo $paginglinks; ?></div>
										<div class="pagination_ci" style="float:left;"> <?php echo (!empty($pagermessage) ? $pagermessage : ''); ?></div>
                                    </td>
                                </tr>
                                <?php } ?>
                                </tfoot>
                            </table>

                        </div>
                    </div>
                </div>
            </div>
                     