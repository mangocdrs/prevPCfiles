<?php
if (!defined('BASEPATH')) exit('No direct script access allowed');

class Reports_content extends MY_Controller {
	

	public function user_view_all_reports(){
		
		$access=$this->check_user();
		$this->panels_check_permission($access);
		
		$success_message=$this->session->flashdata('success_message');
		$error_message=$this->session->flashdata('error_message');
		$user_add_data=$this->session->flashdata('user_add_data');
    	$data['error_message']= $error_message;
		$data['success_message']= $success_message;
		$data['user_add_data']=$user_add_data;	
		
		$this -> load -> model('reports_content/reports_content_model');
		$this->load->library("pagination");
		$offset = ($this->uri->segment(3) != '' ? $this -> uri -> segment(3): 1);
		if($this->input->post('per_page')){
			$per_page = $this->input->post('per_page');
		}else{
			$per_page = 10;
		}
		$totalrooms=$this->reports_content_model->get_all_reports_count();
		$url= $this -> config -> base_url() ."rooms/view"; 
    	
		$pagination_detail = $this->pagination->pagination($totalrooms, $per_page, $offset, $url);
		$data['paginglinks'] = $pagination_detail['paginationLinks'];
		$data['pagermessage'] = $pagination_detail ['paginationMessage'];
		
		$result=$this->reports_content_model->get_all_reports_detail($offset,$per_page);
		$data['total']=$totalrooms;
		$rooms=$this->reports_content_model->get_rooms_detail();
		$data['rooms']=$rooms;
		
		$data['reports']=$result;
		$this->load->view('user_view_reports_content',$data);
	}

	
	public function export(){
		$access=$this->check_user();
		$this->panels_check_permission($access);
			// exit;
		$this -> load -> model('reports_content/reports_content_model');
		$total_users=$this->reports_content_model->get_all_reports_count();
		$result=$this->reports_content_model->get_all_reports_detail(1,$total_users);
		
		// $organization=$this->users_content_model->get_events();
		$result=$this->_user_decorator($result);
		
		$this->download_send_headers("report_export_" . date("Y-m-d") . ".csv");
		echo $this->array2csv($result);
		die();
	} 
	 
 	private function _user_decorator($result){
 		
		$res=array();
		$i=0;
		
		foreach($result as $key=>$val){
			$res[$i]['No'] =  $i+1;
				
			$res[$i]['Event Name'] =  $val->subject;
			$res[$i]['Room Name'] =  $val->room_name;
			$res[$i]['Start Time'] =  $val->start_date;
			$res[$i]['End Time'] =  $val->end_date;
			$res[$i]['Attendees'] =  $val->attendees;
					
			
			$i++;
		}
		return $res;
	}
	
	function download_send_headers($filename) {
    // disable caching
    	$now = gmdate("D, d M Y H:i:s");
	    header("Expires: Tue, 03 Jul 2001 06:00:00 GMT");
	    header("Cache-Control: max-age=0, no-cache, must-revalidate, proxy-revalidate");
	    header("Last-Modified: {$now} GMT");
	
	    // force download  
	    header("Content-Type: application/force-download");
	    header("Content-Type: application/octet-stream");
	    header("Content-Type: application/download");
	
	    // disposition / encoding on response body
	    header("Content-Disposition: attachment;filename={$filename}");
	    header("Content-Transfer-Encoding: binary");
	}
	
	function array2csv(array &$array)
	{
	   if (count($array) == 0) {
	     return null;
	   }
	   ob_start();
	   $df = fopen("php://output", 'w');
	   fputcsv($df, array_keys(reset($array)));
	   foreach ($array as $row) {
	      fputcsv($df, $row);
	   }
	   fclose($df);
	   return ob_get_clean();
	}
	
	
}