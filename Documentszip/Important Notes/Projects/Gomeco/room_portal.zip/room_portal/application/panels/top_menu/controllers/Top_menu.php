<?php
if (!defined('BASEPATH')) exit('No direct script access allowed');

class Top_menu extends MY_Controller {
	public function index() {
        
       exit;
    }
	
	
	public function user(){
		$this->load->view('user_top_menu');
	}
	
	public function investor(){
		$this->load->view('investor_top_menu');
	}
	
}