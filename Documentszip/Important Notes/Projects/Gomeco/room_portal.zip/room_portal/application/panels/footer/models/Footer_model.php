<?php

class Footer_model extends MY_Model {
	
	public function __construct() {
		parent::__construct("app_user");
	}
	
	public function get_rooms_detail($username){
		$result = $this->findOneBy(array(
			"email" => $username
		),'rooms');
		return $result;
	}
}