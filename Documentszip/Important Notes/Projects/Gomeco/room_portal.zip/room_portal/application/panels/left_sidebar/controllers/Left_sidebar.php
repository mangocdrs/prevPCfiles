<?php
if (!defined('BASEPATH')) exit('No direct script access allowed');

class Left_sidebar extends MY_Controller {

    public function  __construct(){
		parent::__construct();
		
    }
	
	public function get_tab_info()
	{
		$fullname=$this->session->userdata("firstName");
		$current_url = $_SERVER['REQUEST_SCHEME']."://".$_SERVER['HTTP_HOST'].$_SERVER['REQUEST_URI'];
		$base_url = $this->config->base_url();
		$url =  str_replace($base_url, '', $current_url);
		$result = explode("/", $url);
		$name = explode('?', $result[1]);
		if(isset($result[2])){
			$sub_name = explode('?', $result[2]);
			$sub_name = $sub_name[0];
		}else{
			$sub_name = "";
		}
		
		$sprint_no = $this->input->get("sprint");
		if(!strlen($sprint_no)){
			$sprint_no = 1;
		}
		
		$data=array(
		 "fullName"=>$fullname,
		 'page_name' => $result[0],
		 'view_name'=> $name[0], 
		 'view_sub_name'=>$sub_name,
		 'sprint_no'=> $sprint_no
		 );
		 
		 return $data;
	}
	
	
	public function user(){
		$data = $this->get_tab_info();
		//print_r($data);exit;
		$this->load->view('user_left_sidebar',$data);
	}
	public function main_admin(){
		$data = $this->get_tab_info();
		//print_r($data);exit;
		$this->load->view('mainadmin_left_sidebar',$data);
	}
	public function investor(){
		
		$this->load->model('left_sidebar/Left_content_model');
		$detail = $this->Left_content_model->get_user_detail();
		$data = $this->get_tab_info();
		$data['is_id_verified'] = $detail->is_id_verified;
		
		$this->load->view('investor_left_sidebar',$data);
	}
	
}
?>
