  <style>
		  @import  url(count/358f56.css);html{box-sizing:border-box}*,:after,:before{box-sizing:inherit}body,ul{margin:0}ul{list-style-type:none;padding:0}svg{width:auto;max-width:100%;height:auto}html{font-family:Larsseit,-apple-system,BlinkMacSystemFont,Avenir Next,Avenir,Segoe UI,Lucida Grande,Helvetica Neue,Helvetica,Fira Sans,Roboto,Noto,Droid Sans,Cantarell,Oxygen,Ubuntu,Franklin Gothic Medium,Century Gothic,Liberation Sans,sans-serif;font-size:17px;line-height:1.5;color:#5a6971}body{-webkit-font-smoothing:antialiased;-moz-osx-font-smoothing:grayscale}li,span{-webkit-font-feature-settings:"ss02";font-feature-settings:"ss02"}a{color:#32aced;-webkit-text-decoration-skip:ink;text-decoration-skip:ink}@font-face{font-family:Larsseit;font-weight:400;font-style:normal;font-display:swap;src:url(fonts/34DEE5_0_0.9d9092b7.eot);src:url(fonts/34DEE5_0_0.9d9092b7-1.eot) format("embedded-opentype"),url(fonts/34DEE5_2_0.ff936385.woff2) format("woff2"),url(fonts/34DEE5_2_0.af1f5a34.woff) format("woff"),url(fonts/34DEE5_2_0.3795a2f5.ttf) format("truetype")}@font-face{font-family:Larsseit;font-weight:500;font-style:normal;font-display:swap;src:url(fonts/medium.a694fcf9.eot);src:url(fonts/medium.a694fcf9-1.eot) format("embedded-opentype"),url(fonts/medium.a9467e9b.woff2) format("woff2"),url(fonts/medium.83c0c342.woff) format("woff"),url(fonts/medium.1c78435f.ttf) format("truetype")}@font-face{font-family:Larsseit;font-weight:700;font-style:normal;font-display:swap;src:url(fonts/bold.45b5ea6e.eot);src:url(fonts/bold.45b5ea6e-1.eot) format("embedded-opentype"),url(fonts/bold.1762f76e.woff2) format("woff2"),url(fonts/bold.b9c7b938.woff) format("woff"),url(fonts/bold.80efbd01.ttf) format("truetype")}.section{padding:40px 20px}@media  only screen and (min-width:480px){.section{padding:80px}}@media  only screen and (min-width:769px){.section{padding:80px}}.container{max-width:1000px;margin-left:auto;margin-right:auto}#navigation-header{position:-webkit-sticky;position:sticky;top:0;z-index:2}@media (-ms-high-contrast:active),(-ms-high-contrast:none){#navigation-header{position:fixed;width:100%}}.section--nav{padding-top:24px;padding-bottom:24px;background-color:#fff;width:100%}.section--nav .container{display:-ms-flexbox;display:flex;-ms-flex-align:center;align-items:center;-ms-flex-pack:justify;justify-content:space-between}.navigation-logo{height:20px;width:65px;display:inline-block;top:-2px;position:relative}.navigation-links{display:none}@media  only screen and (min-width:900px){.navigation-links{display:block}}@media  only screen and (min-width:900px) and (-ms-high-contrast:active),only screen and (min-width:900px) and (-ms-high-contrast:none){.navigation-links{position:fixed;width:100%}}.nav__links-li{display:inline;position:relative}.nav__links-link{font-weight:400;color:#1c3c5b;padding:16px}.nav__links-link,.navigation-dropdown-link{text-decoration:none}@media  only screen and (min-width:900px){.navigation-dropdown{width:160px;background-color:#fff;border-radius:6px;padding:24px;margin-bottom:0;box-shadow:-1px -1px 1px rgba(53,83,115,.06),2px 2px 2px rgba(56,105,154,.05),2px 2px 11px rgba(81,125,168,.1);position:absolute;top:28px;left:0;z-index:2;opacity:0;transform:translateY(-200%)}}.navigation-dropdown-li{margin-bottom:6px}.navigation-dropdown-li:last-child{margin-bottom:0}.navigation-dropdown-li--indented{position:relative}.navigation-dropdown-li--indented .navigation-dropdown-link{padding-left:16px;position:relative}@media  only screen and (min-width:900px){.navigation-dropdown-li--indented .navigation-dropdown-link:before{position:absolute;top:7px;left:7px;height:2px;width:4px;background-color:#d5d8da;border-radius:50%;content:""}}.navigation-dropdown-link{color:#6c8093;font-size:15px}.mobile-navigation{position:fixed;top:0;right:0;bottom:0;left:0;display:none;height:100%;overflow-y:scroll;text-align:center;background-color:#eb3349;background-image:linear-gradient(180deg,#eb3349,#f45b43);z-index:3;padding:24px}.mobile-navigation .navigation-dropdown{margin-bottom:40px;display:block}.mobile-navigation .nav__links-link,.mobile-navigation .navigation-dropdown-link{color:#fff;display:block;text-decoration:none}.mobile-navigation .navigation-dropdown-link{font-size:15px;padding:4px 12px}.mobile-navigation .nav__links-link{font-weight:500;padding:8px 12px}.nav-toggle{display:block;font-size:1px;color:transparent;background-color:transparent;text-align:center;border:0;padding:14px;position:relative;-ms-flex-align:center;align-items:center}@media  only screen and (min-width:900px){.nav-toggle{display:none}}.nav-toggle-icon,.nav-toggle-icon:after,.nav-toggle-icon:before{border-radius:5px;width:100%;height:2px;display:block;position:absolute;left:0;transform-origin:center}.nav-toggle-icon:after,.nav-toggle-icon:before{content:"";position:absolute}.nav-toggle-icon:before{top:-6px}.nav-toggle-icon:after{bottom:-6px}.nav-toggle--close{display:-ms-inline-flexbox;display:inline-flex;margin-bottom:24px}.nav-toggle--close .nav-toggle-icon:after,.nav-toggle--close .nav-toggle-icon:before{background-color:#fff}.nav-toggle--close .nav-toggle-icon:before{transform:translateY(6px) rotate(-45deg)}.nav-toggle--close .nav-toggle-icon:after{transform:translateY(-5px) rotate(45deg)}
		</style>
		<link rel="preload" href="<?php echo $this->config->base_url() ?>r/css/main.421f809a.css" as="style" onload="this.onload=null;this.rel='stylesheet'">
		<noscript><link rel="stylesheet" href="<?php echo $this->config->base_url() ?>r/css/main.421f809a.css"></noscript>
		
		<link rel="preload" as="font" href="<?php echo $this->config->base_url() ?>r/fonts/medium.a9467e9b.woff2" type="font/woff2" crossorigin="anonymous">
		<link rel="preload" as="font" href="<?php echo $this->config->base_url() ?>r/fonts/bold.1762f76e.woff2" type="font/woff2" crossorigin="anonymous">
		<link rel="preload" as="font" href="<?php echo $this->config->base_url() ?>r/fonts/34DEE5_2_0.ff936385.woff2" type="font/woff2" crossorigin="anonymous">
		
		
		  
		  <link rel="preload" href="<?php echo $this->config->base_url() ?>r/css/pricing.89b0bc66.css" as="style" onload="this.onload=null;this.rel='stylesheet'">
		  <noscript><link rel="stylesheet" href="<?php echo $this->config->base_url() ?>r/css/pricing.89b0bc66.css"></noscript>
		<script>!function(n){"use strict";n.loadCSS||(n.loadCSS=function(){});var o=loadCSS.relpreload={};if(o.support=function(){var e;try{e=n.document.createElement("link").relList.supports("preload")}catch(t){e=!1}return function(){return e}}(),o.bindMediaToggle=function(t){var e=t.media||"all";function a(){t.media=e}t.addEventListener?t.addEventListener("load",a):t.attachEvent&&t.attachEvent("onload",a),setTimeout(function(){t.rel="stylesheet",t.media="only x"}),setTimeout(a,3e3)},o.poly=function(){if(!o.support())for(var t=n.document.getElementsByTagName("link"),e=0;e<t.length;e++){var a=t[e];"preload"!==a.rel||"style"!==a.getAttribute("as")||a.getAttribute("data-loadcss")||(a.setAttribute("data-loadcss",!0),o.bindMediaToggle(a))}},!o.support()){o.poly();var t=n.setInterval(o.poly,500);n.addEventListener?n.addEventListener("load",function(){o.poly(),n.clearInterval(t)}):n.attachEvent&&n.attachEvent("onload",function(){o.poly(),n.clearInterval(t)})}"undefined"!=typeof exports?exports.loadCSS=loadCSS:n.loadCSS=loadCSS}("undefined"!=typeof global?global:this);</script>
		
			
		
		
		
	
	
	<link href="<?php echo $this->config->base_url() ?>r/css/bootstrap.min.css" rel="stylesheet">
	<!-- Font Icon CSS -->
	<link href="<?php echo $this->config->base_url() ?>r/css/font-awesome.min.css" rel="stylesheet">
	<!-- Meanmenu CSS -->
	<link href="<?php echo $this->config->base_url() ?>r/css/meanmenu.css" rel="stylesheet">
	<!-- Main CSS -->
	<link href="<?php echo $this->config->base_url() ?>r/css/style.css" rel="stylesheet">
  
  <main role="main">
    <header class="section section--pricing-hero">
  <div class="container">
    <h2 class="hero-title">Our pricing guide</h2>
    <!-- Toggle -->
    <div class="product-toggle-container">
      <span class="hero-subtitle scheduling-title active">Conference Room Displays</span>
      <div class="product-toggle" style="display: none">
        <input class="toggle-base toggle-product" id="product" type="checkbox">
        <label class="toggle-btn" for="product"></label>
      </div>
      <span class="hero-subtitle desks-title" style="display: none">Desks</span>
    </div>
  </div>
</header>

<section class="section section--medium pt--0">
  <div id="#pricing-plans" class="container plan-controller">
    <div class="plan-terms">
      <button class="plan-button" id="monthly-toggle">
        <span class="plan-term" data-plan="monthly">Monthly</span>
      </button>
      <button class="plan-button" id="annually-toggle">
        <span class="plan-term plan-term--selected" data-plan="annually">
          Annually
        </span>
      </button>
    </div>
    <div class="plans-wrapper">
      <div class="plans-container">
        <div class="pricing-plans scheduling-plans">
  <div class="pricing-plan basic-plan">
    <div class="pricing-content">
      <div class="plan-tag">Basic</div>
      <h3 class="plan-unit-price" data-monthly="$30 / space" data-annually="$20 / space"><span class="basic-price">$20 / space</span></h3>
      <small class="plan-meta" data-monthly="monthly" data-annually="annually">
        per month, billed <span class="billing-cycle">annually</span><br>
        Add up to <strong>15</strong> spaces
      </small>

      <ul class="plan-includes">
        <span class="plan-includes-title">Includes:</span>
        <li>Unlimited office buildings</li>
        <li>Room Display app: iPad & Android</li>
        <li>Mobile app for scheduling</li>
        <li>Analytics web dashboard</li>
        <li>And all standard features…</li>
      </ul>
    </div>

    <a class="button button--outline" href="<?php echo $this->config->base_url() ?>demorequest">Schedule a demo</a>
  </div>

  <div class="pricing-plan preferred-plan">
    <div class="pricing-content">
      <div class="plan-tag">Pro</div>
      <h3 class="plan-unit-price" data-monthly="$32 / space" data-annually="$22 / space"><span class="preferred-price">$22 / space</span></h3>
      <small class="plan-meta" data-monthly="monthly" data-annually="annually">
        per month, billed <span class="billing-cycle">annually</span><br>
        Add groups of <strong>5</strong>, up to <strong>30</strong> spaces
      </small>

      <ul class="plan-includes">
        <span class="plan-includes-title">All of Basic and:</span>
        <li>Amenities</li>
        <li>Issue Reporting</li>
        <li>Levels category within buildings</li>
        <li>And all standard features…</li>
      </ul>
    </div>

    <a class="button button--red" href="<?php echo $this->config->base_url() ?>demorequest">Schedule a demo</a>
  </div>

  <div class="pricing-plan enterprise-plan">
    <div class="pricing-content">
      <div class="plan-tag">Enterprise</div>
      <h3 class="plan-unit-price" data-monthly="Contact us" data-annually="Contact us"><span class="enterprise-price">Contact us</span></h3>
      <small class="plan-meta" data-monthly="monthly" data-annually="annually">
        per month, billed <span class="billing-cycle">annually</span>
      </small>

      <ul class="plan-includes">
        <span class="plan-includes-title">All of Basic, Pro, and:</span>
        <li>Level and Campus categories</li>
        <li>SAML single sign-on (SSO)</li>
        <li>Meeting services (i.e., catering, A/V)</li>
        <li>And all standard features…</li>
      </ul>
    </div>

    <a class="button button--outline" href="<?php echo $this->config->base_url() ?>demorequest">Schedule a demo</a>
  </div>
</div>

        <div class="pricing-plans desks-plans">
  <div class="pricing-plan basic-plan">
    <div class="pricing-content">
      <div class="plan-tag">Basic</div>
      <h3 class="plan-unit-price" data-monthly="$4 / desk" data-annually="$2 / desk"><span class="basic-price">$2 / desk</span></h3>
      <small class="plan-meta" data-monthly="monthly" data-annually="annually">
        per month, billed <span class="billing-cycle">annually</span><br>
        Add groups of <strong>50</strong>, up to <strong>300</strong> desks
      </small>

      <ul class="plan-includes">
        <span class="plan-includes-title">Includes:</span>
        <li>Seat assignments</li>
        <li>Seat look-up</li>
        <li>And all standard features…</li>
      </ul>
    </div>

    <a class="button button--outline" href="<?php echo $this->config->base_url() ?>demorequest">Schedule a demo</a>
  </div>

  <div class="pricing-plan preferred-plan">
    <div class="pricing-content">
      <div class="plan-tag">Pro</div>
      <h3 class="plan-unit-price" data-monthly="Annual plan only" data-annually="$3 / desk"><span class="preferred-price">$3 / desk</span></h3>
      <small class="plan-meta" data-monthly="annually" data-annually="annually">
        per month, billed <span class="billing-cycle">annually</span><br>
        Add groups of <strong>50</strong>, up to <strong>1,000</strong> desks<br>
        minimum 100 desks
      </small>

      <ul class="plan-includes">
        <span class="plan-includes-title">All of Basic and:</span>
        <li>Desk reservations</li>
        <li>Hot desking</li>
        <li>And all standard features…</li>
      </ul>
    </div>

    <a class="button button--red" href="<?php echo $this->config->base_url() ?>demorequest">Schedule a demo</a>
  </div>

  <div class="pricing-plan enterprise-plan">
    <div class="pricing-content">
      <div class="plan-tag">Enterprise</div>
      <h3 class="plan-unit-price" data-monthly="Contact us" data-annually="Contact us"><span class="enterprise-price">Contact us</span></h3>
      <small class="plan-meta" data-monthly="annually" data-annually="annually">
          per month, billed <span class="billing-cycle">annually</span><br>
          minimum 100 desks
        </small>

      <ul class="plan-includes">
        <span class="plan-includes-title">All of Basic, Pro, and:</span>
        <li>Reverse hotelling</li>
        <li>Dedicated success manager</li>
        <li>Professional services</li>
        <li>SCIM Integration</li>
        <li>SAML single sign-on (SSO)</li>
        <li>And all standard features…</li>
      </ul>
    </div>

    <a class="button button--outline" href="<?php echo $this->config->base_url() ?>demorequest">Schedule a demo</a>
  </div>
</div>

      </div>
    </div>
  </div>
</section>

<section class="section section--medium section--features-table">
  <div class="container">
    <h3 id="features">Features you expect and then some</h3>

    <section class="features-wrapper">
      <table class="features-table">
        
          <thead id="features-platform">
            <tr>
              <th>Platform</th>
              <th>Basic</th>
              <th>Pro</th>
              <th>Enterprise</th>
            </tr>
          </thead>
          <tbody>
            
            <tr>
              <td>
                <span class="feature-title" data-description="Connect with Google Apps, Office 365, and on-premise Exchange (starting with 2007)">
                  
                  Works with all major calendars
                  <svg width="16px" height="16px" viewbox="0 0 16 16" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">
    <g id="Pricing" stroke="none" stroke-width="1" fill-rule="evenodd">
        <g id="Pricing-/-Scheduling-/-Annual" transform="translate(-444.000000, -2072.000000)" fill-rule="nonzero">
            <g id="Feature-Table" transform="translate(0.000000, 1320.000000)">
                <g id="Group-5" transform="translate(179.000000, 538.000000)">
                    <g id="Section-4">
                        <g id="Group-2-Copy" transform="translate(0.000000, 36.000000)">
                            <path d="M273,178 C268.582032,178 265,181.583323 265,186 C265,190.419258 268.582032,194 273,194 C277.417968,194 281,190.419258 281,186 C281,181.583323 277.417968,178 273,178 Z M273,181.548387 C273.748258,181.548387 274.354839,182.154968 274.354839,182.903226 C274.354839,183.651484 273.748258,184.258065 273,184.258065 C272.251742,184.258065 271.645161,183.651484 271.645161,182.903226 C271.645161,182.154968 272.251742,181.548387 273,181.548387 Z M274.806452,189.741935 C274.806452,189.95571 274.633129,190.129032 274.419355,190.129032 L271.580645,190.129032 C271.366871,190.129032 271.193548,189.95571 271.193548,189.741935 L271.193548,188.967742 C271.193548,188.753968 271.366871,188.580645 271.580645,188.580645 L271.967742,188.580645 L271.967742,186.516129 L271.580645,186.516129 C271.366871,186.516129 271.193548,186.342806 271.193548,186.129032 L271.193548,185.354839 C271.193548,185.141065 271.366871,184.967742 271.580645,184.967742 L273.645161,184.967742 C273.858935,184.967742 274.032258,185.141065 274.032258,185.354839 L274.032258,188.580645 L274.419355,188.580645 C274.633129,188.580645 274.806452,188.753968 274.806452,188.967742 L274.806452,189.741935 Z" id="Shape"></path>
                        </g>
                    </g>
                </g>
            </g>
        </g>
    </g>
</svg>

                  
                </span>
              </td>
              <td><span class="check">&#10004;</span></td>
              <td><span class="check">&#10004;</span></td>
              <td><span class="check">&#10004;</span></td>
            </tr>
            
            <tr>
              <td>
                <span class="feature-title" data-description="Invite all of your co-workers, or just give your office admins superpowers.">
                  
                  Unlimited users
                  <svg width="16px" height="16px" viewbox="0 0 16 16" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">
    <g id="Pricing" stroke="none" stroke-width="1" fill-rule="evenodd">
        <g id="Pricing-/-Scheduling-/-Annual" transform="translate(-444.000000, -2072.000000)" fill-rule="nonzero">
            <g id="Feature-Table" transform="translate(0.000000, 1320.000000)">
                <g id="Group-5" transform="translate(179.000000, 538.000000)">
                    <g id="Section-4">
                        <g id="Group-2-Copy" transform="translate(0.000000, 36.000000)">
                            <path d="M273,178 C268.582032,178 265,181.583323 265,186 C265,190.419258 268.582032,194 273,194 C277.417968,194 281,190.419258 281,186 C281,181.583323 277.417968,178 273,178 Z M273,181.548387 C273.748258,181.548387 274.354839,182.154968 274.354839,182.903226 C274.354839,183.651484 273.748258,184.258065 273,184.258065 C272.251742,184.258065 271.645161,183.651484 271.645161,182.903226 C271.645161,182.154968 272.251742,181.548387 273,181.548387 Z M274.806452,189.741935 C274.806452,189.95571 274.633129,190.129032 274.419355,190.129032 L271.580645,190.129032 C271.366871,190.129032 271.193548,189.95571 271.193548,189.741935 L271.193548,188.967742 C271.193548,188.753968 271.366871,188.580645 271.580645,188.580645 L271.967742,188.580645 L271.967742,186.516129 L271.580645,186.516129 C271.366871,186.516129 271.193548,186.342806 271.193548,186.129032 L271.193548,185.354839 C271.193548,185.141065 271.366871,184.967742 271.580645,184.967742 L273.645161,184.967742 C273.858935,184.967742 274.032258,185.141065 274.032258,185.354839 L274.032258,188.580645 L274.419355,188.580645 C274.633129,188.580645 274.806452,188.753968 274.806452,188.967742 L274.806452,189.741935 Z" id="Shape"></path>
                        </g>
                    </g>
                </g>
            </g>
        </g>
    </g>
</svg>

                  
                </span>
              </td>
              <td><span class="check">&#10004;</span></td>
              <td><span class="check">&#10004;</span></td>
              <td><span class="check">&#10004;</span></td>
            </tr>
            
            <tr>
              <td>
                <span class="feature-title" data-description="Group your conference rooms by building, making it easy to search specific offices.">
                  
                  Manage multiple buildings
                  <svg width="16px" height="16px" viewbox="0 0 16 16" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">
    <g id="Pricing" stroke="none" stroke-width="1" fill-rule="evenodd">
        <g id="Pricing-/-Scheduling-/-Annual" transform="translate(-444.000000, -2072.000000)" fill-rule="nonzero">
            <g id="Feature-Table" transform="translate(0.000000, 1320.000000)">
                <g id="Group-5" transform="translate(179.000000, 538.000000)">
                    <g id="Section-4">
                        <g id="Group-2-Copy" transform="translate(0.000000, 36.000000)">
                            <path d="M273,178 C268.582032,178 265,181.583323 265,186 C265,190.419258 268.582032,194 273,194 C277.417968,194 281,190.419258 281,186 C281,181.583323 277.417968,178 273,178 Z M273,181.548387 C273.748258,181.548387 274.354839,182.154968 274.354839,182.903226 C274.354839,183.651484 273.748258,184.258065 273,184.258065 C272.251742,184.258065 271.645161,183.651484 271.645161,182.903226 C271.645161,182.154968 272.251742,181.548387 273,181.548387 Z M274.806452,189.741935 C274.806452,189.95571 274.633129,190.129032 274.419355,190.129032 L271.580645,190.129032 C271.366871,190.129032 271.193548,189.95571 271.193548,189.741935 L271.193548,188.967742 C271.193548,188.753968 271.366871,188.580645 271.580645,188.580645 L271.967742,188.580645 L271.967742,186.516129 L271.580645,186.516129 C271.366871,186.516129 271.193548,186.342806 271.193548,186.129032 L271.193548,185.354839 C271.193548,185.141065 271.366871,184.967742 271.580645,184.967742 L273.645161,184.967742 C273.858935,184.967742 274.032258,185.141065 274.032258,185.354839 L274.032258,188.580645 L274.419355,188.580645 C274.633129,188.580645 274.806452,188.753968 274.806452,188.967742 L274.806452,189.741935 Z" id="Shape"></path>
                        </g>
                    </g>
                </g>
            </g>
        </g>
    </g>
</svg>

                  
                </span>
              </td>
              <td><span class="check">&#10004;</span></td>
              <td><span class="check">&#10004;</span></td>
              <td><span class="check">&#10004;</span></td>
            </tr>
            
            <tr>
              <td>
                <span class="feature-title" data-description="Tag rooms with equipment, and then search for available space with the right tools for the job.">
                  
                  Room amenities
                  <svg width="16px" height="16px" viewbox="0 0 16 16" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">
    <g id="Pricing" stroke="none" stroke-width="1" fill-rule="evenodd">
        <g id="Pricing-/-Scheduling-/-Annual" transform="translate(-444.000000, -2072.000000)" fill-rule="nonzero">
            <g id="Feature-Table" transform="translate(0.000000, 1320.000000)">
                <g id="Group-5" transform="translate(179.000000, 538.000000)">
                    <g id="Section-4">
                        <g id="Group-2-Copy" transform="translate(0.000000, 36.000000)">
                            <path d="M273,178 C268.582032,178 265,181.583323 265,186 C265,190.419258 268.582032,194 273,194 C277.417968,194 281,190.419258 281,186 C281,181.583323 277.417968,178 273,178 Z M273,181.548387 C273.748258,181.548387 274.354839,182.154968 274.354839,182.903226 C274.354839,183.651484 273.748258,184.258065 273,184.258065 C272.251742,184.258065 271.645161,183.651484 271.645161,182.903226 C271.645161,182.154968 272.251742,181.548387 273,181.548387 Z M274.806452,189.741935 C274.806452,189.95571 274.633129,190.129032 274.419355,190.129032 L271.580645,190.129032 C271.366871,190.129032 271.193548,189.95571 271.193548,189.741935 L271.193548,188.967742 C271.193548,188.753968 271.366871,188.580645 271.580645,188.580645 L271.967742,188.580645 L271.967742,186.516129 L271.580645,186.516129 C271.366871,186.516129 271.193548,186.342806 271.193548,186.129032 L271.193548,185.354839 C271.193548,185.141065 271.366871,184.967742 271.580645,184.967742 L273.645161,184.967742 C273.858935,184.967742 274.032258,185.141065 274.032258,185.354839 L274.032258,188.580645 L274.419355,188.580645 C274.633129,188.580645 274.806452,188.753968 274.806452,188.967742 L274.806452,189.741935 Z" id="Shape"></path>
                        </g>
                    </g>
                </g>
            </g>
        </g>
    </g>
</svg>

                  
                </span>
              </td>
              <td>&mdash;</td>
              <td><span class="check">&#10004;</span></td>
              <td><span class="check">&#10004;</span></td>
            </tr>
            
            <tr>
              <td>
                <span class="feature-title" data-description="Easier support visibility with integrated issue reporting to your existing facility services + tech help desks.">
                  
                    <a href="#">
                  
                  Issue reporting
                  <svg width="16px" height="16px" viewbox="0 0 16 16" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">
    <g id="Pricing" stroke="none" stroke-width="1" fill-rule="evenodd">
        <g id="Pricing-/-Scheduling-/-Annual" transform="translate(-444.000000, -2072.000000)" fill-rule="nonzero">
            <g id="Feature-Table" transform="translate(0.000000, 1320.000000)">
                <g id="Group-5" transform="translate(179.000000, 538.000000)">
                    <g id="Section-4">
                        <g id="Group-2-Copy" transform="translate(0.000000, 36.000000)">
                            <path d="M273,178 C268.582032,178 265,181.583323 265,186 C265,190.419258 268.582032,194 273,194 C277.417968,194 281,190.419258 281,186 C281,181.583323 277.417968,178 273,178 Z M273,181.548387 C273.748258,181.548387 274.354839,182.154968 274.354839,182.903226 C274.354839,183.651484 273.748258,184.258065 273,184.258065 C272.251742,184.258065 271.645161,183.651484 271.645161,182.903226 C271.645161,182.154968 272.251742,181.548387 273,181.548387 Z M274.806452,189.741935 C274.806452,189.95571 274.633129,190.129032 274.419355,190.129032 L271.580645,190.129032 C271.366871,190.129032 271.193548,189.95571 271.193548,189.741935 L271.193548,188.967742 C271.193548,188.753968 271.366871,188.580645 271.580645,188.580645 L271.967742,188.580645 L271.967742,186.516129 L271.580645,186.516129 C271.366871,186.516129 271.193548,186.342806 271.193548,186.129032 L271.193548,185.354839 C271.193548,185.141065 271.366871,184.967742 271.580645,184.967742 L273.645161,184.967742 C273.858935,184.967742 274.032258,185.141065 274.032258,185.354839 L274.032258,188.580645 L274.419355,188.580645 C274.633129,188.580645 274.806452,188.753968 274.806452,188.967742 L274.806452,189.741935 Z" id="Shape"></path>
                        </g>
                    </g>
                </g>
            </g>
        </g>
    </g>
</svg>

                  
                    </a>
                  
                </span>
              </td>
              <td>&mdash;</td>
              <td><span class="check">&#10004;</span></td>
              <td><span class="check">&#10004;</span></td>
            </tr>
            
            <tr>
              <td>
                <span class="feature-title" data-description="Add levels within a building to help everyone find the best rooms closest to them.">
                  
                  Manage multiple levels
                  <svg width="16px" height="16px" viewbox="0 0 16 16" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">
    <g id="Pricing" stroke="none" stroke-width="1" fill-rule="evenodd">
        <g id="Pricing-/-Scheduling-/-Annual" transform="translate(-444.000000, -2072.000000)" fill-rule="nonzero">
            <g id="Feature-Table" transform="translate(0.000000, 1320.000000)">
                <g id="Group-5" transform="translate(179.000000, 538.000000)">
                    <g id="Section-4">
                        <g id="Group-2-Copy" transform="translate(0.000000, 36.000000)">
                            <path d="M273,178 C268.582032,178 265,181.583323 265,186 C265,190.419258 268.582032,194 273,194 C277.417968,194 281,190.419258 281,186 C281,181.583323 277.417968,178 273,178 Z M273,181.548387 C273.748258,181.548387 274.354839,182.154968 274.354839,182.903226 C274.354839,183.651484 273.748258,184.258065 273,184.258065 C272.251742,184.258065 271.645161,183.651484 271.645161,182.903226 C271.645161,182.154968 272.251742,181.548387 273,181.548387 Z M274.806452,189.741935 C274.806452,189.95571 274.633129,190.129032 274.419355,190.129032 L271.580645,190.129032 C271.366871,190.129032 271.193548,189.95571 271.193548,189.741935 L271.193548,188.967742 C271.193548,188.753968 271.366871,188.580645 271.580645,188.580645 L271.967742,188.580645 L271.967742,186.516129 L271.580645,186.516129 C271.366871,186.516129 271.193548,186.342806 271.193548,186.129032 L271.193548,185.354839 C271.193548,185.141065 271.366871,184.967742 271.580645,184.967742 L273.645161,184.967742 C273.858935,184.967742 274.032258,185.141065 274.032258,185.354839 L274.032258,188.580645 L274.419355,188.580645 C274.633129,188.580645 274.806452,188.753968 274.806452,188.967742 L274.806452,189.741935 Z" id="Shape"></path>
                        </g>
                    </g>
                </g>
            </g>
        </g>
    </g>
</svg>

                  
                </span>
              </td>
              <td>&mdash;</td>
              <td><span class="check">&#10004;</span></td>
              <td><span class="check">&#10004;</span></td>
            </tr>
            
            <tr>
              <td>
                <span class="feature-title" data-description="Coordinate across distinct office campuses.">
                  
                  Manage multiple campuses
                  <svg width="16px" height="16px" viewbox="0 0 16 16" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">
    <g id="Pricing" stroke="none" stroke-width="1" fill-rule="evenodd">
        <g id="Pricing-/-Scheduling-/-Annual" transform="translate(-444.000000, -2072.000000)" fill-rule="nonzero">
            <g id="Feature-Table" transform="translate(0.000000, 1320.000000)">
                <g id="Group-5" transform="translate(179.000000, 538.000000)">
                    <g id="Section-4">
                        <g id="Group-2-Copy" transform="translate(0.000000, 36.000000)">
                            <path d="M273,178 C268.582032,178 265,181.583323 265,186 C265,190.419258 268.582032,194 273,194 C277.417968,194 281,190.419258 281,186 C281,181.583323 277.417968,178 273,178 Z M273,181.548387 C273.748258,181.548387 274.354839,182.154968 274.354839,182.903226 C274.354839,183.651484 273.748258,184.258065 273,184.258065 C272.251742,184.258065 271.645161,183.651484 271.645161,182.903226 C271.645161,182.154968 272.251742,181.548387 273,181.548387 Z M274.806452,189.741935 C274.806452,189.95571 274.633129,190.129032 274.419355,190.129032 L271.580645,190.129032 C271.366871,190.129032 271.193548,189.95571 271.193548,189.741935 L271.193548,188.967742 C271.193548,188.753968 271.366871,188.580645 271.580645,188.580645 L271.967742,188.580645 L271.967742,186.516129 L271.580645,186.516129 C271.366871,186.516129 271.193548,186.342806 271.193548,186.129032 L271.193548,185.354839 C271.193548,185.141065 271.366871,184.967742 271.580645,184.967742 L273.645161,184.967742 C273.858935,184.967742 274.032258,185.141065 274.032258,185.354839 L274.032258,188.580645 L274.419355,188.580645 C274.633129,188.580645 274.806452,188.753968 274.806452,188.967742 L274.806452,189.741935 Z" id="Shape"></path>
                        </g>
                    </g>
                </g>
            </g>
        </g>
    </g>
</svg>

                  
                </span>
              </td>
              <td>&mdash;</td>
              <td>&mdash;</td>
              <td><span class="check">&#10004;</span></td>
            </tr>
            
            
          </tbody>
        
          <thead id="features-scheduling">
            <tr>
              <th>Scheduling</th>
              <th>Basic</th>
              <th>Pro</th>
              <th>Enterprise</th>
            </tr>
          </thead>
          <tbody>
            
            <tr>
              <td>
                <span class="feature-title" data-description="Syncs with your existing calendars, which your co-workers the flexibility to continue booking within Outlook or Google or Dyart.">
                  
                  Calendar integration
                  <svg width="16px" height="16px" viewbox="0 0 16 16" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">
    <g id="Pricing" stroke="none" stroke-width="1" fill-rule="evenodd">
        <g id="Pricing-/-Scheduling-/-Annual" transform="translate(-444.000000, -2072.000000)" fill-rule="nonzero">
            <g id="Feature-Table" transform="translate(0.000000, 1320.000000)">
                <g id="Group-5" transform="translate(179.000000, 538.000000)">
                    <g id="Section-4">
                        <g id="Group-2-Copy" transform="translate(0.000000, 36.000000)">
                            <path d="M273,178 C268.582032,178 265,181.583323 265,186 C265,190.419258 268.582032,194 273,194 C277.417968,194 281,190.419258 281,186 C281,181.583323 277.417968,178 273,178 Z M273,181.548387 C273.748258,181.548387 274.354839,182.154968 274.354839,182.903226 C274.354839,183.651484 273.748258,184.258065 273,184.258065 C272.251742,184.258065 271.645161,183.651484 271.645161,182.903226 C271.645161,182.154968 272.251742,181.548387 273,181.548387 Z M274.806452,189.741935 C274.806452,189.95571 274.633129,190.129032 274.419355,190.129032 L271.580645,190.129032 C271.366871,190.129032 271.193548,189.95571 271.193548,189.741935 L271.193548,188.967742 C271.193548,188.753968 271.366871,188.580645 271.580645,188.580645 L271.967742,188.580645 L271.967742,186.516129 L271.580645,186.516129 C271.366871,186.516129 271.193548,186.342806 271.193548,186.129032 L271.193548,185.354839 C271.193548,185.141065 271.366871,184.967742 271.580645,184.967742 L273.645161,184.967742 C273.858935,184.967742 274.032258,185.141065 274.032258,185.354839 L274.032258,188.580645 L274.419355,188.580645 C274.633129,188.580645 274.806452,188.753968 274.806452,188.967742 L274.806452,189.741935 Z" id="Shape"></path>
                        </g>
                    </g>
                </g>
            </g>
        </g>
    </g>
</svg>

                  
                </span>
              </td>
              <td><span class="check">&#10004;</span></td>
              <td><span class="check">&#10004;</span></td>
              <td><span class="check">&#10004;</span></td>
            </tr>
            
            <tr>
              <td>
                <span class="feature-title" data-description="Real-time availability on the big screens in your office.">
                  
                    <a href="#">
                  
                  Status Board
                  <svg width="16px" height="16px" viewbox="0 0 16 16" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">
    <g id="Pricing" stroke="none" stroke-width="1" fill-rule="evenodd">
        <g id="Pricing-/-Scheduling-/-Annual" transform="translate(-444.000000, -2072.000000)" fill-rule="nonzero">
            <g id="Feature-Table" transform="translate(0.000000, 1320.000000)">
                <g id="Group-5" transform="translate(179.000000, 538.000000)">
                    <g id="Section-4">
                        <g id="Group-2-Copy" transform="translate(0.000000, 36.000000)">
                            <path d="M273,178 C268.582032,178 265,181.583323 265,186 C265,190.419258 268.582032,194 273,194 C277.417968,194 281,190.419258 281,186 C281,181.583323 277.417968,178 273,178 Z M273,181.548387 C273.748258,181.548387 274.354839,182.154968 274.354839,182.903226 C274.354839,183.651484 273.748258,184.258065 273,184.258065 C272.251742,184.258065 271.645161,183.651484 271.645161,182.903226 C271.645161,182.154968 272.251742,181.548387 273,181.548387 Z M274.806452,189.741935 C274.806452,189.95571 274.633129,190.129032 274.419355,190.129032 L271.580645,190.129032 C271.366871,190.129032 271.193548,189.95571 271.193548,189.741935 L271.193548,188.967742 C271.193548,188.753968 271.366871,188.580645 271.580645,188.580645 L271.967742,188.580645 L271.967742,186.516129 L271.580645,186.516129 C271.366871,186.516129 271.193548,186.342806 271.193548,186.129032 L271.193548,185.354839 C271.193548,185.141065 271.366871,184.967742 271.580645,184.967742 L273.645161,184.967742 C273.858935,184.967742 274.032258,185.141065 274.032258,185.354839 L274.032258,188.580645 L274.419355,188.580645 C274.633129,188.580645 274.806452,188.753968 274.806452,188.967742 L274.806452,189.741935 Z" id="Shape"></path>
                        </g>
                    </g>
                </g>
            </g>
        </g>
    </g>
</svg>

                  
                    </a>
                  
                </span>
              </td>
              <td><span class="check">&#10004;</span></td>
              <td><span class="check">&#10004;</span></td>
              <td><span class="check">&#10004;</span></td>
            </tr>
            
            <tr>
              <td>
                <span class="feature-title" data-description="A one click install to pull in space information from Dyart into your native calendar including room size, amenities, and more for fast and efficient resource booking.">
                  
                    <a href="#">
                  
                  Browser plugins
                  <svg width="16px" height="16px" viewbox="0 0 16 16" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">
    <g id="Pricing" stroke="none" stroke-width="1" fill-rule="evenodd">
        <g id="Pricing-/-Scheduling-/-Annual" transform="translate(-444.000000, -2072.000000)" fill-rule="nonzero">
            <g id="Feature-Table" transform="translate(0.000000, 1320.000000)">
                <g id="Group-5" transform="translate(179.000000, 538.000000)">
                    <g id="Section-4">
                        <g id="Group-2-Copy" transform="translate(0.000000, 36.000000)">
                            <path d="M273,178 C268.582032,178 265,181.583323 265,186 C265,190.419258 268.582032,194 273,194 C277.417968,194 281,190.419258 281,186 C281,181.583323 277.417968,178 273,178 Z M273,181.548387 C273.748258,181.548387 274.354839,182.154968 274.354839,182.903226 C274.354839,183.651484 273.748258,184.258065 273,184.258065 C272.251742,184.258065 271.645161,183.651484 271.645161,182.903226 C271.645161,182.154968 272.251742,181.548387 273,181.548387 Z M274.806452,189.741935 C274.806452,189.95571 274.633129,190.129032 274.419355,190.129032 L271.580645,190.129032 C271.366871,190.129032 271.193548,189.95571 271.193548,189.741935 L271.193548,188.967742 C271.193548,188.753968 271.366871,188.580645 271.580645,188.580645 L271.967742,188.580645 L271.967742,186.516129 L271.580645,186.516129 C271.366871,186.516129 271.193548,186.342806 271.193548,186.129032 L271.193548,185.354839 C271.193548,185.141065 271.366871,184.967742 271.580645,184.967742 L273.645161,184.967742 C273.858935,184.967742 274.032258,185.141065 274.032258,185.354839 L274.032258,188.580645 L274.419355,188.580645 C274.633129,188.580645 274.806452,188.753968 274.806452,188.967742 L274.806452,189.741935 Z" id="Shape"></path>
                        </g>
                    </g>
                </g>
            </g>
        </g>
    </g>
</svg>

                  
                    </a>
                  
                </span>
              </td>
              <td><span class="check">&#10004;</span></td>
              <td><span class="check">&#10004;</span></td>
              <td><span class="check">&#10004;</span></td>
            </tr>
            
            <tr>
              <td>
                <span class="feature-title" data-description="Assign calendar systems on a space-by-space level, allowing offices on Google to schedule on Office 365 and vice-versa.">
                  
                  Cross-system support
                  <svg width="16px" height="16px" viewbox="0 0 16 16" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">
    <g id="Pricing" stroke="none" stroke-width="1" fill-rule="evenodd">
        <g id="Pricing-/-Scheduling-/-Annual" transform="translate(-444.000000, -2072.000000)" fill-rule="nonzero">
            <g id="Feature-Table" transform="translate(0.000000, 1320.000000)">
                <g id="Group-5" transform="translate(179.000000, 538.000000)">
                    <g id="Section-4">
                        <g id="Group-2-Copy" transform="translate(0.000000, 36.000000)">
                            <path d="M273,178 C268.582032,178 265,181.583323 265,186 C265,190.419258 268.582032,194 273,194 C277.417968,194 281,190.419258 281,186 C281,181.583323 277.417968,178 273,178 Z M273,181.548387 C273.748258,181.548387 274.354839,182.154968 274.354839,182.903226 C274.354839,183.651484 273.748258,184.258065 273,184.258065 C272.251742,184.258065 271.645161,183.651484 271.645161,182.903226 C271.645161,182.154968 272.251742,181.548387 273,181.548387 Z M274.806452,189.741935 C274.806452,189.95571 274.633129,190.129032 274.419355,190.129032 L271.580645,190.129032 C271.366871,190.129032 271.193548,189.95571 271.193548,189.741935 L271.193548,188.967742 C271.193548,188.753968 271.366871,188.580645 271.580645,188.580645 L271.967742,188.580645 L271.967742,186.516129 L271.580645,186.516129 C271.366871,186.516129 271.193548,186.342806 271.193548,186.129032 L271.193548,185.354839 C271.193548,185.141065 271.366871,184.967742 271.580645,184.967742 L273.645161,184.967742 C273.858935,184.967742 274.032258,185.141065 274.032258,185.354839 L274.032258,188.580645 L274.419355,188.580645 C274.633129,188.580645 274.806452,188.753968 274.806452,188.967742 L274.806452,189.741935 Z" id="Shape"></path>
                        </g>
                    </g>
                </g>
            </g>
        </g>
    </g>
</svg>

                  
                </span>
              </td>
              <td><span class="check">&#10004;</span></td>
              <td><span class="check">&#10004;</span></td>
              <td><span class="check">&#10004;</span></td>
            </tr>
            
            <tr>
              <td>
                <span class="feature-title" data-description="Calendars update reservations when people enter and exit meeting rooms, giving back extra time at the end.">
                  
                  Automatic room booking
                  <svg width="16px" height="16px" viewbox="0 0 16 16" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">
    <g id="Pricing" stroke="none" stroke-width="1" fill-rule="evenodd">
        <g id="Pricing-/-Scheduling-/-Annual" transform="translate(-444.000000, -2072.000000)" fill-rule="nonzero">
            <g id="Feature-Table" transform="translate(0.000000, 1320.000000)">
                <g id="Group-5" transform="translate(179.000000, 538.000000)">
                    <g id="Section-4">
                        <g id="Group-2-Copy" transform="translate(0.000000, 36.000000)">
                            <path d="M273,178 C268.582032,178 265,181.583323 265,186 C265,190.419258 268.582032,194 273,194 C277.417968,194 281,190.419258 281,186 C281,181.583323 277.417968,178 273,178 Z M273,181.548387 C273.748258,181.548387 274.354839,182.154968 274.354839,182.903226 C274.354839,183.651484 273.748258,184.258065 273,184.258065 C272.251742,184.258065 271.645161,183.651484 271.645161,182.903226 C271.645161,182.154968 272.251742,181.548387 273,181.548387 Z M274.806452,189.741935 C274.806452,189.95571 274.633129,190.129032 274.419355,190.129032 L271.580645,190.129032 C271.366871,190.129032 271.193548,189.95571 271.193548,189.741935 L271.193548,188.967742 C271.193548,188.753968 271.366871,188.580645 271.580645,188.580645 L271.967742,188.580645 L271.967742,186.516129 L271.580645,186.516129 C271.366871,186.516129 271.193548,186.342806 271.193548,186.129032 L271.193548,185.354839 C271.193548,185.141065 271.366871,184.967742 271.580645,184.967742 L273.645161,184.967742 C273.858935,184.967742 274.032258,185.141065 274.032258,185.354839 L274.032258,188.580645 L274.419355,188.580645 C274.633129,188.580645 274.806452,188.753968 274.806452,188.967742 L274.806452,189.741935 Z" id="Shape"></path>
                        </g>
                    </g>
                </g>
            </g>
        </g>
    </g>
</svg>

                  
                </span>
              </td>
              <td><span class="check">&#10004;</span></td>
              <td><span class="check">&#10004;</span></td>
              <td><span class="check">&#10004;</span></td>
            </tr>
            
            <tr>
              <td>
                <span class="feature-title" data-description="Add Dyartbot to your team chat and it will help you find free rooms at a moment's notice.">
                  
                    <a href="#">
                  
                  Slack Plugin
                  <svg width="16px" height="16px" viewbox="0 0 16 16" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">
    <g id="Pricing" stroke="none" stroke-width="1" fill-rule="evenodd">
        <g id="Pricing-/-Scheduling-/-Annual" transform="translate(-444.000000, -2072.000000)" fill-rule="nonzero">
            <g id="Feature-Table" transform="translate(0.000000, 1320.000000)">
                <g id="Group-5" transform="translate(179.000000, 538.000000)">
                    <g id="Section-4">
                        <g id="Group-2-Copy" transform="translate(0.000000, 36.000000)">
                            <path d="M273,178 C268.582032,178 265,181.583323 265,186 C265,190.419258 268.582032,194 273,194 C277.417968,194 281,190.419258 281,186 C281,181.583323 277.417968,178 273,178 Z M273,181.548387 C273.748258,181.548387 274.354839,182.154968 274.354839,182.903226 C274.354839,183.651484 273.748258,184.258065 273,184.258065 C272.251742,184.258065 271.645161,183.651484 271.645161,182.903226 C271.645161,182.154968 272.251742,181.548387 273,181.548387 Z M274.806452,189.741935 C274.806452,189.95571 274.633129,190.129032 274.419355,190.129032 L271.580645,190.129032 C271.366871,190.129032 271.193548,189.95571 271.193548,189.741935 L271.193548,188.967742 C271.193548,188.753968 271.366871,188.580645 271.580645,188.580645 L271.967742,188.580645 L271.967742,186.516129 L271.580645,186.516129 C271.366871,186.516129 271.193548,186.342806 271.193548,186.129032 L271.193548,185.354839 C271.193548,185.141065 271.366871,184.967742 271.580645,184.967742 L273.645161,184.967742 C273.858935,184.967742 274.032258,185.141065 274.032258,185.354839 L274.032258,188.580645 L274.419355,188.580645 C274.633129,188.580645 274.806452,188.753968 274.806452,188.967742 L274.806452,189.741935 Z" id="Shape"></path>
                        </g>
                    </g>
                </g>
            </g>
        </g>
    </g>
</svg>

                  
                    </a>
                  
                </span>
              </td>
              <td><span class="check">&#10004;</span></td>
              <td><span class="check">&#10004;</span></td>
              <td><span class="check">&#10004;</span></td>
            </tr>
            
            <tr>
              <td>
                <span class="feature-title" data-description="Dyart spaces can use beacons to let the mobile app know when you're nearby. Once a room knows you're there, it updates your team and calendars automatically.">
                  
                    <a href="#">
                  
                  Presence
                  <svg width="16px" height="16px" viewbox="0 0 16 16" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">
    <g id="Pricing" stroke="none" stroke-width="1" fill-rule="evenodd">
        <g id="Pricing-/-Scheduling-/-Annual" transform="translate(-444.000000, -2072.000000)" fill-rule="nonzero">
            <g id="Feature-Table" transform="translate(0.000000, 1320.000000)">
                <g id="Group-5" transform="translate(179.000000, 538.000000)">
                    <g id="Section-4">
                        <g id="Group-2-Copy" transform="translate(0.000000, 36.000000)">
                            <path d="M273,178 C268.582032,178 265,181.583323 265,186 C265,190.419258 268.582032,194 273,194 C277.417968,194 281,190.419258 281,186 C281,181.583323 277.417968,178 273,178 Z M273,181.548387 C273.748258,181.548387 274.354839,182.154968 274.354839,182.903226 C274.354839,183.651484 273.748258,184.258065 273,184.258065 C272.251742,184.258065 271.645161,183.651484 271.645161,182.903226 C271.645161,182.154968 272.251742,181.548387 273,181.548387 Z M274.806452,189.741935 C274.806452,189.95571 274.633129,190.129032 274.419355,190.129032 L271.580645,190.129032 C271.366871,190.129032 271.193548,189.95571 271.193548,189.741935 L271.193548,188.967742 C271.193548,188.753968 271.366871,188.580645 271.580645,188.580645 L271.967742,188.580645 L271.967742,186.516129 L271.580645,186.516129 C271.366871,186.516129 271.193548,186.342806 271.193548,186.129032 L271.193548,185.354839 C271.193548,185.141065 271.366871,184.967742 271.580645,184.967742 L273.645161,184.967742 C273.858935,184.967742 274.032258,185.141065 274.032258,185.354839 L274.032258,188.580645 L274.419355,188.580645 C274.633129,188.580645 274.806452,188.753968 274.806452,188.967742 L274.806452,189.741935 Z" id="Shape"></path>
                        </g>
                    </g>
                </g>
            </g>
        </g>
    </g>
</svg>

                  
                    </a>
                  
                </span>
              </td>
              <td><span class="check">&#10004;</span></td>
              <td><span class="check">&#10004;</span></td>
              <td><span class="check">&#10004;</span></td>
            </tr>
            
            <tr>
              <td>
                <span class="feature-title" data-description="Limit scheduling of high value rooms to just administrators.">
                  
                  Restricted booking
                  <svg width="16px" height="16px" viewbox="0 0 16 16" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">
    <g id="Pricing" stroke="none" stroke-width="1" fill-rule="evenodd">
        <g id="Pricing-/-Scheduling-/-Annual" transform="translate(-444.000000, -2072.000000)" fill-rule="nonzero">
            <g id="Feature-Table" transform="translate(0.000000, 1320.000000)">
                <g id="Group-5" transform="translate(179.000000, 538.000000)">
                    <g id="Section-4">
                        <g id="Group-2-Copy" transform="translate(0.000000, 36.000000)">
                            <path d="M273,178 C268.582032,178 265,181.583323 265,186 C265,190.419258 268.582032,194 273,194 C277.417968,194 281,190.419258 281,186 C281,181.583323 277.417968,178 273,178 Z M273,181.548387 C273.748258,181.548387 274.354839,182.154968 274.354839,182.903226 C274.354839,183.651484 273.748258,184.258065 273,184.258065 C272.251742,184.258065 271.645161,183.651484 271.645161,182.903226 C271.645161,182.154968 272.251742,181.548387 273,181.548387 Z M274.806452,189.741935 C274.806452,189.95571 274.633129,190.129032 274.419355,190.129032 L271.580645,190.129032 C271.366871,190.129032 271.193548,189.95571 271.193548,189.741935 L271.193548,188.967742 C271.193548,188.753968 271.366871,188.580645 271.580645,188.580645 L271.967742,188.580645 L271.967742,186.516129 L271.580645,186.516129 C271.366871,186.516129 271.193548,186.342806 271.193548,186.129032 L271.193548,185.354839 C271.193548,185.141065 271.366871,184.967742 271.580645,184.967742 L273.645161,184.967742 C273.858935,184.967742 274.032258,185.141065 274.032258,185.354839 L274.032258,188.580645 L274.419355,188.580645 C274.633129,188.580645 274.806452,188.753968 274.806452,188.967742 L274.806452,189.741935 Z" id="Shape"></path>
                        </g>
                    </g>
                </g>
            </g>
        </g>
    </g>
</svg>

                  
                </span>
              </td>
              <td>&mdash;</td>
              <td><span class="check">&#10004;</span></td>
              <td><span class="check">&#10004;</span></td>
            </tr>
            
            <tr>
              <td>
                <span class="feature-title" data-description="Calendars update reservations when people enter and exit meeting rooms, giving back extra time at the end.">
                  
                  Automatic room booking
                  <svg width="16px" height="16px" viewbox="0 0 16 16" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">
    <g id="Pricing" stroke="none" stroke-width="1" fill-rule="evenodd">
        <g id="Pricing-/-Scheduling-/-Annual" transform="translate(-444.000000, -2072.000000)" fill-rule="nonzero">
            <g id="Feature-Table" transform="translate(0.000000, 1320.000000)">
                <g id="Group-5" transform="translate(179.000000, 538.000000)">
                    <g id="Section-4">
                        <g id="Group-2-Copy" transform="translate(0.000000, 36.000000)">
                            <path d="M273,178 C268.582032,178 265,181.583323 265,186 C265,190.419258 268.582032,194 273,194 C277.417968,194 281,190.419258 281,186 C281,181.583323 277.417968,178 273,178 Z M273,181.548387 C273.748258,181.548387 274.354839,182.154968 274.354839,182.903226 C274.354839,183.651484 273.748258,184.258065 273,184.258065 C272.251742,184.258065 271.645161,183.651484 271.645161,182.903226 C271.645161,182.154968 272.251742,181.548387 273,181.548387 Z M274.806452,189.741935 C274.806452,189.95571 274.633129,190.129032 274.419355,190.129032 L271.580645,190.129032 C271.366871,190.129032 271.193548,189.95571 271.193548,189.741935 L271.193548,188.967742 C271.193548,188.753968 271.366871,188.580645 271.580645,188.580645 L271.967742,188.580645 L271.967742,186.516129 L271.580645,186.516129 C271.366871,186.516129 271.193548,186.342806 271.193548,186.129032 L271.193548,185.354839 C271.193548,185.141065 271.366871,184.967742 271.580645,184.967742 L273.645161,184.967742 C273.858935,184.967742 274.032258,185.141065 274.032258,185.354839 L274.032258,188.580645 L274.419355,188.580645 C274.633129,188.580645 274.806452,188.753968 274.806452,188.967742 L274.806452,189.741935 Z" id="Shape"></path>
                        </g>
                    </g>
                </g>
            </g>
        </g>
    </g>
</svg>

                  
                </span>
              </td>
              <td>&mdash;</td>
              <td><span class="check">&#10004;</span></td>
              <td><span class="check">&#10004;</span></td>
            </tr>
            
            <tr>
              <td>
                <span class="feature-title" data-description="Add indoor maps and wayfinding to Dyart and get turn by turn directions to your next meeting.">
                  
                  Aruba Meridian
                  <svg width="16px" height="16px" viewbox="0 0 16 16" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">
    <g id="Pricing" stroke="none" stroke-width="1" fill-rule="evenodd">
        <g id="Pricing-/-Scheduling-/-Annual" transform="translate(-444.000000, -2072.000000)" fill-rule="nonzero">
            <g id="Feature-Table" transform="translate(0.000000, 1320.000000)">
                <g id="Group-5" transform="translate(179.000000, 538.000000)">
                    <g id="Section-4">
                        <g id="Group-2-Copy" transform="translate(0.000000, 36.000000)">
                            <path d="M273,178 C268.582032,178 265,181.583323 265,186 C265,190.419258 268.582032,194 273,194 C277.417968,194 281,190.419258 281,186 C281,181.583323 277.417968,178 273,178 Z M273,181.548387 C273.748258,181.548387 274.354839,182.154968 274.354839,182.903226 C274.354839,183.651484 273.748258,184.258065 273,184.258065 C272.251742,184.258065 271.645161,183.651484 271.645161,182.903226 C271.645161,182.154968 272.251742,181.548387 273,181.548387 Z M274.806452,189.741935 C274.806452,189.95571 274.633129,190.129032 274.419355,190.129032 L271.580645,190.129032 C271.366871,190.129032 271.193548,189.95571 271.193548,189.741935 L271.193548,188.967742 C271.193548,188.753968 271.366871,188.580645 271.580645,188.580645 L271.967742,188.580645 L271.967742,186.516129 L271.580645,186.516129 C271.366871,186.516129 271.193548,186.342806 271.193548,186.129032 L271.193548,185.354839 C271.193548,185.141065 271.366871,184.967742 271.580645,184.967742 L273.645161,184.967742 C273.858935,184.967742 274.032258,185.141065 274.032258,185.354839 L274.032258,188.580645 L274.419355,188.580645 C274.633129,188.580645 274.806452,188.753968 274.806452,188.967742 L274.806452,189.741935 Z" id="Shape"></path>
                        </g>
                    </g>
                </g>
            </g>
        </g>
    </g>
</svg>

                  
                </span>
              </td>
              <td>&mdash;</td>
              <td>&mdash;</td>
              <td><span class="check">&#10004;</span></td>
            </tr>
            
            
          </tbody>
        
          <!-- <thead id="features-desks">
            <tr>
              <th>Desks</th>
              <th>Basic</th>
              <th>Pro</th>
              <th>Enterprise</th>
            </tr>
          </thead> -->
          <!-- <tbody>
            
            <tr>
              <td>
                <span class="feature-title" data-description="Assign your coworkers seats in the office">
                  
                  Seat assignments
                  <svg width="16px" height="16px" viewbox="0 0 16 16" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">
    <g id="Pricing" stroke="none" stroke-width="1" fill-rule="evenodd">
        <g id="Pricing-/-Scheduling-/-Annual" transform="translate(-444.000000, -2072.000000)" fill-rule="nonzero">
            <g id="Feature-Table" transform="translate(0.000000, 1320.000000)">
                <g id="Group-5" transform="translate(179.000000, 538.000000)">
                    <g id="Section-4">
                        <g id="Group-2-Copy" transform="translate(0.000000, 36.000000)">
                            <path d="M273,178 C268.582032,178 265,181.583323 265,186 C265,190.419258 268.582032,194 273,194 C277.417968,194 281,190.419258 281,186 C281,181.583323 277.417968,178 273,178 Z M273,181.548387 C273.748258,181.548387 274.354839,182.154968 274.354839,182.903226 C274.354839,183.651484 273.748258,184.258065 273,184.258065 C272.251742,184.258065 271.645161,183.651484 271.645161,182.903226 C271.645161,182.154968 272.251742,181.548387 273,181.548387 Z M274.806452,189.741935 C274.806452,189.95571 274.633129,190.129032 274.419355,190.129032 L271.580645,190.129032 C271.366871,190.129032 271.193548,189.95571 271.193548,189.741935 L271.193548,188.967742 C271.193548,188.753968 271.366871,188.580645 271.580645,188.580645 L271.967742,188.580645 L271.967742,186.516129 L271.580645,186.516129 C271.366871,186.516129 271.193548,186.342806 271.193548,186.129032 L271.193548,185.354839 C271.193548,185.141065 271.366871,184.967742 271.580645,184.967742 L273.645161,184.967742 C273.858935,184.967742 274.032258,185.141065 274.032258,185.354839 L274.032258,188.580645 L274.419355,188.580645 C274.633129,188.580645 274.806452,188.753968 274.806452,188.967742 L274.806452,189.741935 Z" id="Shape"/>
                        </g>
                    </g>
                </g>
            </g>
        </g>
    </g>
</svg>

                  
                </span>
              </td>
              <td><span class="check">&#10004;</span></td>
              <td><span class="check">&#10004;</span></td>
              <td><span class="check">&#10004;</span></td>
            </tr>
            
            <tr>
              <td>
                <span class="feature-title" data-description="Real-time availability on the big screens in your office.">
                  
                    <a href="#">
                  
                  Status Board
                  <svg width="16px" height="16px" viewbox="0 0 16 16" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">
    <g id="Pricing" stroke="none" stroke-width="1" fill-rule="evenodd">
        <g id="Pricing-/-Scheduling-/-Annual" transform="translate(-444.000000, -2072.000000)" fill-rule="nonzero">
            <g id="Feature-Table" transform="translate(0.000000, 1320.000000)">
                <g id="Group-5" transform="translate(179.000000, 538.000000)">
                    <g id="Section-4">
                        <g id="Group-2-Copy" transform="translate(0.000000, 36.000000)">
                            <path d="M273,178 C268.582032,178 265,181.583323 265,186 C265,190.419258 268.582032,194 273,194 C277.417968,194 281,190.419258 281,186 C281,181.583323 277.417968,178 273,178 Z M273,181.548387 C273.748258,181.548387 274.354839,182.154968 274.354839,182.903226 C274.354839,183.651484 273.748258,184.258065 273,184.258065 C272.251742,184.258065 271.645161,183.651484 271.645161,182.903226 C271.645161,182.154968 272.251742,181.548387 273,181.548387 Z M274.806452,189.741935 C274.806452,189.95571 274.633129,190.129032 274.419355,190.129032 L271.580645,190.129032 C271.366871,190.129032 271.193548,189.95571 271.193548,189.741935 L271.193548,188.967742 C271.193548,188.753968 271.366871,188.580645 271.580645,188.580645 L271.967742,188.580645 L271.967742,186.516129 L271.580645,186.516129 C271.366871,186.516129 271.193548,186.342806 271.193548,186.129032 L271.193548,185.354839 C271.193548,185.141065 271.366871,184.967742 271.580645,184.967742 L273.645161,184.967742 C273.858935,184.967742 274.032258,185.141065 274.032258,185.354839 L274.032258,188.580645 L274.419355,188.580645 C274.633129,188.580645 274.806452,188.753968 274.806452,188.967742 L274.806452,189.741935 Z" id="Shape"/>
                        </g>
                    </g>
                </g>
            </g>
        </g>
    </g>
</svg>

                  
                    </a>
                  
                </span>
              </td>
              <td><span class="check">&#10004;</span></td>
              <td><span class="check">&#10004;</span></td>
              <td><span class="check">&#10004;</span></td>
            </tr>
            
            <tr>
              <td>
                <span class="feature-title" data-description="A one click install to pull in space information from Dyart into your native calendar including room size, amenities, and more for fast and efficient resource booking.">
                  
                    <a href="#">
                  
                  Browser plugins
                  <svg width="16px" height="16px" viewbox="0 0 16 16" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">
    <g id="Pricing" stroke="none" stroke-width="1" fill-rule="evenodd">
        <g id="Pricing-/-Scheduling-/-Annual" transform="translate(-444.000000, -2072.000000)" fill-rule="nonzero">
            <g id="Feature-Table" transform="translate(0.000000, 1320.000000)">
                <g id="Group-5" transform="translate(179.000000, 538.000000)">
                    <g id="Section-4">
                        <g id="Group-2-Copy" transform="translate(0.000000, 36.000000)">
                            <path d="M273,178 C268.582032,178 265,181.583323 265,186 C265,190.419258 268.582032,194 273,194 C277.417968,194 281,190.419258 281,186 C281,181.583323 277.417968,178 273,178 Z M273,181.548387 C273.748258,181.548387 274.354839,182.154968 274.354839,182.903226 C274.354839,183.651484 273.748258,184.258065 273,184.258065 C272.251742,184.258065 271.645161,183.651484 271.645161,182.903226 C271.645161,182.154968 272.251742,181.548387 273,181.548387 Z M274.806452,189.741935 C274.806452,189.95571 274.633129,190.129032 274.419355,190.129032 L271.580645,190.129032 C271.366871,190.129032 271.193548,189.95571 271.193548,189.741935 L271.193548,188.967742 C271.193548,188.753968 271.366871,188.580645 271.580645,188.580645 L271.967742,188.580645 L271.967742,186.516129 L271.580645,186.516129 C271.366871,186.516129 271.193548,186.342806 271.193548,186.129032 L271.193548,185.354839 C271.193548,185.141065 271.366871,184.967742 271.580645,184.967742 L273.645161,184.967742 C273.858935,184.967742 274.032258,185.141065 274.032258,185.354839 L274.032258,188.580645 L274.419355,188.580645 C274.633129,188.580645 274.806452,188.753968 274.806452,188.967742 L274.806452,189.741935 Z" id="Shape"/>
                        </g>
                    </g>
                </g>
            </g>
        </g>
    </g>
</svg>

                  
                    </a>
                  
                </span>
              </td>
              <td><span class="check">&#10004;</span></td>
              <td><span class="check">&#10004;</span></td>
              <td><span class="check">&#10004;</span></td>
            </tr>
            
            <tr>
              <td>
                <span class="feature-title" data-description="Assign calendar systems on a space-by-space level, allowing offices on Google to schedule on Office 365 and vice-versa.">
                  
                  Cross-system support
                  <svg width="16px" height="16px" viewbox="0 0 16 16" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">
    <g id="Pricing" stroke="none" stroke-width="1" fill-rule="evenodd">
        <g id="Pricing-/-Scheduling-/-Annual" transform="translate(-444.000000, -2072.000000)" fill-rule="nonzero">
            <g id="Feature-Table" transform="translate(0.000000, 1320.000000)">
                <g id="Group-5" transform="translate(179.000000, 538.000000)">
                    <g id="Section-4">
                        <g id="Group-2-Copy" transform="translate(0.000000, 36.000000)">
                            <path d="M273,178 C268.582032,178 265,181.583323 265,186 C265,190.419258 268.582032,194 273,194 C277.417968,194 281,190.419258 281,186 C281,181.583323 277.417968,178 273,178 Z M273,181.548387 C273.748258,181.548387 274.354839,182.154968 274.354839,182.903226 C274.354839,183.651484 273.748258,184.258065 273,184.258065 C272.251742,184.258065 271.645161,183.651484 271.645161,182.903226 C271.645161,182.154968 272.251742,181.548387 273,181.548387 Z M274.806452,189.741935 C274.806452,189.95571 274.633129,190.129032 274.419355,190.129032 L271.580645,190.129032 C271.366871,190.129032 271.193548,189.95571 271.193548,189.741935 L271.193548,188.967742 C271.193548,188.753968 271.366871,188.580645 271.580645,188.580645 L271.967742,188.580645 L271.967742,186.516129 L271.580645,186.516129 C271.366871,186.516129 271.193548,186.342806 271.193548,186.129032 L271.193548,185.354839 C271.193548,185.141065 271.366871,184.967742 271.580645,184.967742 L273.645161,184.967742 C273.858935,184.967742 274.032258,185.141065 274.032258,185.354839 L274.032258,188.580645 L274.419355,188.580645 C274.633129,188.580645 274.806452,188.753968 274.806452,188.967742 L274.806452,189.741935 Z" id="Shape"/>
                        </g>
                    </g>
                </g>
            </g>
        </g>
    </g>
</svg>

                  
                </span>
              </td>
              <td><span class="check">&#10004;</span></td>
              <td><span class="check">&#10004;</span></td>
              <td><span class="check">&#10004;</span></td>
            </tr>
            
            
          </tbody>
        -->
          <thead id="features-room-display">
            <tr>
              <th>Room Display</th>
              <th>Basic</th>
              <th>Pro</th>
              <th>Enterprise</th>
            </tr>
          </thead>
          <tbody>
            
            <tr>
              <td>
                <span class="feature-title" data-description="Dyart runs on all modern tablets. You can use what you already have, even mix and match platforms.">
                  
                  iPad and Android apps
                  <svg width="16px" height="16px" viewbox="0 0 16 16" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">
    <g id="Pricing" stroke="none" stroke-width="1" fill-rule="evenodd">
        <g id="Pricing-/-Scheduling-/-Annual" transform="translate(-444.000000, -2072.000000)" fill-rule="nonzero">
            <g id="Feature-Table" transform="translate(0.000000, 1320.000000)">
                <g id="Group-5" transform="translate(179.000000, 538.000000)">
                    <g id="Section-4">
                        <g id="Group-2-Copy" transform="translate(0.000000, 36.000000)">
                            <path d="M273,178 C268.582032,178 265,181.583323 265,186 C265,190.419258 268.582032,194 273,194 C277.417968,194 281,190.419258 281,186 C281,181.583323 277.417968,178 273,178 Z M273,181.548387 C273.748258,181.548387 274.354839,182.154968 274.354839,182.903226 C274.354839,183.651484 273.748258,184.258065 273,184.258065 C272.251742,184.258065 271.645161,183.651484 271.645161,182.903226 C271.645161,182.154968 272.251742,181.548387 273,181.548387 Z M274.806452,189.741935 C274.806452,189.95571 274.633129,190.129032 274.419355,190.129032 L271.580645,190.129032 C271.366871,190.129032 271.193548,189.95571 271.193548,189.741935 L271.193548,188.967742 C271.193548,188.753968 271.366871,188.580645 271.580645,188.580645 L271.967742,188.580645 L271.967742,186.516129 L271.580645,186.516129 C271.366871,186.516129 271.193548,186.342806 271.193548,186.129032 L271.193548,185.354839 C271.193548,185.141065 271.366871,184.967742 271.580645,184.967742 L273.645161,184.967742 C273.858935,184.967742 274.032258,185.141065 274.032258,185.354839 L274.032258,188.580645 L274.419355,188.580645 C274.633129,188.580645 274.806452,188.753968 274.806452,188.967742 L274.806452,189.741935 Z" id="Shape"></path>
                        </g>
                    </g>
                </g>
            </g>
        </g>
    </g>
</svg>

                  
                </span>
              </td>
              <td><span class="check">&#10004;</span></td>
              <td><span class="check">&#10004;</span></td>
              <td><span class="check">&#10004;</span></td>
            </tr>
            
            <tr>
              <td>
                <span class="feature-title" data-description="When the room is free, you can start a new meeting in one tap.">
                  
                  Start impromptu meetings
                  <svg width="16px" height="16px" viewbox="0 0 16 16" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">
    <g id="Pricing" stroke="none" stroke-width="1" fill-rule="evenodd">
        <g id="Pricing-/-Scheduling-/-Annual" transform="translate(-444.000000, -2072.000000)" fill-rule="nonzero">
            <g id="Feature-Table" transform="translate(0.000000, 1320.000000)">
                <g id="Group-5" transform="translate(179.000000, 538.000000)">
                    <g id="Section-4">
                        <g id="Group-2-Copy" transform="translate(0.000000, 36.000000)">
                            <path d="M273,178 C268.582032,178 265,181.583323 265,186 C265,190.419258 268.582032,194 273,194 C277.417968,194 281,190.419258 281,186 C281,181.583323 277.417968,178 273,178 Z M273,181.548387 C273.748258,181.548387 274.354839,182.154968 274.354839,182.903226 C274.354839,183.651484 273.748258,184.258065 273,184.258065 C272.251742,184.258065 271.645161,183.651484 271.645161,182.903226 C271.645161,182.154968 272.251742,181.548387 273,181.548387 Z M274.806452,189.741935 C274.806452,189.95571 274.633129,190.129032 274.419355,190.129032 L271.580645,190.129032 C271.366871,190.129032 271.193548,189.95571 271.193548,189.741935 L271.193548,188.967742 C271.193548,188.753968 271.366871,188.580645 271.580645,188.580645 L271.967742,188.580645 L271.967742,186.516129 L271.580645,186.516129 C271.366871,186.516129 271.193548,186.342806 271.193548,186.129032 L271.193548,185.354839 C271.193548,185.141065 271.366871,184.967742 271.580645,184.967742 L273.645161,184.967742 C273.858935,184.967742 274.032258,185.141065 274.032258,185.354839 L274.032258,188.580645 L274.419355,188.580645 C274.633129,188.580645 274.806452,188.753968 274.806452,188.967742 L274.806452,189.741935 Z" id="Shape"></path>
                        </g>
                    </g>
                </g>
            </g>
        </g>
    </g>
</svg>

                  
                </span>
              </td>
              <td><span class="check">&#10004;</span></td>
              <td><span class="check">&#10004;</span></td>
              <td><span class="check">&#10004;</span></td>
            </tr>
            
            <tr>
              <td>
                <span class="feature-title" data-description="Enable check-ins to make sure only meetings that actually happen stay on the schedule.">
                  
                  Remove abandoned meetings
                  <svg width="16px" height="16px" viewbox="0 0 16 16" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">
    <g id="Pricing" stroke="none" stroke-width="1" fill-rule="evenodd">
        <g id="Pricing-/-Scheduling-/-Annual" transform="translate(-444.000000, -2072.000000)" fill-rule="nonzero">
            <g id="Feature-Table" transform="translate(0.000000, 1320.000000)">
                <g id="Group-5" transform="translate(179.000000, 538.000000)">
                    <g id="Section-4">
                        <g id="Group-2-Copy" transform="translate(0.000000, 36.000000)">
                            <path d="M273,178 C268.582032,178 265,181.583323 265,186 C265,190.419258 268.582032,194 273,194 C277.417968,194 281,190.419258 281,186 C281,181.583323 277.417968,178 273,178 Z M273,181.548387 C273.748258,181.548387 274.354839,182.154968 274.354839,182.903226 C274.354839,183.651484 273.748258,184.258065 273,184.258065 C272.251742,184.258065 271.645161,183.651484 271.645161,182.903226 C271.645161,182.154968 272.251742,181.548387 273,181.548387 Z M274.806452,189.741935 C274.806452,189.95571 274.633129,190.129032 274.419355,190.129032 L271.580645,190.129032 C271.366871,190.129032 271.193548,189.95571 271.193548,189.741935 L271.193548,188.967742 C271.193548,188.753968 271.366871,188.580645 271.580645,188.580645 L271.967742,188.580645 L271.967742,186.516129 L271.580645,186.516129 C271.366871,186.516129 271.193548,186.342806 271.193548,186.129032 L271.193548,185.354839 C271.193548,185.141065 271.366871,184.967742 271.580645,184.967742 L273.645161,184.967742 C273.858935,184.967742 274.032258,185.141065 274.032258,185.354839 L274.032258,188.580645 L274.419355,188.580645 C274.633129,188.580645 274.806452,188.753968 274.806452,188.967742 L274.806452,189.741935 Z" id="Shape"></path>
                        </g>
                    </g>
                </g>
            </g>
        </g>
    </g>
</svg>

                  
                </span>
              </td>
              <td><span class="check">&#10004;</span></td>
              <td><span class="check">&#10004;</span></td>
              <td><span class="check">&#10004;</span></td>
            </tr>
            
            <tr>
              <td>
                <span class="feature-title" data-description="Full room-level control over meeting details visibility.">
                  
                  Meeting privacy
                  <svg width="16px" height="16px" viewbox="0 0 16 16" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">
    <g id="Pricing" stroke="none" stroke-width="1" fill-rule="evenodd">
        <g id="Pricing-/-Scheduling-/-Annual" transform="translate(-444.000000, -2072.000000)" fill-rule="nonzero">
            <g id="Feature-Table" transform="translate(0.000000, 1320.000000)">
                <g id="Group-5" transform="translate(179.000000, 538.000000)">
                    <g id="Section-4">
                        <g id="Group-2-Copy" transform="translate(0.000000, 36.000000)">
                            <path d="M273,178 C268.582032,178 265,181.583323 265,186 C265,190.419258 268.582032,194 273,194 C277.417968,194 281,190.419258 281,186 C281,181.583323 277.417968,178 273,178 Z M273,181.548387 C273.748258,181.548387 274.354839,182.154968 274.354839,182.903226 C274.354839,183.651484 273.748258,184.258065 273,184.258065 C272.251742,184.258065 271.645161,183.651484 271.645161,182.903226 C271.645161,182.154968 272.251742,181.548387 273,181.548387 Z M274.806452,189.741935 C274.806452,189.95571 274.633129,190.129032 274.419355,190.129032 L271.580645,190.129032 C271.366871,190.129032 271.193548,189.95571 271.193548,189.741935 L271.193548,188.967742 C271.193548,188.753968 271.366871,188.580645 271.580645,188.580645 L271.967742,188.580645 L271.967742,186.516129 L271.580645,186.516129 C271.366871,186.516129 271.193548,186.342806 271.193548,186.129032 L271.193548,185.354839 C271.193548,185.141065 271.366871,184.967742 271.580645,184.967742 L273.645161,184.967742 C273.858935,184.967742 274.032258,185.141065 274.032258,185.354839 L274.032258,188.580645 L274.419355,188.580645 C274.633129,188.580645 274.806452,188.753968 274.806452,188.967742 L274.806452,189.741935 Z" id="Shape"></path>
                        </g>
                    </g>
                </g>
            </g>
        </g>
    </g>
</svg>

                  
                </span>
              </td>
              <td><span class="check">&#10004;</span></td>
              <td><span class="check">&#10004;</span></td>
              <td><span class="check">&#10004;</span></td>
            </tr>
            
            <tr>
              <td>
                <span class="feature-title" data-description="Update settings in one place, and push changes to all room displays instantly. Notifications (coming soon) let admins know when devices are offline.">
                  
                  Remote device management
                  <svg width="16px" height="16px" viewbox="0 0 16 16" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">
    <g id="Pricing" stroke="none" stroke-width="1" fill-rule="evenodd">
        <g id="Pricing-/-Scheduling-/-Annual" transform="translate(-444.000000, -2072.000000)" fill-rule="nonzero">
            <g id="Feature-Table" transform="translate(0.000000, 1320.000000)">
                <g id="Group-5" transform="translate(179.000000, 538.000000)">
                    <g id="Section-4">
                        <g id="Group-2-Copy" transform="translate(0.000000, 36.000000)">
                            <path d="M273,178 C268.582032,178 265,181.583323 265,186 C265,190.419258 268.582032,194 273,194 C277.417968,194 281,190.419258 281,186 C281,181.583323 277.417968,178 273,178 Z M273,181.548387 C273.748258,181.548387 274.354839,182.154968 274.354839,182.903226 C274.354839,183.651484 273.748258,184.258065 273,184.258065 C272.251742,184.258065 271.645161,183.651484 271.645161,182.903226 C271.645161,182.154968 272.251742,181.548387 273,181.548387 Z M274.806452,189.741935 C274.806452,189.95571 274.633129,190.129032 274.419355,190.129032 L271.580645,190.129032 C271.366871,190.129032 271.193548,189.95571 271.193548,189.741935 L271.193548,188.967742 C271.193548,188.753968 271.366871,188.580645 271.580645,188.580645 L271.967742,188.580645 L271.967742,186.516129 L271.580645,186.516129 C271.366871,186.516129 271.193548,186.342806 271.193548,186.129032 L271.193548,185.354839 C271.193548,185.141065 271.366871,184.967742 271.580645,184.967742 L273.645161,184.967742 C273.858935,184.967742 274.032258,185.141065 274.032258,185.354839 L274.032258,188.580645 L274.419355,188.580645 C274.633129,188.580645 274.806452,188.753968 274.806452,188.967742 L274.806452,189.741935 Z" id="Shape"></path>
                        </g>
                    </g>
                </g>
            </g>
        </g>
    </g>
</svg>

                  
                </span>
              </td>
              <td><span class="check">&#10004;</span></td>
              <td><span class="check">&#10004;</span></td>
              <td><span class="check">&#10004;</span></td>
            </tr>
            
            <tr>
              <td>
                <span class="feature-title" data-description="Integrates with your MDM provider for easy deployment and management of your fleet.">
                  
                  MDM integration
                  <svg width="16px" height="16px" viewbox="0 0 16 16" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">
    <g id="Pricing" stroke="none" stroke-width="1" fill-rule="evenodd">
        <g id="Pricing-/-Scheduling-/-Annual" transform="translate(-444.000000, -2072.000000)" fill-rule="nonzero">
            <g id="Feature-Table" transform="translate(0.000000, 1320.000000)">
                <g id="Group-5" transform="translate(179.000000, 538.000000)">
                    <g id="Section-4">
                        <g id="Group-2-Copy" transform="translate(0.000000, 36.000000)">
                            <path d="M273,178 C268.582032,178 265,181.583323 265,186 C265,190.419258 268.582032,194 273,194 C277.417968,194 281,190.419258 281,186 C281,181.583323 277.417968,178 273,178 Z M273,181.548387 C273.748258,181.548387 274.354839,182.154968 274.354839,182.903226 C274.354839,183.651484 273.748258,184.258065 273,184.258065 C272.251742,184.258065 271.645161,183.651484 271.645161,182.903226 C271.645161,182.154968 272.251742,181.548387 273,181.548387 Z M274.806452,189.741935 C274.806452,189.95571 274.633129,190.129032 274.419355,190.129032 L271.580645,190.129032 C271.366871,190.129032 271.193548,189.95571 271.193548,189.741935 L271.193548,188.967742 C271.193548,188.753968 271.366871,188.580645 271.580645,188.580645 L271.967742,188.580645 L271.967742,186.516129 L271.580645,186.516129 C271.366871,186.516129 271.193548,186.342806 271.193548,186.129032 L271.193548,185.354839 C271.193548,185.141065 271.366871,184.967742 271.580645,184.967742 L273.645161,184.967742 C273.858935,184.967742 274.032258,185.141065 274.032258,185.354839 L274.032258,188.580645 L274.419355,188.580645 C274.633129,188.580645 274.806452,188.753968 274.806452,188.967742 L274.806452,189.741935 Z" id="Shape"></path>
                        </g>
                    </g>
                </g>
            </g>
        </g>
    </g>
</svg>

                  
                </span>
              </td>
              <td><span class="check">&#10004;</span></td>
              <td><span class="check">&#10004;</span></td>
              <td><span class="check">&#10004;</span></td>
            </tr>
            
            <tr>
              <td>
                <span class="feature-title" data-description="For enhanced visibility, Rooms supports integration with most LED cases.">
                  
                  LED case support
                  <svg width="16px" height="16px" viewbox="0 0 16 16" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">
    <g id="Pricing" stroke="none" stroke-width="1" fill-rule="evenodd">
        <g id="Pricing-/-Scheduling-/-Annual" transform="translate(-444.000000, -2072.000000)" fill-rule="nonzero">
            <g id="Feature-Table" transform="translate(0.000000, 1320.000000)">
                <g id="Group-5" transform="translate(179.000000, 538.000000)">
                    <g id="Section-4">
                        <g id="Group-2-Copy" transform="translate(0.000000, 36.000000)">
                            <path d="M273,178 C268.582032,178 265,181.583323 265,186 C265,190.419258 268.582032,194 273,194 C277.417968,194 281,190.419258 281,186 C281,181.583323 277.417968,178 273,178 Z M273,181.548387 C273.748258,181.548387 274.354839,182.154968 274.354839,182.903226 C274.354839,183.651484 273.748258,184.258065 273,184.258065 C272.251742,184.258065 271.645161,183.651484 271.645161,182.903226 C271.645161,182.154968 272.251742,181.548387 273,181.548387 Z M274.806452,189.741935 C274.806452,189.95571 274.633129,190.129032 274.419355,190.129032 L271.580645,190.129032 C271.366871,190.129032 271.193548,189.95571 271.193548,189.741935 L271.193548,188.967742 C271.193548,188.753968 271.366871,188.580645 271.580645,188.580645 L271.967742,188.580645 L271.967742,186.516129 L271.580645,186.516129 C271.366871,186.516129 271.193548,186.342806 271.193548,186.129032 L271.193548,185.354839 C271.193548,185.141065 271.366871,184.967742 271.580645,184.967742 L273.645161,184.967742 C273.858935,184.967742 274.032258,185.141065 274.032258,185.354839 L274.032258,188.580645 L274.419355,188.580645 C274.633129,188.580645 274.806452,188.753968 274.806452,188.967742 L274.806452,189.741935 Z" id="Shape"></path>
                        </g>
                    </g>
                </g>
            </g>
        </g>
    </g>
</svg>

                  
                </span>
              </td>
              <td><span class="check">&#10004;</span></td>
              <td><span class="check">&#10004;</span></td>
              <td><span class="check">&#10004;</span></td>
            </tr>
            
            
          </tbody> 
        
          <thead id="features-analytics">
            <tr>
              <th>Analytics</th>
              <th>Basic</th>
              <th>Pro</th>
              <th>Enterprise</th>
            </tr>
          </thead>
          <tbody>
            
            <tr>
              <td>
                <span class="feature-title" data-description="See conference room activity live and figure out what works, with realtime charts and utilization data.">
                  
                  Measure your room usage
                  <svg width="16px" height="16px" viewbox="0 0 16 16" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">
    <g id="Pricing" stroke="none" stroke-width="1" fill-rule="evenodd">
        <g id="Pricing-/-Scheduling-/-Annual" transform="translate(-444.000000, -2072.000000)" fill-rule="nonzero">
            <g id="Feature-Table" transform="translate(0.000000, 1320.000000)">
                <g id="Group-5" transform="translate(179.000000, 538.000000)">
                    <g id="Section-4">
                        <g id="Group-2-Copy" transform="translate(0.000000, 36.000000)">
                            <path d="M273,178 C268.582032,178 265,181.583323 265,186 C265,190.419258 268.582032,194 273,194 C277.417968,194 281,190.419258 281,186 C281,181.583323 277.417968,178 273,178 Z M273,181.548387 C273.748258,181.548387 274.354839,182.154968 274.354839,182.903226 C274.354839,183.651484 273.748258,184.258065 273,184.258065 C272.251742,184.258065 271.645161,183.651484 271.645161,182.903226 C271.645161,182.154968 272.251742,181.548387 273,181.548387 Z M274.806452,189.741935 C274.806452,189.95571 274.633129,190.129032 274.419355,190.129032 L271.580645,190.129032 C271.366871,190.129032 271.193548,189.95571 271.193548,189.741935 L271.193548,188.967742 C271.193548,188.753968 271.366871,188.580645 271.580645,188.580645 L271.967742,188.580645 L271.967742,186.516129 L271.580645,186.516129 C271.366871,186.516129 271.193548,186.342806 271.193548,186.129032 L271.193548,185.354839 C271.193548,185.141065 271.366871,184.967742 271.580645,184.967742 L273.645161,184.967742 C273.858935,184.967742 274.032258,185.141065 274.032258,185.354839 L274.032258,188.580645 L274.419355,188.580645 C274.633129,188.580645 274.806452,188.753968 274.806452,188.967742 L274.806452,189.741935 Z" id="Shape"></path>
                        </g>
                    </g>
                </g>
            </g>
        </g>
    </g>
</svg>

                  
                </span>
              </td>
              <td><span class="check">&#10004;</span></td>
              <td><span class="check">&#10004;</span></td>
              <td><span class="check">&#10004;</span></td>
            </tr>
            
            <tr>
              <td>
                <span class="feature-title" data-description="Avoid scheduling conflicts by finding the high traffic times and planning around them.">
                  
                  Find meeting bottlenecks
                  <svg width="16px" height="16px" viewbox="0 0 16 16" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">
    <g id="Pricing" stroke="none" stroke-width="1" fill-rule="evenodd">
        <g id="Pricing-/-Scheduling-/-Annual" transform="translate(-444.000000, -2072.000000)" fill-rule="nonzero">
            <g id="Feature-Table" transform="translate(0.000000, 1320.000000)">
                <g id="Group-5" transform="translate(179.000000, 538.000000)">
                    <g id="Section-4">
                        <g id="Group-2-Copy" transform="translate(0.000000, 36.000000)">
                            <path d="M273,178 C268.582032,178 265,181.583323 265,186 C265,190.419258 268.582032,194 273,194 C277.417968,194 281,190.419258 281,186 C281,181.583323 277.417968,178 273,178 Z M273,181.548387 C273.748258,181.548387 274.354839,182.154968 274.354839,182.903226 C274.354839,183.651484 273.748258,184.258065 273,184.258065 C272.251742,184.258065 271.645161,183.651484 271.645161,182.903226 C271.645161,182.154968 272.251742,181.548387 273,181.548387 Z M274.806452,189.741935 C274.806452,189.95571 274.633129,190.129032 274.419355,190.129032 L271.580645,190.129032 C271.366871,190.129032 271.193548,189.95571 271.193548,189.741935 L271.193548,188.967742 C271.193548,188.753968 271.366871,188.580645 271.580645,188.580645 L271.967742,188.580645 L271.967742,186.516129 L271.580645,186.516129 C271.366871,186.516129 271.193548,186.342806 271.193548,186.129032 L271.193548,185.354839 C271.193548,185.141065 271.366871,184.967742 271.580645,184.967742 L273.645161,184.967742 C273.858935,184.967742 274.032258,185.141065 274.032258,185.354839 L274.032258,188.580645 L274.419355,188.580645 C274.633129,188.580645 274.806452,188.753968 274.806452,188.967742 L274.806452,189.741935 Z" id="Shape"></path>
                        </g>
                    </g>
                </g>
            </g>
        </g>
    </g>
</svg>

                  
                </span>
              </td>
              <td><span class="check">&#10004;</span></td>
              <td><span class="check">&#10004;</span></td>
              <td><span class="check">&#10004;</span></td>
            </tr>
            
            <tr>
              <td>
                <span class="feature-title" data-description="Get a digest of your office activity, straight to your inbox.">
                  
                  Weekly usage reports
                  <svg width="16px" height="16px" viewbox="0 0 16 16" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">
    <g id="Pricing" stroke="none" stroke-width="1" fill-rule="evenodd">
        <g id="Pricing-/-Scheduling-/-Annual" transform="translate(-444.000000, -2072.000000)" fill-rule="nonzero">
            <g id="Feature-Table" transform="translate(0.000000, 1320.000000)">
                <g id="Group-5" transform="translate(179.000000, 538.000000)">
                    <g id="Section-4">
                        <g id="Group-2-Copy" transform="translate(0.000000, 36.000000)">
                            <path d="M273,178 C268.582032,178 265,181.583323 265,186 C265,190.419258 268.582032,194 273,194 C277.417968,194 281,190.419258 281,186 C281,181.583323 277.417968,178 273,178 Z M273,181.548387 C273.748258,181.548387 274.354839,182.154968 274.354839,182.903226 C274.354839,183.651484 273.748258,184.258065 273,184.258065 C272.251742,184.258065 271.645161,183.651484 271.645161,182.903226 C271.645161,182.154968 272.251742,181.548387 273,181.548387 Z M274.806452,189.741935 C274.806452,189.95571 274.633129,190.129032 274.419355,190.129032 L271.580645,190.129032 C271.366871,190.129032 271.193548,189.95571 271.193548,189.741935 L271.193548,188.967742 C271.193548,188.753968 271.366871,188.580645 271.580645,188.580645 L271.967742,188.580645 L271.967742,186.516129 L271.580645,186.516129 C271.366871,186.516129 271.193548,186.342806 271.193548,186.129032 L271.193548,185.354839 C271.193548,185.141065 271.366871,184.967742 271.580645,184.967742 L273.645161,184.967742 C273.858935,184.967742 274.032258,185.141065 274.032258,185.354839 L274.032258,188.580645 L274.419355,188.580645 C274.633129,188.580645 274.806452,188.753968 274.806452,188.967742 L274.806452,189.741935 Z" id="Shape"></path>
                        </g>
                    </g>
                </g>
            </g>
        </g>
    </g>
</svg>

                  
                </span>
              </td>
              <td><span class="check">&#10004;</span></td>
              <td><span class="check">&#10004;</span></td>
              <td><span class="check">&#10004;</span></td>
            </tr>
            
            <tr>
              <td>
                <span class="feature-title" data-description="Download a copy of your raw usage data and run your own analysis.">
                  
                  Export your data
                  <svg width="16px" height="16px" viewbox="0 0 16 16" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">
    <g id="Pricing" stroke="none" stroke-width="1" fill-rule="evenodd">
        <g id="Pricing-/-Scheduling-/-Annual" transform="translate(-444.000000, -2072.000000)" fill-rule="nonzero">
            <g id="Feature-Table" transform="translate(0.000000, 1320.000000)">
                <g id="Group-5" transform="translate(179.000000, 538.000000)">
                    <g id="Section-4">
                        <g id="Group-2-Copy" transform="translate(0.000000, 36.000000)">
                            <path d="M273,178 C268.582032,178 265,181.583323 265,186 C265,190.419258 268.582032,194 273,194 C277.417968,194 281,190.419258 281,186 C281,181.583323 277.417968,178 273,178 Z M273,181.548387 C273.748258,181.548387 274.354839,182.154968 274.354839,182.903226 C274.354839,183.651484 273.748258,184.258065 273,184.258065 C272.251742,184.258065 271.645161,183.651484 271.645161,182.903226 C271.645161,182.154968 272.251742,181.548387 273,181.548387 Z M274.806452,189.741935 C274.806452,189.95571 274.633129,190.129032 274.419355,190.129032 L271.580645,190.129032 C271.366871,190.129032 271.193548,189.95571 271.193548,189.741935 L271.193548,188.967742 C271.193548,188.753968 271.366871,188.580645 271.580645,188.580645 L271.967742,188.580645 L271.967742,186.516129 L271.580645,186.516129 C271.366871,186.516129 271.193548,186.342806 271.193548,186.129032 L271.193548,185.354839 C271.193548,185.141065 271.366871,184.967742 271.580645,184.967742 L273.645161,184.967742 C273.858935,184.967742 274.032258,185.141065 274.032258,185.354839 L274.032258,188.580645 L274.419355,188.580645 C274.633129,188.580645 274.806452,188.753968 274.806452,188.967742 L274.806452,189.741935 Z" id="Shape"></path>
                        </g>
                    </g>
                </g>
            </g>
        </g>
    </g>
</svg>

                  
                </span>
              </td>
              <td><span class="check">&#10004;</span></td>
              <td><span class="check">&#10004;</span></td>
              <td><span class="check">&#10004;</span></td>
            </tr>
            
            <tr>
              <td>
                <span class="feature-title" data-description="You have specific office metrics to track, we can make sure you have them delivered when you need them.">
                  
                  Custom reports (ask for pricing)
                  <svg width="16px" height="16px" viewbox="0 0 16 16" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">
    <g id="Pricing" stroke="none" stroke-width="1" fill-rule="evenodd">
        <g id="Pricing-/-Scheduling-/-Annual" transform="translate(-444.000000, -2072.000000)" fill-rule="nonzero">
            <g id="Feature-Table" transform="translate(0.000000, 1320.000000)">
                <g id="Group-5" transform="translate(179.000000, 538.000000)">
                    <g id="Section-4">
                        <g id="Group-2-Copy" transform="translate(0.000000, 36.000000)">
                            <path d="M273,178 C268.582032,178 265,181.583323 265,186 C265,190.419258 268.582032,194 273,194 C277.417968,194 281,190.419258 281,186 C281,181.583323 277.417968,178 273,178 Z M273,181.548387 C273.748258,181.548387 274.354839,182.154968 274.354839,182.903226 C274.354839,183.651484 273.748258,184.258065 273,184.258065 C272.251742,184.258065 271.645161,183.651484 271.645161,182.903226 C271.645161,182.154968 272.251742,181.548387 273,181.548387 Z M274.806452,189.741935 C274.806452,189.95571 274.633129,190.129032 274.419355,190.129032 L271.580645,190.129032 C271.366871,190.129032 271.193548,189.95571 271.193548,189.741935 L271.193548,188.967742 C271.193548,188.753968 271.366871,188.580645 271.580645,188.580645 L271.967742,188.580645 L271.967742,186.516129 L271.580645,186.516129 C271.366871,186.516129 271.193548,186.342806 271.193548,186.129032 L271.193548,185.354839 C271.193548,185.141065 271.366871,184.967742 271.580645,184.967742 L273.645161,184.967742 C273.858935,184.967742 274.032258,185.141065 274.032258,185.354839 L274.032258,188.580645 L274.419355,188.580645 C274.633129,188.580645 274.806452,188.753968 274.806452,188.967742 L274.806452,189.741935 Z" id="Shape"></path>
                        </g>
                    </g>
                </g>
            </g>
        </g>
    </g>
</svg>

                  
                </span>
              </td>
              <td>&mdash;</td>
              <td>&mdash;</td>
              <td><span class="check">&#10004;</span></td>
            </tr>
            
            
          </tbody>
        
          <thead id="features-administration">
            <tr>
              <th>Administration</th>
              <th>Basic</th>
              <th>Pro</th>
              <th>Enterprise</th>
            </tr>
          </thead>
          <tbody>
            
            <tr>
              <td>
                <span class="feature-title" data-description="Support for single sign-on via Google Apps and Office 365 accounts.">
                  
                  Google and Office 365 SSO
                  <svg width="16px" height="16px" viewbox="0 0 16 16" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">
    <g id="Pricing" stroke="none" stroke-width="1" fill-rule="evenodd">
        <g id="Pricing-/-Scheduling-/-Annual" transform="translate(-444.000000, -2072.000000)" fill-rule="nonzero">
            <g id="Feature-Table" transform="translate(0.000000, 1320.000000)">
                <g id="Group-5" transform="translate(179.000000, 538.000000)">
                    <g id="Section-4">
                        <g id="Group-2-Copy" transform="translate(0.000000, 36.000000)">
                            <path d="M273,178 C268.582032,178 265,181.583323 265,186 C265,190.419258 268.582032,194 273,194 C277.417968,194 281,190.419258 281,186 C281,181.583323 277.417968,178 273,178 Z M273,181.548387 C273.748258,181.548387 274.354839,182.154968 274.354839,182.903226 C274.354839,183.651484 273.748258,184.258065 273,184.258065 C272.251742,184.258065 271.645161,183.651484 271.645161,182.903226 C271.645161,182.154968 272.251742,181.548387 273,181.548387 Z M274.806452,189.741935 C274.806452,189.95571 274.633129,190.129032 274.419355,190.129032 L271.580645,190.129032 C271.366871,190.129032 271.193548,189.95571 271.193548,189.741935 L271.193548,188.967742 C271.193548,188.753968 271.366871,188.580645 271.580645,188.580645 L271.967742,188.580645 L271.967742,186.516129 L271.580645,186.516129 C271.366871,186.516129 271.193548,186.342806 271.193548,186.129032 L271.193548,185.354839 C271.193548,185.141065 271.366871,184.967742 271.580645,184.967742 L273.645161,184.967742 C273.858935,184.967742 274.032258,185.141065 274.032258,185.354839 L274.032258,188.580645 L274.419355,188.580645 C274.633129,188.580645 274.806452,188.753968 274.806452,188.967742 L274.806452,189.741935 Z" id="Shape"></path>
                        </g>
                    </g>
                </g>
            </g>
        </g>
    </g>
</svg>

                  
                </span>
              </td>
              <td><span class="check">&#10004;</span></td>
              <td><span class="check">&#10004;</span></td>
              <td><span class="check">&#10004;</span></td>
            </tr>
            
            <tr>
              <td>
                <span class="feature-title" data-description="Onboard your organization easily using an existing identity provider like Okta, Ping, and OneLogin.">
                  
                  SAML single sign-on
                  <svg width="16px" height="16px" viewbox="0 0 16 16" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">
    <g id="Pricing" stroke="none" stroke-width="1" fill-rule="evenodd">
        <g id="Pricing-/-Scheduling-/-Annual" transform="translate(-444.000000, -2072.000000)" fill-rule="nonzero">
            <g id="Feature-Table" transform="translate(0.000000, 1320.000000)">
                <g id="Group-5" transform="translate(179.000000, 538.000000)">
                    <g id="Section-4">
                        <g id="Group-2-Copy" transform="translate(0.000000, 36.000000)">
                            <path d="M273,178 C268.582032,178 265,181.583323 265,186 C265,190.419258 268.582032,194 273,194 C277.417968,194 281,190.419258 281,186 C281,181.583323 277.417968,178 273,178 Z M273,181.548387 C273.748258,181.548387 274.354839,182.154968 274.354839,182.903226 C274.354839,183.651484 273.748258,184.258065 273,184.258065 C272.251742,184.258065 271.645161,183.651484 271.645161,182.903226 C271.645161,182.154968 272.251742,181.548387 273,181.548387 Z M274.806452,189.741935 C274.806452,189.95571 274.633129,190.129032 274.419355,190.129032 L271.580645,190.129032 C271.366871,190.129032 271.193548,189.95571 271.193548,189.741935 L271.193548,188.967742 C271.193548,188.753968 271.366871,188.580645 271.580645,188.580645 L271.967742,188.580645 L271.967742,186.516129 L271.580645,186.516129 C271.366871,186.516129 271.193548,186.342806 271.193548,186.129032 L271.193548,185.354839 C271.193548,185.141065 271.366871,184.967742 271.580645,184.967742 L273.645161,184.967742 C273.858935,184.967742 274.032258,185.141065 274.032258,185.354839 L274.032258,188.580645 L274.419355,188.580645 C274.633129,188.580645 274.806452,188.753968 274.806452,188.967742 L274.806452,189.741935 Z" id="Shape"></path>
                        </g>
                    </g>
                </g>
            </g>
        </g>
    </g>
</svg>

                  
                </span>
              </td>
              <td>&mdash;</td>
              <td>&mdash;</td>
              <td><span class="check">&#10004;</span></td>
            </tr>
            
            <tr>
              <td>
                <span class="feature-title" data-description="Provision and sync user data from supported identity providers.">
                  
                  Active Directory sync
                  <svg width="16px" height="16px" viewbox="0 0 16 16" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">
    <g id="Pricing" stroke="none" stroke-width="1" fill-rule="evenodd">
        <g id="Pricing-/-Scheduling-/-Annual" transform="translate(-444.000000, -2072.000000)" fill-rule="nonzero">
            <g id="Feature-Table" transform="translate(0.000000, 1320.000000)">
                <g id="Group-5" transform="translate(179.000000, 538.000000)">
                    <g id="Section-4">
                        <g id="Group-2-Copy" transform="translate(0.000000, 36.000000)">
                            <path d="M273,178 C268.582032,178 265,181.583323 265,186 C265,190.419258 268.582032,194 273,194 C277.417968,194 281,190.419258 281,186 C281,181.583323 277.417968,178 273,178 Z M273,181.548387 C273.748258,181.548387 274.354839,182.154968 274.354839,182.903226 C274.354839,183.651484 273.748258,184.258065 273,184.258065 C272.251742,184.258065 271.645161,183.651484 271.645161,182.903226 C271.645161,182.154968 272.251742,181.548387 273,181.548387 Z M274.806452,189.741935 C274.806452,189.95571 274.633129,190.129032 274.419355,190.129032 L271.580645,190.129032 C271.366871,190.129032 271.193548,189.95571 271.193548,189.741935 L271.193548,188.967742 C271.193548,188.753968 271.366871,188.580645 271.580645,188.580645 L271.967742,188.580645 L271.967742,186.516129 L271.580645,186.516129 C271.366871,186.516129 271.193548,186.342806 271.193548,186.129032 L271.193548,185.354839 C271.193548,185.141065 271.366871,184.967742 271.580645,184.967742 L273.645161,184.967742 C273.858935,184.967742 274.032258,185.141065 274.032258,185.354839 L274.032258,188.580645 L274.419355,188.580645 C274.633129,188.580645 274.806452,188.753968 274.806452,188.967742 L274.806452,189.741935 Z" id="Shape"></path>
                        </g>
                    </g>
                </g>
            </g>
        </g>
    </g>
</svg>

                  
                </span>
              </td>
              <td>&mdash;</td>
              <td>&mdash;</td>
              <td><span class="check">&#10004;</span></td>
            </tr>
            
            
          </tbody>
        
          <thead id="features-web-dashboard">
            <tr>
              <th>Web Dashboard</th>
              <th>Basic</th>
              <th>Pro</th>
              <th>Enterprise</th>
            </tr>
          </thead>
          <tbody>
            
            <tr>
              <td>
                <span class="feature-title" data-description="Find available spaces in your office. Filter by capacity and type.">
                  
                  Office search engine
                  <svg width="16px" height="16px" viewbox="0 0 16 16" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">
    <g id="Pricing" stroke="none" stroke-width="1" fill-rule="evenodd">
        <g id="Pricing-/-Scheduling-/-Annual" transform="translate(-444.000000, -2072.000000)" fill-rule="nonzero">
            <g id="Feature-Table" transform="translate(0.000000, 1320.000000)">
                <g id="Group-5" transform="translate(179.000000, 538.000000)">
                    <g id="Section-4">
                        <g id="Group-2-Copy" transform="translate(0.000000, 36.000000)">
                            <path d="M273,178 C268.582032,178 265,181.583323 265,186 C265,190.419258 268.582032,194 273,194 C277.417968,194 281,190.419258 281,186 C281,181.583323 277.417968,178 273,178 Z M273,181.548387 C273.748258,181.548387 274.354839,182.154968 274.354839,182.903226 C274.354839,183.651484 273.748258,184.258065 273,184.258065 C272.251742,184.258065 271.645161,183.651484 271.645161,182.903226 C271.645161,182.154968 272.251742,181.548387 273,181.548387 Z M274.806452,189.741935 C274.806452,189.95571 274.633129,190.129032 274.419355,190.129032 L271.580645,190.129032 C271.366871,190.129032 271.193548,189.95571 271.193548,189.741935 L271.193548,188.967742 C271.193548,188.753968 271.366871,188.580645 271.580645,188.580645 L271.967742,188.580645 L271.967742,186.516129 L271.580645,186.516129 C271.366871,186.516129 271.193548,186.342806 271.193548,186.129032 L271.193548,185.354839 C271.193548,185.141065 271.366871,184.967742 271.580645,184.967742 L273.645161,184.967742 C273.858935,184.967742 274.032258,185.141065 274.032258,185.354839 L274.032258,188.580645 L274.419355,188.580645 C274.633129,188.580645 274.806452,188.753968 274.806452,188.967742 L274.806452,189.741935 Z" id="Shape"></path>
                        </g>
                    </g>
                </g>
            </g>
        </g>
    </g>
</svg>

                  
                </span>
              </td>
              <td><span class="check">&#10004;</span></td>
              <td><span class="check">&#10004;</span></td>
              <td><span class="check">&#10004;</span></td>
            </tr>
            
            <tr>
              <td>
                <span class="feature-title" data-description="Dyart makes your office calendars available to everyone, even if you're on separate calendar systems. Great for co-working and other multi-tenant environments.">
                  
                  Easy access to shared calendars
                  <svg width="16px" height="16px" viewbox="0 0 16 16" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">
    <g id="Pricing" stroke="none" stroke-width="1" fill-rule="evenodd">
        <g id="Pricing-/-Scheduling-/-Annual" transform="translate(-444.000000, -2072.000000)" fill-rule="nonzero">
            <g id="Feature-Table" transform="translate(0.000000, 1320.000000)">
                <g id="Group-5" transform="translate(179.000000, 538.000000)">
                    <g id="Section-4">
                        <g id="Group-2-Copy" transform="translate(0.000000, 36.000000)">
                            <path d="M273,178 C268.582032,178 265,181.583323 265,186 C265,190.419258 268.582032,194 273,194 C277.417968,194 281,190.419258 281,186 C281,181.583323 277.417968,178 273,178 Z M273,181.548387 C273.748258,181.548387 274.354839,182.154968 274.354839,182.903226 C274.354839,183.651484 273.748258,184.258065 273,184.258065 C272.251742,184.258065 271.645161,183.651484 271.645161,182.903226 C271.645161,182.154968 272.251742,181.548387 273,181.548387 Z M274.806452,189.741935 C274.806452,189.95571 274.633129,190.129032 274.419355,190.129032 L271.580645,190.129032 C271.366871,190.129032 271.193548,189.95571 271.193548,189.741935 L271.193548,188.967742 C271.193548,188.753968 271.366871,188.580645 271.580645,188.580645 L271.967742,188.580645 L271.967742,186.516129 L271.580645,186.516129 C271.366871,186.516129 271.193548,186.342806 271.193548,186.129032 L271.193548,185.354839 C271.193548,185.141065 271.366871,184.967742 271.580645,184.967742 L273.645161,184.967742 C273.858935,184.967742 274.032258,185.141065 274.032258,185.354839 L274.032258,188.580645 L274.419355,188.580645 C274.633129,188.580645 274.806452,188.753968 274.806452,188.967742 L274.806452,189.741935 Z" id="Shape"></path>
                        </g>
                    </g>
                </g>
            </g>
        </g>
    </g>
</svg>

                  
                </span>
              </td>
              <td><span class="check">&#10004;</span></td>
              <td><span class="check">&#10004;</span></td>
              <td><span class="check">&#10004;</span></td>
            </tr>
            
            <tr>
              <td>
                <span class="feature-title" data-description="Include support requests for catering, facilities, and A/V with your meetings.">
                  
                    <a href="#">
                  
                  Meeting services
                  <svg width="16px" height="16px" viewbox="0 0 16 16" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">
    <g id="Pricing" stroke="none" stroke-width="1" fill-rule="evenodd">
        <g id="Pricing-/-Scheduling-/-Annual" transform="translate(-444.000000, -2072.000000)" fill-rule="nonzero">
            <g id="Feature-Table" transform="translate(0.000000, 1320.000000)">
                <g id="Group-5" transform="translate(179.000000, 538.000000)">
                    <g id="Section-4">
                        <g id="Group-2-Copy" transform="translate(0.000000, 36.000000)">
                            <path d="M273,178 C268.582032,178 265,181.583323 265,186 C265,190.419258 268.582032,194 273,194 C277.417968,194 281,190.419258 281,186 C281,181.583323 277.417968,178 273,178 Z M273,181.548387 C273.748258,181.548387 274.354839,182.154968 274.354839,182.903226 C274.354839,183.651484 273.748258,184.258065 273,184.258065 C272.251742,184.258065 271.645161,183.651484 271.645161,182.903226 C271.645161,182.154968 272.251742,181.548387 273,181.548387 Z M274.806452,189.741935 C274.806452,189.95571 274.633129,190.129032 274.419355,190.129032 L271.580645,190.129032 C271.366871,190.129032 271.193548,189.95571 271.193548,189.741935 L271.193548,188.967742 C271.193548,188.753968 271.366871,188.580645 271.580645,188.580645 L271.967742,188.580645 L271.967742,186.516129 L271.580645,186.516129 C271.366871,186.516129 271.193548,186.342806 271.193548,186.129032 L271.193548,185.354839 C271.193548,185.141065 271.366871,184.967742 271.580645,184.967742 L273.645161,184.967742 C273.858935,184.967742 274.032258,185.141065 274.032258,185.354839 L274.032258,188.580645 L274.419355,188.580645 C274.633129,188.580645 274.806452,188.753968 274.806452,188.967742 L274.806452,189.741935 Z" id="Shape"></path>
                        </g>
                    </g>
                </g>
            </g>
        </g>
    </g>
</svg>

                  
                    </a>
                  
                </span>
              </td>
              <td>&mdash;</td>
              <td>&mdash;</td>
              <td><span class="check">&#10004;</span></td>
            </tr>
            
            
          </tbody>
        
          <thead id="features-support">
            <tr>
              <th>Support</th>
              <th>Basic</th>
              <th>Pro</th>
              <th>Enterprise</th>
            </tr>
          </thead>
          <tbody>
            
            <tr>
              <td>
                <span class="feature-title" data-description="Talk to some of the friendliest support you've ever met.">
                  
                  Live chat
                  <svg width="16px" height="16px" viewbox="0 0 16 16" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">
    <g id="Pricing" stroke="none" stroke-width="1" fill-rule="evenodd">
        <g id="Pricing-/-Scheduling-/-Annual" transform="translate(-444.000000, -2072.000000)" fill-rule="nonzero">
            <g id="Feature-Table" transform="translate(0.000000, 1320.000000)">
                <g id="Group-5" transform="translate(179.000000, 538.000000)">
                    <g id="Section-4">
                        <g id="Group-2-Copy" transform="translate(0.000000, 36.000000)">
                            <path d="M273,178 C268.582032,178 265,181.583323 265,186 C265,190.419258 268.582032,194 273,194 C277.417968,194 281,190.419258 281,186 C281,181.583323 277.417968,178 273,178 Z M273,181.548387 C273.748258,181.548387 274.354839,182.154968 274.354839,182.903226 C274.354839,183.651484 273.748258,184.258065 273,184.258065 C272.251742,184.258065 271.645161,183.651484 271.645161,182.903226 C271.645161,182.154968 272.251742,181.548387 273,181.548387 Z M274.806452,189.741935 C274.806452,189.95571 274.633129,190.129032 274.419355,190.129032 L271.580645,190.129032 C271.366871,190.129032 271.193548,189.95571 271.193548,189.741935 L271.193548,188.967742 C271.193548,188.753968 271.366871,188.580645 271.580645,188.580645 L271.967742,188.580645 L271.967742,186.516129 L271.580645,186.516129 C271.366871,186.516129 271.193548,186.342806 271.193548,186.129032 L271.193548,185.354839 C271.193548,185.141065 271.366871,184.967742 271.580645,184.967742 L273.645161,184.967742 C273.858935,184.967742 274.032258,185.141065 274.032258,185.354839 L274.032258,188.580645 L274.419355,188.580645 C274.633129,188.580645 274.806452,188.753968 274.806452,188.967742 L274.806452,189.741935 Z" id="Shape"></path>
                        </g>
                    </g>
                </g>
            </g>
        </g>
    </g>
</svg>

                  
                </span>
              </td>
              <td><span class="check">&#10004;</span></td>
              <td><span class="check">&#10004;</span></td>
              <td><span class="check">&#10004;</span></td>
            </tr>
            
            <tr>
              <td>
                <span class="feature-title" data-description="We've helped hundreds of companies set up their scheduling. We're here to get you up and running, even if you're starting from scratch.">
                  
                  Hands-on onboarding
                  <svg width="16px" height="16px" viewbox="0 0 16 16" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">
    <g id="Pricing" stroke="none" stroke-width="1" fill-rule="evenodd">
        <g id="Pricing-/-Scheduling-/-Annual" transform="translate(-444.000000, -2072.000000)" fill-rule="nonzero">
            <g id="Feature-Table" transform="translate(0.000000, 1320.000000)">
                <g id="Group-5" transform="translate(179.000000, 538.000000)">
                    <g id="Section-4">
                        <g id="Group-2-Copy" transform="translate(0.000000, 36.000000)">
                            <path d="M273,178 C268.582032,178 265,181.583323 265,186 C265,190.419258 268.582032,194 273,194 C277.417968,194 281,190.419258 281,186 C281,181.583323 277.417968,178 273,178 Z M273,181.548387 C273.748258,181.548387 274.354839,182.154968 274.354839,182.903226 C274.354839,183.651484 273.748258,184.258065 273,184.258065 C272.251742,184.258065 271.645161,183.651484 271.645161,182.903226 C271.645161,182.154968 272.251742,181.548387 273,181.548387 Z M274.806452,189.741935 C274.806452,189.95571 274.633129,190.129032 274.419355,190.129032 L271.580645,190.129032 C271.366871,190.129032 271.193548,189.95571 271.193548,189.741935 L271.193548,188.967742 C271.193548,188.753968 271.366871,188.580645 271.580645,188.580645 L271.967742,188.580645 L271.967742,186.516129 L271.580645,186.516129 C271.366871,186.516129 271.193548,186.342806 271.193548,186.129032 L271.193548,185.354839 C271.193548,185.141065 271.366871,184.967742 271.580645,184.967742 L273.645161,184.967742 C273.858935,184.967742 274.032258,185.141065 274.032258,185.354839 L274.032258,188.580645 L274.419355,188.580645 C274.633129,188.580645 274.806452,188.753968 274.806452,188.967742 L274.806452,189.741935 Z" id="Shape"></path>
                        </g>
                    </g>
                </g>
            </g>
        </g>
    </g>
</svg>

                  
                </span>
              </td>
              <td><span class="check">&#10004;</span></td>
              <td><span class="check">&#10004;</span></td>
              <td><span class="check">&#10004;</span></td>
            </tr>
            
            <tr>
              <td>
                <span class="feature-title" data-description="Need help completing a risk assessment? We'll work with your security team to check the right boxes.">
                  
                    <a href="#">
                  
                  Security audit assistance
                  <svg width="16px" height="16px" viewbox="0 0 16 16" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">
    <g id="Pricing" stroke="none" stroke-width="1" fill-rule="evenodd">
        <g id="Pricing-/-Scheduling-/-Annual" transform="translate(-444.000000, -2072.000000)" fill-rule="nonzero">
            <g id="Feature-Table" transform="translate(0.000000, 1320.000000)">
                <g id="Group-5" transform="translate(179.000000, 538.000000)">
                    <g id="Section-4">
                        <g id="Group-2-Copy" transform="translate(0.000000, 36.000000)">
                            <path d="M273,178 C268.582032,178 265,181.583323 265,186 C265,190.419258 268.582032,194 273,194 C277.417968,194 281,190.419258 281,186 C281,181.583323 277.417968,178 273,178 Z M273,181.548387 C273.748258,181.548387 274.354839,182.154968 274.354839,182.903226 C274.354839,183.651484 273.748258,184.258065 273,184.258065 C272.251742,184.258065 271.645161,183.651484 271.645161,182.903226 C271.645161,182.154968 272.251742,181.548387 273,181.548387 Z M274.806452,189.741935 C274.806452,189.95571 274.633129,190.129032 274.419355,190.129032 L271.580645,190.129032 C271.366871,190.129032 271.193548,189.95571 271.193548,189.741935 L271.193548,188.967742 C271.193548,188.753968 271.366871,188.580645 271.580645,188.580645 L271.967742,188.580645 L271.967742,186.516129 L271.580645,186.516129 C271.366871,186.516129 271.193548,186.342806 271.193548,186.129032 L271.193548,185.354839 C271.193548,185.141065 271.366871,184.967742 271.580645,184.967742 L273.645161,184.967742 C273.858935,184.967742 274.032258,185.141065 274.032258,185.354839 L274.032258,188.580645 L274.419355,188.580645 C274.633129,188.580645 274.806452,188.753968 274.806452,188.967742 L274.806452,189.741935 Z" id="Shape"></path>
                        </g>
                    </g>
                </g>
            </g>
        </g>
    </g>
</svg>

                  
                    </a>
                  
                </span>
              </td>
              <td>&mdash;</td>
              <td>&mdash;</td>
              <td><span class="check">&#10004;</span></td>
            </tr>
            
            
          </tbody>
        
      </table>
    </section>
  </div>
</section>

<section class="section cta-base cta-bar">
  <div class="container">
    <div class="cta-bar__left">
      <h4>Start to schedule your office with Dyart</h4>
      <p class="p--big">Ready to jump in? <a href="<?php echo $this->config->base_url() ?>demorequest">Start your free trial</a></p>
    </div>
    <div class="cta-bar__right">
      <a href="<?php echo $this->config->base_url() ?>demorequest" class="button button--red-inverse">Schedule a Demo</a>
    </div>
  </div>
</section>

<section class="section section--medium">
  <div class="container">
    <h3 id="faq">Frequently asked questions</h3>

    
      <div class="faq-item" id="faq-1">
        <div class="faq-item-content">
          <h4 class="faq-item-title">Does Dyart integrate with my current calendars?</h4>
          <div class="faq-answer" style="display: block;">
            <p>Yes! Dyart is like having a really smart assistant with access to your calendars. As long as you use a supported calendar system, you don’t have to change a thing unless you want to.</p>

          </div>
        </div>
        <button class="faq-item-toggle-wrapper active">
          <span class="faq-item-toggle"></span>
        </button>
      </div>
    
      <div class="faq-item" id="faq-2">
        <div class="faq-item-content">
          <h4 class="faq-item-title">What kind of office analytics can Dyart report?</h4>
          <div class="faq-answer" style="">
            <p>Dyart automatically combines calendar events, presence, and other office data to give insights about how your team and space work together. You’ll learn how meeting length, time of day, and frequency affect how your team operates.</p>

          </div>
        </div>
        <button class="faq-item-toggle-wrapper ">
          <span class="faq-item-toggle"></span>
        </button>
      </div>
    
      <div class="faq-item" id="faq-3">
        <div class="faq-item-content">
          <h4 class="faq-item-title">Does this work for shared offices?</h4>
          <div class="faq-answer" style="">
            <p>The dashboard and mobile apps make it easy to share calendars in multi-tenant environments. <a href="#">Here’s a guide to get started</a>.</p>

          </div>
        </div>
        <button class="faq-item-toggle-wrapper ">
          <span class="faq-item-toggle"></span>
        </button>
      </div>
    
      <div class="faq-item" id="faq-4">
        <div class="faq-item-content">
          <h4 class="faq-item-title">Do you have an on-premise version?</h4>
          <div class="faq-answer" style="">
            <p>Dyart is available as a cloud-only service today, which makes it easy for us to quickly deliver new features and improve performance. We do not currently have plans to release a self-hosted version. <a href="#">Learn more about our security practices</a>.</p>

          </div>
        </div>
        <button class="faq-item-toggle-wrapper ">
          <span class="faq-item-toggle"></span>
        </button>
      </div>
    
      <div class="faq-item" id="faq-5">
        <div class="faq-item-content">
          <h4 class="faq-item-title">What hardware do I need?</h4>
          <div class="faq-answer" style="">
            <p>For calendar booking, just an iPad. For presence, Dyart uses beacons to mark locations. A single <a href="http://beekn.net/guide-to-ibeacons/">beacon</a> will fit most rooms. <a href="#">Check out the store for a full list of suggested equipment</a>.</p>

          </div>
        </div>
        <button class="faq-item-toggle-wrapper ">
          <span class="faq-item-toggle"></span>
        </button>
      </div>
    
      <div class="faq-item" id="faq-6">
        <div class="faq-item-content">
          <h4 class="faq-item-title">Do you provide the hardware?</h4>
          <div class="faq-answer" style="">
            <p>No, Dyart is software that runs on off-the-shelf iOS (i.e. iPad) and Android devices. We keep a <a href="#">list of recommended equipment (and where to find them) here</a></p>

          </div>
        </div>
        <button class="faq-item-toggle-wrapper ">
          <span class="faq-item-toggle"></span>
        </button>
      </div>
    
      <div class="faq-item" id="faq-7">
        <div class="faq-item-content">
          <h4 class="faq-item-title">What else can Dyart do?</h4>
          <div class="faq-answer" style="">
            <p>Meeting upgrades and room booking are a good start, but there are many other office headaches Dyart can solve. See more of where a building API can go with our <a href="#">developer</a> program.</p>

          </div>
        </div>
        <button class="faq-item-toggle-wrapper ">
          <span class="faq-item-toggle"></span>
        </button>
      </div>
    
      <div class="faq-item" id="faq-8">
        <div class="faq-item-content">
          <h4 class="faq-item-title">Where can I get the mobile apps?</h4>
          <div class="faq-answer" style="">
            <p>We keep links for all our apps <a href="#">here</a>.</p>

          </div>
        </div>
        <button class="faq-item-toggle-wrapper ">
          <span class="faq-item-toggle"></span>
        </button>
      </div>
    
      <div class="faq-item" id="faq-9">
        <div class="faq-item-content">
          <h4 class="faq-item-title">Which beacons should I buy?</h4>
          <div class="faq-answer" style="">
            <p>We don’t sell beacons directly, but work with all popular brands. Beacons range from $5 to $30 each and can run on battery or AC power. We keep an up to date <a href="#">list of our favorites here</a>.</p>

          </div>
        </div>
        <button class="faq-item-toggle-wrapper ">
          <span class="faq-item-toggle"></span>
        </button>
      </div>
    
      <div class="faq-item" id="faq-10">
        <div class="faq-item-content">
          <h4 class="faq-item-title">Can I turn presence off?</h4>
          <div class="faq-answer" style="">
            <p>Of course. You have full control over when (and how) you want Dyart to notice you. Go off the grid as much as you want.</p>

          </div>
        </div>
        <button class="faq-item-toggle-wrapper ">
          <span class="faq-item-toggle"></span>
        </button>
      </div>
    
  </div>
</section>





  </main>

  <script>
  
;(function() {
  var w = window
  var ic = w.Intercom
  if (typeof ic === 'function') {
    ic('reattach_activator')
    ic('update', intercomSettings)
  } else {
    var d = document
    var i = function() {
      i.c(arguments)
    }
    i.q = []
    i.c = function(args) {
      i.q.push(args)
    }
    w.Intercom = i
    function l() {
      var s = d.createElement('script')
      s.type = 'text/javascript'
      s.async = true
      s.src = 'https://widget.intercom.io/widget/o0c73zj4'
      var x = d.getElementsByTagName('script')[0]
      x.parentNode.insertBefore(s, x)
    }
    if (w.attachEvent) {
      w.attachEvent('onload', l)
    } else {
      w.addEventListener('load', l, false)
    }
  }
})()
</script>

<script>
;(function() {
  // forEach
  // https://toddmotto.com/ditch-the-array-foreach-call-nodelist-hack/
  const forEach = function(array, callback, scope) {
    for (let i = 0; i < array.length; i++) {
      callback.call(scope, i, array[i])
    }
  }

  ;(function() {
    var httpRequest

    // function getSession() {
      // httpRequest = new XMLHttpRequest()
// 
      // if (!httpRequest) {
        // // XHR unsupported, somehow.
        // return false
      // }
// 
      // httpRequest.onreadystatechange = function() {
        // if (httpRequest.readyState === XMLHttpRequest.DONE) {
          // if (httpRequest.status === 200) {
            // let response = JSON.parse(httpRequest.responseText)
            // updateSession(response.data)
          // } else {
            // // Nothing available, just use anonymous session.
            // updateSession(null)
          // }
        // }
      // }
      // httpRequest.open('POST', '/robin-profile')
      // httpRequest.send()
    // }
// 
    // function updateSession(profile) {
      // if (window.Intercom) {
        // let INTERCOM_ENV = 'o0c73zj4'
        // let USER_HASH = profile ? profile.identifier : undefined
        // let ROBIN_USER_ID = profile ? profile.user.id : undefined
        // // If a session exists, boot Intercom with the appropriate user.
        // window.Intercom('boot', {
          // app_id: INTERCOM_ENV,
          // user_id: ROBIN_USER_ID,
          // user_hash: USER_HASH
        // })
      // }
    // }
// 
    // getSession()
  })()
})()
</script>

<script src="<?php echo $this->config->base_url()?>r/js/main.e41742e6.js" async=""></script>

<script>
	  document.body.className = "pricing show-scheduling";

</script>