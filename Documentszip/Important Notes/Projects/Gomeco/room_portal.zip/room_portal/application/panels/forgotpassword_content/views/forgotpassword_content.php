  <div class="basic-page">
			<div class="container">
				<div class="row">
					<div class="col-md-4 col-md-offset-1">
						<div class="basic-left">
							<h1>Recover Password</h1>
							<p>Don’t have an account? Signup</p>
						</div>
					</div>
					
   
					<div class="col-md-4 col-md-offset-1">
						<div class="basic-right">
													
						    
						    								 <form class="form-horizontal" id="forgotPassword" name="forgotPassword" method="POST" action="<?php echo $this->config->base_url();?>forgotpassword_content/send_password">
				              
								<div class="single-field">
									<p for="">Email*</p>
									<input name="email" id="email" type="email" placeholder="Enter your mail address" value="<?php echo $user_add_data['email'] ?>" >
								</div>
								<div class="single-field">
									<button type="submit">Reset Password <i class="fa fa-arrow-right"></i></button>
								</div>
							</form>
						</div>
					</div>
				</div>
			</div>
	</div>
