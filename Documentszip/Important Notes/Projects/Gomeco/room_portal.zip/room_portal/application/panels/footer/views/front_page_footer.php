<footer class="footer-area section-padding blue-bg">
		<div class="container-fluid">
			<div class="row">
				<div class="col-md-6">
					<div class="footer-menu">
						<ul>
							<li><a href="<?php echo $this->config->base_url() ?>privacy">Privacy Policy</a></li>
							<li><a href="<?php echo $this->config->base_url() ?>terms">Terms of Service</a></li>
						</ul>
					</div>
					<div class="social-media">
						<a target="_blank" href="https://twitter.com/dyartlabs"><i class="fa fa-twitter"></i></a>
						<a target="_blank" href="https://www.facebook.com/dyartlabs/"><i class="fa fa-facebook"></i></a>
						<a target="_blank" href="https://www.linkedin.com/company/dyart-labs"><i class="fa fa-linkedin"></i></a>
					</div>
				</div>
				<div class="col-md-6">
					<div class="copyright-text">
						<p>&copy; 2018, Dyart IT Consultants, Inc.</p>
					</div>
				</div>
			</div>
		</div>
	</footer><!-- /Footer Area -->
	
</div>		


<!-- Jquery JS -->
<script src="<?php echo $this->config->base_url();?>r/js/jquery.min.js"></script>

<!-- Bootstrap JS -->
<script src="<?php echo $this->config->base_url();?>r/js/bootstrap.min.js"></script>

<!-- Jquery Easing Plugin -->
<script src="<?php echo $this->config->base_url();?>r/js/jquery.easing.min.js"></script>

<!-- Meanmenu Plugin -->
<script src="<?php echo $this->config->base_url();?>r/js/jquery.meanmenu.js"></script>

<!-- SmoothScroll Plugin -->
<script src="<?php echo $this->config->base_url();?>r/js/smoothScroll.js"></script>

<script type="text/javascript" src="<?php echo $this->config->base_url().'r/'; ?>js/jquery.validate.js"></script>
	<script type="text/javascript" src="<?php echo $this->config->base_url().'r/'; ?>js/jquery-validate.bootstrap-tooltip.js"></script>

<!-- Main Javascript -->
<!-- <script src="<?php echo $this->config->base_url();?>r/js/main.js"></script> -->

 <script src="<?php echo $this->config->base_url().'r/'; ?>js/jquery.bootstrap-growl.js"></script>	
<?php if (isset($success_message) && $success_message!=""){ ?> 	
 <script type="text/javascript">

            $(function() {
               
                
                
                setTimeout(function() {
                    $.bootstrapGrowl("<?php echo $success_message;?>", {
                        type: 'success',
                        align: 'center',
                        width: 'auto',
                        allow_dismiss: false
                    });
                }, 1000);
                
               
            });
            <?php
if(isset($signup) && $signup!=""){
	
	?>
	$('#myModal').modal('show');
	<?php
}
?>
        </script>
<?php } ?>
<?php if (isset($error_message) && $error_message!=""){ ?> 	
 <script type="text/javascript">

            $(function() {
                
                setTimeout(function() {
                    $.bootstrapGrowl("<?php echo $error_message;?>", {
                        type: 'danger',
                        align: 'center',
                        width: 'auto',
                        allow_dismiss: false
                    });
                }, 1000);
                
               
            });
            <?php
if(isset($login) && $login!=""){
	
	?>
	$('#myModal').modal('show');
	<?php
}
?>
        </script>
<?php } ?>


<script type="text/javascript">
	
	$.validator.addMethod("alpha", function(value, element) {
	  return this.optional(element) |/^[a-zA-Z]+$/.test(value);
	 }, "Only Alphabets Allowed");
	$.validator.addMethod("Email", function(value, element) {
	  return this.optional(element) |/^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/.test(value);
	 }, "Valid email only");
	
	
	   $("#userSignUp").validate({
	       rules: {
	        first_name: {required: true},
	        last_name: {required: true},
	        email: {required: true,Email:true},
	        password: {required: true,minlength: 6},
	       
	        },
	  messages: {
	                   first_name:{required: "First Name is Required"},
	                last_name:{required: "Last Name is Required"},
	                email:{required: "Email Field is Required",Email:"Email Not Valid"},
	                password:{required: "Password is Required"},
	               
	     }       ,
	            tooltip_options: {
	       
	            }
	});
	
	$("#userSignIn").validate({
	       rules: {
	       
	        email: {required: true,Email:true},
	        password: {required: true,minlength: 6},
	       
	        },
	  messages: {
	                  
	                email:{required: "Email Field is Required",Email:"Email Not Valid"},
	                password:{required: "Password is Required"},
	               
	     }       ,
	            tooltip_options: {
	       
	            }
	});
	
	$("#forgotPassword").validate({
	       rules: {
	       
	        email: {required: true,Email:true},
	       
	       
	        },
	  messages: {
	                  
	                email:{required: "Email Field is Required",Email:"Email Not Valid"},
	              
	               
	     }       ,
	            tooltip_options: {
	       
	            }
	});
	
	$("#form_reset_password").validate({
	       rules: {
	        
	         password: {required: true,minlength: 6},
	         confirm_password: {
						      equalTo: "#password"
						    },
	       
	        },
	  messages: {
	                   
	                new_password:{required: "Password Required"},
	                confirm_password:{required: "Please Confirm Password"},
	               
	     }       ,
	            tooltip_options: {
	       
	            }
	});	
	
  $("#requestForm").validate({
	       rules: {
	        full_name: {required: true},
	        company_role: {required: true},
	        email: {required: true,Email:true},
	        company_name: {required: true},
	        company_website: {required: true},
	        check_auth: {required: true},
	       
	        },
	  messages: {
	                full_name:{required: "Please Provide your full name"},
	                company_role:{required: "Company Role Required"},
	                email:{required: "Email Field is Required",Email:"Email Not Valid"},
	                company_name:{required: "Company Name Required"},
	                company_website:{required: "Company Website Required"},
	                check_auth:{required: "Please Check"},
	               
	     }       ,
	            tooltip_options: {
	       
	            }
	});	
	
</script>
    
</body>

</html>