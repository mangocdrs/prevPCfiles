<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

if ( ! function_exists('request_validation')){	
	function request_validation(){
	    
	    $CI =& get_instance();
	    $CI->load->helper(array('form', 'url','file'));
	    $CI->load->library('form_validation');
		$CI->form_validation->set_rules('full_name', 'full_name', 'required');
	    $CI->form_validation->set_rules('company_role', 'company_role', 'required');
		$CI->form_validation->set_rules('company_name', 'company_name', 'required');
		$CI->form_validation->set_rules('company_website', 'company_website', 'required');
		$CI->form_validation->set_rules('email', 'email', 'required|valid_email');
		
	    
	    if ($CI->form_validation->run() == FALSE){
	         
	    	$data = array(
	        	'full_name' => set_value('full_name'),
	          	'company_role' => set_value('company_role'), 
	            'email' => set_value('email'),
	            'company_name' => set_value('company_name'),
	            'company_website' => set_value('company_website'),
	            'phone' => set_value('phone'),
	            'valid'=>0,
	            'error_message' => validation_errors(),
	         );
	        $CI->session->set_flashdata('error_message', "Field insertion error");
	    }else{
	    	$data = array(
	        	'full_name' => set_value('full_name'),
	          	'company_role' => set_value('company_role'), 
	            'email' => set_value('email'),
	            'company_name' => set_value('company_name'),
	            'company_website' => set_value('company_website'),
	            'phone' => set_value('phone'),
	        	'valid' => 1,
	        	'error_message' => "no validation error"
	    		);
	    }
		$CI->session->set_flashdata('user_add_data', $data);
	    return $data['valid'];
	}
}
if ( ! function_exists('singup_validation')){	
	function singup_validation(){
	    
	    $CI =& get_instance();
	    $CI->load->helper(array('form', 'url','file'));
	    $CI->load->library('form_validation');
		$CI->form_validation->set_rules('first_name', 'first_name', 'required');
	    $CI->form_validation->set_rules('last_name', 'last_name', 'required');
		$CI->form_validation->set_rules('email', 'email', 'required|valid_email');
		$CI->form_validation->set_rules('password', 'password', 'required');
		$CI->form_validation->set_rules('category', 'category', 'required');
	    
	    if ($CI->form_validation->run() == FALSE){
	         
	    	$data = array(
	        	'first_name' => set_value('first_name'),
	          	'last_name' => set_value('last_name'), 
	            'email' => set_value('email'),
	            'password' => set_value('password'),
	            'category' => set_value('category'),
	            'valid'=>0,
	            'error_message' => validation_errors(),
	         );
	        $CI->session->set_flashdata('error_message', "Field insertion error");
	    }else{
	    	$data = array(
	        	'first_name' => set_value('first_name'),
	          	'last_name' => set_value('last_name'), 
	            'email' => set_value('email'),
	            'password' => set_value('password'),
	            'category' => set_value('category'),
	        	'valid' => 1,
	        	'error_message' => "no validation error"
	    		);
	    }
		$CI->session->set_flashdata('user_add_data', $data);
	    return $data['valid'];
	}
}
if ( ! function_exists('singin_validation')){	
	function singin_validation(){
	
		$CI =& get_instance();
		$CI->load->helper(array('form', 'url','file'));
		$CI->load->library('form_validation');
		$CI->form_validation->set_rules('email', 'email', 'required|valid_email');
		$CI->form_validation->set_rules('password', 'password', 'required');
	    
	    if ($CI->form_validation->run() == FALSE){
	 		$data = array(
	        	'email' => set_value('email'),
	            'password' => set_value('password'),
	            'valid'=>0,
	            'error_message' => validation_errors(),
	         );
	        $CI->session->set_flashdata('error_message', "Field insertion error");
	    }else{
	    	$data = array(
	        	'email' => set_value('email'),
	            'password' => set_value('password'),
	        	'valid' => 1,
	        	'error_message' => "no validation error"
	    	);
	    }
		$CI->session->set_flashdata('user_login_data', $data);
	    return $data['valid'];  
	}
}
if ( ! function_exists('issue_validation')){
	function issue_validation(){
			
		$CI =& get_instance();
	    $CI->load->helper(array('form', 'url','file'));
	    $CI->load->library('form_validation');
		$CI->form_validation->set_rules('title', 'title', 'required');
	    $CI->form_validation->set_rules('location', 'location', 'required');
		     
		if ($CI->form_validation->run() == FALSE){
	         
	   		$data = array(
	        	'title' => set_value('title'),
	          	'location' => set_value('location'),
	          	'tags' => set_value('tags'),
	          	'description' => set_value('description'),
	            'valid'=>0,
	            'error_message' => validation_errors(),
	         );
	         $CI->session->set_flashdata('error_message', "Field insertion error");
	    }else{
	    	$data = array(
	        	'valid' => 1,
	        	'error_message' => "no validation error"
	    	 );
	    }
		$CI->session->set_flashdata('issue_data', $data);
		return $data['valid'];
	}
}
if ( ! function_exists('save_user_session')){
    function save_user_session($userdata){
        $CI =& get_instance();
		if(isset($userdata['auth'])){
			$email = $userdata['email'];
			$auth = $userdata['auth'];
		}else{
			$email = $CI -> input -> post('email');
			$password = $CI->input->post('password');
			$hased_pass=hash("sha256",$password,False);
			$auth = "Basic"." ".base64_encode($email.":".$hased_pass);
	    }
		$data = array(
    		'auth'=>$auth,
            'is_logged_in' => 1,
            'first_name'=> $userdata['firstName'],
            'last_name'=>$userdata['lastName'],
            'email'=>$email,
            'region_id'=>$userdata['regionId'],
            'user_id'=>$userdata['userId'],
            'user_latitude'=>$userdata['homeCityLatitude'],
            'user_longitude'=>$userdata['homeCityLongitude'],
            'home_city'=>$userdata['homeCity'],
            'user_type'=>$userdata['userType'],
            'profile_image'=>$userdata['imageAddress'],
            );
		$CI->session->set_userdata($data);
	}
}

if ( ! function_exists('feedback_validation')){
	function feedback_validation(){
			
		$CI =& get_instance();
	    $CI->load->helper(array('form', 'url','file'));
	    $CI->load->library('form_validation');
		$CI->form_validation->set_rules('feedback_name', 'feedback_name', 'required');
	    $CI->form_validation->set_rules('feedback_email', 'feedback_email', 'required');
		$CI->form_validation->set_rules('feedback_message', 'feedback_message', 'required');
		     
		if ($CI->form_validation->run() == FALSE){
	         
	   		$data = array(
	        	'feedback_name' => set_value('feedback_name'),
	          	'feedback_email' => set_value('feedback_email'),
	          	'feedback_message' => set_value('feedback_message'),
	            'valid'=>0,
	            'error_message' => validation_errors(),
	         );
	         $CI->session->set_flashdata('error_message', "Field insertion error");
	    }else{
	    	$data = array(
	        	'valid' => 1,
	        	'error_message' => "no validation error"
	    	 );
	    }

		$CI->session->set_flashdata('feedback_data', $data);
		return $data['valid'];
	}
}

