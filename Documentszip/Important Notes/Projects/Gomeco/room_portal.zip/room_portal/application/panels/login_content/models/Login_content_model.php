<?php

class Login_content_model extends MY_Model {
	public function __construct() {
		
		parent::__construct("");
	}
	
	
	public function verify_user(){
		
		$result = $this->findOneBy(array(
			"verification_string" => $this->input->get('verify'),
			
		),'users');
		if(isset($result->id)){
			$update_in_user=array(
			'status'=>'active',
			'verification_string'=>''
		);
		$ver_str=$this->input->get('verify');
		$this ->update($update_in_user,"verification_string='$ver_str'",'users');
		
		$this->session->set_flashdata('success_message','Email Verified Please login to continue');
		$this->session->set_flashdata('error_message','');
		}
		else{
			$this->session->set_flashdata('success_message','');
			$this->session->set_flashdata('error_message','Not Found');
		}
		
		
	}
	
	public function login_user(){
		
		$email = $this -> input -> post('email');
		$password = $this -> input -> post('password');
		
		//echo hash('sha256',$password);exit;
		$result = $this->findOneBy(array(
			"email" => $email,
			"password" => hash('sha256',$password),
			"status" => 'active'
		),'users');
		
		if(!isset($result->id)){
			
			
			$check_user = $this->findOneBy(array(
				"email" => $this->input->post('email')
			),'users');
           
		    if(!(empty($check_user))){
		    //	print_r($check_user);exit;
		     if($check_user->status=='pending'){
			
			$this -> session -> set_flashdata('error_message', "Please Verify your Email before Login");
		}
			elseif($check_user->status!='active'){
			
			$this -> session -> set_flashdata('error_message', "Your Accout Status is not active please contact Administrator");
		}
		
       else {

			$this -> session -> set_flashdata('error_message', "Invalid Password");
			}
			
			
			}
			else if(empty($check_user)){
				
				$this -> session -> set_flashdata('error_message', "Email not Registered");
			}
	   return FALSE;
			
		}	
		
	return $result;
	}


}
?>
