<?php
if (!defined('BASEPATH')) exit('No direct script access allowed');

class Footer extends MY_Controller {

     public function index() {
       exit;
    }
	public function frontfooter() {

       $this->load->view('front_page_footer');
    }
	public function homepage(){		
		$username = $this->session->userdata("username_room");
		$this -> load -> model('footer/footer_model');
		$rooms = $this->footer_model->get_rooms_detail($username);
		$data['rooms'] = $rooms;
		$this->load->view('home_footer',$data);	
		
	}
	public function super_admin(){		
		$this->load->view('superadmin_footer');	
	}
	
}
