

        <div class="basic-page">
			<div class="container">
				<div class="row">
					<div class="col-md-4 col-md-offset-1">
						<div class="basic-left">
							<h1>Log in</h1>
							<p>Don’t have an account? Signup</p>
						</div>
					</div>
					<div class="col-md-4 col-md-offset-1">
						<div class="basic-right">
													
						    
						    							 <form class="form-horizontal" id="userSignIn" name="userSignIn" method="POST" action="<?php echo $this->config->base_url();?>login_content/user_login">
				              
								<div class="single-field" style="margin-top: 8%;">
									<p for="">Email*</p>
									<input name="email" id="email" type="email" placeholder="Enter your mail address" value="" >
								</div>
								<div class="single-field">
									<p for="">Password*</p>
									<input name="password" id="password" type="password" placeholder="Enter your password" >
								</div>
								<div class="single-field">
									<button type="submit">Login <i class="fa fa-arrow-right"></i></button>
									<a href="<?php echo $this->config->base_url();?>forgotpassword">Forgot password?</a>
								</div>
							</form>
						</div>
					</div>
				</div>
			</div>
	</div>