<?php
error_reporting(E_ERROR);
class Tokens_content_model extends MY_Model {
	public function __construct() {
		
	}

	

	public function insert_token($token) {
       
		 $tokenc=$this->check_token();
		
		if(empty($tokenc)){
			$insert=array(
	   			'refresh_token'=>$token,
	   			'user_id' => $this->session->user_id

			);
	
			$result_inserted=$this->insert($insert,'refresh_tokens');
			
		}
		else{
			
			$insert_in_user=array(
			'refresh_token'=>$token,
			
		);
		$user_id=$tokenc->user_id;
		
		$result_inserted=$this->update($insert_in_user,"user_id='$user_id'",'refresh_tokens'); 
		}	
			
		
			return $result_inserted;
 }

 	public function check_token() {

    $token = $this->findOneBy(array(
				"user_id" => $this->session->user_id
			),'refresh_tokens');
			return $token;
 }

 	public function get_all_tokens_count() {
 		$params = array(
 			"select"=>"*",
 			"from"=>"refresh_tokens"
 			);
 		$result = $this->find($params);

 		if($result) {
 			return count($result);
 		}else{
 			return False;
 		}

 	}

 	public function get_all_tokens($offset,$limit){
	
         $where = ""	;
		if($this->uri->slash_segment(2)=="search/")
		{
			if(!$_POST)
			{
				$search_name=$this->session->userdata("search_name");
				$search_email= $this->session->userdata("search_email");
				$per_page= $this->session->userdata("per_page");
				$search_status= $this->session->userdata("search_status");

			}
			else{

				$search_name=$this->input->post("search_name");
				$search_email=$this->input->post("search_email");
			 	$per_page=$this->input->post("per_page");
			 	$search_status=$this->input->post("search_status");
				$newdata = array(
						'search_name'  => $search_name,
						'search_email'  => $search_email,
						'per_page'  => $per_page,
						'search_status'  => $search_status,
						);
				$this->session->set_userdata($newdata);
			}	
			$where_search = array();
			if(isset($search_name) && $search_name!=""){
				$where_search[] = "name like '%".$search_name."%'";
			}
			
			if(isset($search_email) && $search_email!=""){
				$where_search[] = "email like '%".$search_email."%'";
			}

			if(isset($per_page) && $per_page!=""){
				$limit =$per_page;
			}

			if(isset($search_status) && $search_status!=""){
				$where_search[] = "status = '".$search_status."'";
			}
			
			$where_search = implode(" and ", $where_search);
			if(strlen($where_search)){
			  	$where = $where_search;
			}	
		}

		else{
			$this->session->unset_userdata("search_name");
			$this->session->unset_userdata("search_email");
			$this->session->unset_userdata("per_page");
			$this->session->unset_userdata("search_status");
			}

		$params=array(
			'select'=>"*",
			'from'=> "refresh_tokens",
			"page" => $offset,
        	"limit" => $limit,
			);
		
		if(strlen($where)){
			$params['where']=$where;
		}
		$result=$this->find($params);

        return $result;

	}
		

public function delete_token() {
 		$id = $this->input->get('id');
		
		$this->delete("id = '$id'","refresh_tokens");
	}




















}
