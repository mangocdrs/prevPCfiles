<?php

class Services_content_model extends MY_Model {
	public function __construct() {
		parent::__construct("rooms");
	}



	public function get_service_account_detail(){
		$params=array(
			'select'=>"*",
			'from'=> "services_account_detail",
			'where' => " user_id =".$this->session->user_id
		);
		$result=$this->find($params);
		return $result;
		/*******/
	}


	function update_service_account_detail($image) {
		
	
		$account_detail = $this->get_service_account_detail();
		$email=$this->input->post("email");
		$password=$this->input->post("password");
		$service_url=$this->input->post("service_url");
		$organization_name=$this->input->post("organization_name");
		$meeting_cancel_time=$this->input->post("meeting_cancel_time");
		$display_option=$this->input->post("display_option");
		$params=array(
			'date_created'=>date("Y-m-d H:i:s"),
			'email'=>$email,
			'service_url'=>$service_url,
			'organization_name'=>$organization_name,
			'password'=>base64_encode($password),
			'meeting_cancel_time'=>round($meeting_cancel_time),
			'type'=>$display_option,
			'user_id' => $this->session->user_id,
			);
		
		if($image){
			$params['image'] = $image;
		}
		
		
		if(isset($account_detail[0])){
			$file_name=$account_detail[0]->services_file_name;
			copy(getcwd().DIRECTORY_SEPARATOR."uploads".DIRECTORY_SEPARATOR."Services.wsdl", getcwd().DIRECTORY_SEPARATOR."uploads".DIRECTORY_SEPARATOR.$file_name);
			$params['date_updated'] = date("Y-m-d H:i:s");
			$this->update($params,'id = '.$account_detail[0]->id,"services_account_detail");
		
		}else{
			$digits = 6;
            $file_name=rand(pow(10, $digits-1), pow(10, $digits)-1); 
			copy(getcwd().DIRECTORY_SEPARATOR."uploads".DIRECTORY_SEPARATOR."Services.wsdl", getcwd().DIRECTORY_SEPARATOR."uploads".DIRECTORY_SEPARATOR.$file_name.'_Services.wsdl');
			chmod(getcwd().DIRECTORY_SEPARATOR."uploads".DIRECTORY_SEPARATOR.$file_name.'_Services.wsdl',0777);
			
		    $params['services_file_name']=$file_name.'_Services.wsdl';
			$params['date_created'] = date("Y-m-d H:i:s");
			$this->insert($params,"services_account_detail");
		
		}
	}
		
}
?>
