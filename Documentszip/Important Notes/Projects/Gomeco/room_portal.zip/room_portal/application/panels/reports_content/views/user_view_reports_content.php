<?php if (isset($success_message) && $success_message!=""){ ?>
<script>
	setTimeout(function() {
	     $.bootstrapGrowl('<?php echo $success_message;?>', {
	         type: 'success',
	         align: 'center',
	         width: 'auto',
	         allow_dismiss: false
	     });
	 }, 1);
</script>
<?php } ?>
<?php
	if (isset($error_message) && $error_message!="" ){ 
		if(!isset($user_add_data['error_message'])){
		?>
	
	<script>
	       setTimeout(function() {
	            $.bootstrapGrowl('<?php echo $error_message;?>', {
	                type: 'danger',
	                align: 'center',
	                width: 'auto',
	                allow_dismiss: false
	            });
	        }, 1);
	    </script>
	   <?php
		
		}
		$error_message =  strip_tags($user_add_data['error_message']);
	    $error_message = str_replace(array("\r", "\n"), '', $error_message);
		$error_message= explode('.',$error_message);
	 	for($i=0; $i<count($error_message)-1; $i++){
  			$error = $error_message[$i];
        	if (isset($error)){ ?>
	        	
        		<script>
	       setTimeout(function() {
	            $.bootstrapGrowl("<?php echo $error;?>", {
	                type: 'danger',
	                align: 'center',
	                width: 'auto',
	                allow_dismiss: false
	            });
	        }, 1);
	    </script>
        		
        		
        	<?php }	}
		 } ?>



<div class="wrapper wrapper-content animated fadeInRight">
    <div class="row">
        <div class="col-lg-12">
            <div class="ibox float-e-margins">
                <div class="ibox-title">
                    <h5>Reports</h5>
                    
                </div>
                <div class="ibox-content">
                  
                  	<div class="row">
                		<form action="<?php echo $this->config->base_url()?>reports/search" method="POST">
                             
							<div class="col-sm-3">
								<div class="form-group">
									<select name="time_period"  id="time_period" class="form-control">
										<option value=""   <?php if($this->session->userdata('time_period')==""){echo "SELECTED";}?> >Select Time Period</option>
										<option value="week" <?php if($this->session->userdata('time_period')=="week"){echo "SELECTED";}?>>Week</option>
										<option value="month" <?php if($this->session->userdata('time_period')=="month"){echo "SELECTED";}?>>Month</option>
										<option value="year" <?php if($this->session->userdata('time_period')=="year"){echo "SELECTED";}?>>Year</option>
										<option value="custom" <?php if($this->session->userdata('time_period')=="custom"){echo "SELECTED";}?>>Custom</option>
									</select>
								</div>
							</div>
							<div class="col-sm-3 custom-div" style="display:  <?php if($this->session->userdata('time_period')=='custom'){echo 'block';}else{echo 'none';}?>;">
								<div class="form-group">
									<div class="form-group" id="from_datepicker" >
										<div class='input-group date' id='datetimepicker1'>
											<input type='text' class="form-control"  placeholder="from" value="<?php echo $this->session->userdata('from_time') ;?>" name="from_time" id="from_time" />
											<span class="input-group-addon">
											<span class="glyphicon glyphicon-calendar"></span>
											</span>
										</div>
									</div>
								</div>
							</div>
							
							<div class="col-sm-3 custom-div" style="display:  <?php if($this->session->userdata('time_period')=='custom'){echo 'block';}else{echo 'none';}?>;">
								<div class="form-group" id="to_datepicker" >
									<div class='input-group date' id='datetimepicker2' >
										<input type='text' class="form-control"  placeholder="to"  value="<?php echo $this->session->userdata('to_time') ;?>" name="to_time" id="to_time" />
										<span class="input-group-addon">
										<span class="glyphicon glyphicon-calendar"></span>
										</span>
									</div>
								</div>
							</div>
							<div class="col-sm-3">
								<div class="form-group">
									<input type="text" id="event_name" name="event_name"  value="<?php echo $this->session->userdata('event_name') ?>"  placeholder="Event Name" class="form-control">
								</div>
							</div>
							<div class="col-sm-3">
								<div class="form-group">
									<select name="rooms"  id="rooms" class="form-control">
										<option value=""   <?php if($this->session->userdata('rooms')==""){echo "SELECTED";}?> >Select Room</option>
										<?php foreach ($rooms as $key => $value) {
											
										 ?>
                             				<option value="<?php echo $value->Id ?>" <?php if($this->session->userdata('rooms')== $value->Id){echo "SELECTED";}?>><?php echo $value->name; ?></option>
										<?php 
										}
										?>
                         			</select>
								</div>
							</div>
							
							 <div class="col-sm-3">
								<div class="form-group">
									<input type="submit" class="btn btn-primary"  value="Search"/>
								</div>
							</div>
						</form>
					</div>
                  
                    <div class="table-responsive">
                    
                    <table class="table table-bordered table-hover" data-page-size="10">
                        <thead>
                        <tr>
                            <th>Event Name</th>
                            <th>Room Name</th>
                            <th>Start Time</th>
                            <th>End Time</th>
                            <th>Attendees</th>
                         </tr>
                        </thead>
                        <tbody>
                        	
                           <?php foreach ($reports as $key => $value) {
							 ?>
							    <tr>
                                	 <td><?php echo $value->subject ?></td>
                                     <td><?php echo $value->room_name ?></td>
                                     <td><?php echo $value->start_date ?></td>
                                     <td><?php echo $value->end_date ?></td>
                                     <td><?php echo $value->attendees ?></td>
						         </tr>

                            <?php 
							}
							?>
                          <?php if(count($reports) == 0){
                          	?>
                              <tr>
                                  <td colspan="6" align="center">No Record</td>
                              </tr>
                          <?php
                          }
                          ?>

                        </tbody>
                        <tfoot>
                             <?php if(!empty($room_detail)){ ?>
                              
                            <tr>
                            	
                                <td colspan="12">
                                    <div class="pagination_ci" style="float:right;"> <?php echo $paginglinks; ?></div>
									<div class="pagination_ci" style="float:left;"> <?php echo (!empty($pagermessage) ? $pagermessage : ''); ?></div>
                                </td>
                            </tr>
                            <?php } ?>
                        </tfoot>
                    </table>
                    
                      <?php if(count($reports)){
                          	?>
                          <a href="<?php echo $this->config->base_url()?>reports_content/export"><span class="btn btn-group btn-success"> Export </span></a>
	                 <?php
                          }
                          ?>
                    </div>
                    
                </div>
            </div>
        </div>
    </div>
 </div>
 

<script type="text/javascript">


$(document).ready(function() {
	
	
	$(document).on('change', '[id^="time_period"]', function(){
  		var val= $(this).val();
  		if(val == "custom"){
  			$(".custom-div").show();
  		}else{
  			$(".custom-div").hide();
  		}
  	});
	$(function () {
	                $('#datetimepicker1').datetimepicker({
	                sideBySide: true,
	                 format : 'MM/DD/YYYY HH:mm:ss'
	            });
	            });
	
	$(function () {
	                $('#datetimepicker2').datetimepicker({
	                sideBySide: true,
	                 format : 'MM/DD/YYYY HH:mm:ss'
	            });
	           });
});
</script>                     