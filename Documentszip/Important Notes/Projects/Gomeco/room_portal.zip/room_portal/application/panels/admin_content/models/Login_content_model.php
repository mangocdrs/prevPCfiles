<?php

class Login_content_model extends MY_Model {
	public function __construct() {
		parent::__construct("rooms");
	}


	function validate() {
		$CI =& get_instance();
		$username = $this -> input -> post('username');
		$password = $this -> input -> post('password');
		$hased_pass=hash("sha256",$password,False);
		
		
		$result = $this->findOneBy(array(
			"email" => $username
		),'users');
		
		if(!isset($result->id)){
			$this -> session -> set_flashdata('error_message', "Invalid Username");
			return FALSE;
		}
		
		
		$result = $this->findOneBy(array(
			"email" => $username,
			"password" => $hased_pass
		),'users');
		
		
		
		if(!isset($result->id)){
			$this -> session -> set_flashdata('error_message', "Invalid Password");
			return FALSE;
		}
		
		
	
		return $result;
	}
	
	
	public function get_token(){
		$sql = "
    		SELECT site_settings.value
    		FROM site_settings
    		WHERE slug='outlook_token'";
		$q = $this->db->query($sql);
		
		$res=$q->result();
		
		if(!empty($res)){
			return $res[0]->value;
		}else{
			return false;
		}
	}

	
}
?>
