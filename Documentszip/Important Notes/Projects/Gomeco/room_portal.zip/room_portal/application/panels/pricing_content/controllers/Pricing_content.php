<?php
if (!defined('BASEPATH')) exit('No direct script access allowed');

class Pricing_content extends MY_Controller {
    	 
		
	public function index() {

		$this -> load -> model('pricing_content/pricing_content_model');
		$success_message=$this->session->flashdata('success_message');
		$error_message=$this->session->flashdata('error_message');
		$data['error_message']= $error_message;
		$data['success_message']= $success_message;
		$data['user_add_data']=$this->session->flashdata('user_add_data');
		$data['user_login_data']=$this->session->flashdata('user_login_data');
		$data['issue_data']=$this->session->flashdata('issue_data');
		$data['feedback_data']=$this->session->flashdata('feedback_data');
		$this->load->view('pricing_content',$data);
    }	

   
  

}
?>
