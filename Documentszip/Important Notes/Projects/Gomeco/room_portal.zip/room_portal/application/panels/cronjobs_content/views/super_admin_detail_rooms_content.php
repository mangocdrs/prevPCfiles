<?php if (isset($success_message) && $success_message!=""){ ?>
<script>
	setTimeout(function() {
	     $.bootstrapGrowl('<?php echo $success_message;?>', {
	         type: 'success',
	         align: 'center',
	         width: 'auto',
	         allow_dismiss: false
	     });
	 }, 1);
</script>
<?php } ?>
<?php
	if (isset($error_message) && $error_message!="" ){ 
		if(!isset($user_add_data['error_message'])){
		?>
	
	<script>
	       setTimeout(function() {
	            $.bootstrapGrowl('<?php echo $error_message;?>', {
	                type: 'danger',
	                align: 'center',
	                width: 'auto',
	                allow_dismiss: false
	            });
	        }, 1);
	    </script>
	   <?php
		
		}
		$error_message =  strip_tags($user_add_data['error_message']);
	    $error_message = str_replace(array("\r", "\n"), '', $error_message);
		$error_message= explode('.',$error_message);
	 	for($i=0; $i<count($error_message)-1; $i++){
  			$error = $error_message[$i];
        	if (isset($error)){ ?>
	        	
        		<script>
	       setTimeout(function() {
	            $.bootstrapGrowl("<?php echo $error;?>", {
	                type: 'danger',
	                align: 'center',
	                width: 'auto',
	                allow_dismiss: false
	            });
	        }, 1);
	    </script>
        		
        		
        	<?php }	}
		 } ?>

<!-- <div id="page-wrapper" class="gray-bg"> -->

<div class="wrapper wrapper-content animated fadeInRight">
     <div class="row">
                    <div class="col-sm-4">
                        <div class="ibox float-e-margins">
                            <div class="ibox-title">
                                <h5>Avg Attendee count</h5>
                              	<span class="label label-success pull-right">30 days</span>
                            </div>
                            <div class="ibox-content">
                                 <h1 class="no-margins"><?php echo $stats['attendee']; ?></h1>
                            </div>
                        </div>
                    </div>
                     <div class="col-sm-4">
                        <div class="ibox float-e-margins">
                            <div class="ibox-title">
                                 <h5>Avg Meeting Length</h5>
                                <span class="label label-success pull-right">30 days</span>
                            </div>
                            <div class="ibox-content">
                                <h1 class="no-margins"><?php echo $stats['meeting_lenght']; ?></h1>
                            </div>
                        </div>
                    </div>
                    <div class="col-sm-4">
                        <div class="ibox float-e-margins">
                            <div class="ibox-title">
                                 <h5>Peak Booking time</h5>
                                <span class="label label-success pull-right">30 days</span>
                            </div>
                            <div class="ibox-content">
                                <h1 class="no-margins"><?php echo $stats['peek_booking']; ?></h1>
                            </div>
                        </div>
                    </div>
		        </div>
                  
    
    <div class="row">
        <div class="col-lg-12">
            <div class="ibox float-e-margins">
                <div class="ibox-title">
                    <h5><?php echo $room[0]->name ?> - Detail</h5>
                    
                </div>
                <div class="ibox-content">
                  
                 
                    <div class="table-responsive">
                    
                    <table class="table table-bordered table-hover" data-page-size="10">
                        <thead>
                        <tr>
                            <th>Event Name</th>
                            <th>Start Time</th>
                            <th>End Time</th>
                            <th>Attendees</th>
                         </tr>
                        </thead>
                        <tbody>
                           <?php foreach ($room_detail as $key => $value) {
                           ?>    
                           
                                <tr>
                                	<td><?php echo $value->subject ?></td>
                                     <td><?php echo $value->start_date ?></td>
                                     <td><?php echo $value->end_date ?></td>
                                     <td><?php echo $value->attendees ?></td>
						         </tr>
							<?php } ?>

                          <?php if(count($room_detail) == 0){
                          	?>
                              <tr>
                                  <td colspan="6" align="center">No Record</td>
                              </tr>
                          <?php
                          }
                          ?>
                        
                        </tbody>
                       
                        <tfoot>
                            <?php if(!empty($room_detail)){ ?>
                              
                                <tr>
                                	
                                    <td colspan="12">
                                        <div class="pagination_ci" style="float:right;"> <?php echo $paginglinks; ?></div>
										<div class="pagination_ci" style="float:left;"> <?php echo (!empty($pagermessage) ? $pagermessage : ''); ?></div>
                                    </td>
                                </tr>
                                <?php } ?>
                        </tfoot>
                    </table>
                  
                    </div>
                    
                </div>
            </div>
        </div>
    </div>
 </div>