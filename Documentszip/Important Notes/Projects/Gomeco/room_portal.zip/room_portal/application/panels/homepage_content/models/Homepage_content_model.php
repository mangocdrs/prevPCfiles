<?php
class Homepage_content_model extends MY_Model {
	public function __construct() {
		
		parent::__construct("");
	}

}
?>
