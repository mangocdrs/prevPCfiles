<!DOCTYPE html>
<html>

<head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Gemoco | Admin Panel</title>
	<link href="<?php echo $this->config->base_url();?>r/manage/css/bootstrap.min.css" rel="stylesheet">
    <link href="<?php echo $this->config->base_url();?>r/manage/font-awesome/css/font-awesome.css" rel="stylesheet">

    <link href="<?php echo $this->config->base_url();?>r/manage/css/plugins/morris/morris-0.4.3.min.css" rel="stylesheet">
	<link rel="stylesheet" href="//cdnjs.cloudflare.com/ajax/libs/bootstrap-select/1.6.3/css/bootstrap-select.min.css" />
	<link href="https://cdn.rawgit.com/Eonasdan/bootstrap-datetimepicker/e8bddc60e73c1ec2475f827be36e1957af72e2ea/build/css/bootstrap-datetimepicker.css" rel="stylesheet">
    
    <link href="<?php echo $this->config->base_url();?>r/manage/css/animate.css" rel="stylesheet">
    <link href="<?php echo $this->config->base_url();?>r/manage/css/style.css" rel="stylesheet">
    <link href="<?php echo $this->config->base_url();?>r/manage/css/jquery.jgrowl.css" rel="stylesheet" type="text/css" />
	<link href="<?php echo $this->config->base_url();?>r/manage/css/plugins/awesome-bootstrap-checkbox/awesome-bootstrap-checkbox.css" rel="stylesheet">


	<script src="<?php echo $this->config->base_url();?>r/manage/js/jquery-2.1.1.js"></script>
    <script src="<?php echo $this->config->base_url();?>r/manage/js/bootstrap.min.js"></script>
   	<script src="<?php echo $this->config->base_url();?>r/manage/js/jquery.bootstrap-growl.js" type="text/javascript"></script>

	
	<script type="text/javascript" src="<?php echo $this->config->base_url(); ?>r/manage/js/jquery.validate.js"></script>
	<script type="text/javascript" src="<?php echo $this->config->base_url(); ?>r/manage/js/jquery-validate.bootstrap-tooltip.js"></script>
	
	
	<script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.9.0/moment-with-locales.js"></script>
	<script src="https://cdn.rawgit.com/Eonasdan/bootstrap-datetimepicker/e8bddc60e73c1ec2475f827be36e1957af72e2ea/src/js/bootstrap-datetimepicker.js"></script>
	<script src="//cdnjs.cloudflare.com/ajax/libs/bootstrap-select/1.6.3/js/bootstrap-select.min.js"></script>
	
	
	

    <script src="<?php echo $this->config->base_url();?>r/manage/js/plugins/metisMenu/jquery.metisMenu.js"></script>
    <script src="<?php echo $this->config->base_url();?>r/manage/js/plugins/slimscroll/jquery.slimscroll.min.js"></script>

    <!-- Custom and plugin javascript -->
    <script src="<?php echo $this->config->base_url();?>r/manage/js/inspinia.js"></script>


  	<script src="<?php echo $this->config->base_url();?>r/manage/js/Notify.js"></script>
  

	

</head>