<?php
if (!defined('BASEPATH')) exit('No direct script access allowed');

class Forgotpassword_content extends MY_Controller {
    	 
		
	public function index() {

		$this -> load -> model('forgotpassword_content/forgotpassword_content_model');
		$success_message=$this->session->flashdata('success_message');
		$error_message=$this->session->flashdata('error_message');
		$data['error_message']= $error_message;
		$data['success_message']= $success_message;
		$data['user_add_data']=$this->session->flashdata('user_add_data');
		$data['user_login_data']=$this->session->flashdata('user_login_data');
		$data['issue_data']=$this->session->flashdata('issue_data');
		$data['feedback_data']=$this->session->flashdata('feedback_data');
		$this->load->view('forgotpassword_content',$data);
    }	


   public function send_password(){
   		$this -> load -> helper('forgotpassword_content/signup_content');
		$this -> load -> model('forgotpassword_content/forgotpassword_content_model');
		$send_password=$this->forgotpassword_content_model->send_password();
	    header("Location:" . $this->config->base_url()."forgotpassword");
   }
  public function change() {

		$this -> load -> model('forgotpassword_content/forgotpassword_content_model');
		$ver_str=$this->input->get('verify');
		if($ver_str!=''){
			$user_id=$this -> forgotpassword_content_model -> verify_user();
		}
		$success_message=$this->session->flashdata('success_message');
		$error_message=$this->session->flashdata('error_message');
		$data['error_message']= $error_message;
		$data['success_message']= $success_message;
		$data['user_add_data']=$this->session->flashdata('user_add_data');
		$data['user_login_data']=$this->session->flashdata('user_login_data');
		$data['issue_data']=$this->session->flashdata('issue_data');
		$data['feedback_data']=$this->session->flashdata('feedback_data');
		$this->load->view('changepassword_content',$data);
    }

  public function change_password(){
	
	$this -> load -> model('forgotpassword_content/forgotpassword_content_model');
	$send_password=$this->forgotpassword_content_model->change_password();
	if($send_password){
		
		$this->session->set_flashdata('success_message','Password reset login to continue');
		header("Location:" . $this->config->base_url()."login");
		exit;
	}
	else{
		
		$this->session->set_flashdata('error_message','Some Problem Occured try again');
		header("Location:" . $this->config->base_url()."forgotpassword");
	
		exit;
	}
	header("Location:" . $this->config->base_url()."forgotpassword");
	
 }



}
?>
