<?php
if (!defined('BASEPATH')) exit('No direct script access allowed');

class Services_content extends MY_Controller {
	

	public function __construct(){
		parent::__construct();
	}
	
	
	public function user_view_all_services(){
		
		$access=$this->check_user();
		$this->panels_check_permission($access);
		
		$success_message=$this->session->flashdata('success_message');
		$error_message=$this->session->flashdata('error_message');
		$user_add_data=$this->session->flashdata('user_add_data');
    	$data['error_message']= $error_message;
		$data['success_message']= $success_message;
		$data['user_add_data']=$user_add_data;	
		
		$this -> load -> model('services_content/services_content_model');
		$services = $this->services_content_model->get_service_account_detail();
		$data['services']=$services;	
		
		
		$this->load->view('user_view_services_content',$data);
	}
	
	public function user_update_services(){
		
		$access=$this->check_user();
		$this->panels_check_permission($access);
		
		$services = $this->input->post("service_url");
		
		$file_content = file_get_contents(base_url()."uploads/SampleServices.wsdl");
		$file_content = str_replace("[SampleServices]", $services, $file_content);
		
		
		
		 $path = getcwd().DIRECTORY_SEPARATOR."uploads".DIRECTORY_SEPARATOR."Services.wsdl";
		$myfile = fopen($path, "w") or die("Unable to Write Services.wsdl file! Check file permission");
		//exit;
		fwrite($myfile, $file_content);
		fclose($myfile);
		
		
		$this -> load -> model('services_content/services_content_model');
		
		
		$image_name = "";		
		if($_FILES['userfile']['name']!=''){
			
			$file=$_FILES['userfile'];
			$this->load->library("Fileuploader");
			$result_file_names=$this->fileuploader->do_upload("logo",$_FILES['userfile']['name'],"userfile");
			if($result_file_names['status'] == "Failure"){
				$this->session->set_flashdata('error_message', $result_file_names['message']);
				header("Location:" . $_SERVER['HTTP_REFERER']);
				exit;
			}
			
			$image_name = $result_file_names['file_name'];
		}
		
		
		
		
		
		
		$this->services_content_model->update_service_account_detail($image_name);
		
		$this -> session -> set_flashdata('success_message', "Settings updated successfully");
		header("Location:" . $_SERVER['HTTP_REFERER']);
		exit;
	}
	
	
}