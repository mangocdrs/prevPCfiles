<?php

class Signup_content_model extends MY_Model {
	public function __construct() {
		
		parent::__construct("");
	}
	public function add_user(){
		
		$check_user = $this->findOneBy(array(
				"email" => $this->input->post('email')
			),'users');
			
		if(empty($check_user)){
			$email=$this->input->post('email');
	        $random_string=$this ->generateRandomString();
			$params=array(
				'first_name'=>$this->input->post('first_name'),
	   			'last_name'=>$this->input->post('last_name'),
				'email'=>$this->input->post('email'),
	   			'password'=>hash('sha256',$this->input->post('password')),
	   			'user_category'=>$this->input->post('category'),
	   			'status'=>'pending',
	   			'verification_string'=>$random_string,
	   			'user_type'=>'user'
			);
			$params['date_created'] = date('Y-m-d H:i:s');
			$user_id=$this->insert($params,'users');
			$reset_link=$this->config->base_url().'login?verify='.$random_string;
	        $email_content=$this ->get_email_template('singup_verification');
			if(empty($email_content)){
				
		    	$email_contentt_full='Please click on following link to verify your email <br> '.$reset_link ;
				
			}else{
				
				$email_contentt_full=str_replace('{link}', $reset_link, $email_content->html_body);
				
			}
			
			//$this ->send_email('Verify Email',$email_contentt_full,$email ,'Gameco','admin@gameco.com');
			
			$this ->send_email($email_content->subject,$email_contentt_full,$email ,$email_content->sender_name,$email_content->sender_email);
			
		    $this->session->set_flashdata('success_message','Confirmation Email Sent Please Check your Email');
				
			return $user_id;
		}
		else{
			
			$this -> session -> set_flashdata('error_message', "Email already Registered");
		    return false;
		}	
		
		
	}
	
	





}
?>
