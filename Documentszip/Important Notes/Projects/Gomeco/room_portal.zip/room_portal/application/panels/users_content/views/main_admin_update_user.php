<?php if (isset($success_message) && $success_message!=""){ ?>
<script>
	setTimeout(function() {
	     $.bootstrapGrowl('<?php echo $success_message;?>', {
	         type: 'success',
	         align: 'center',
	         width: 'auto',
	         allow_dismiss: false
	     });
	 }, 1);
</script>
<?php } ?>
<?php
	if (isset($error_message) && $error_message!="" ){ 
		if(!isset($user_add_data['error_message'])){
		?>
<script>
	setTimeout(function() {
	     $.bootstrapGrowl('<?php echo $error_message;?>', {
	         type: 'danger',
	         align: 'center',
	         width: 'auto',
	         allow_dismiss: false
	     });
	 }, 1);
</script>
<?php
	}
	$error_message =  strip_tags($user_add_data['error_message']);
	   $error_message = str_replace(array("\r", "\n"), '', $error_message);
	$error_message= explode('.',$error_message);
		for($i=0; $i<count($error_message)-1; $i++){
				$error = $error_message[$i];
	      	if (isset($error)){ ?>
<script>
	setTimeout(function() {
	     $.bootstrapGrowl("<?php echo $error;?>", {
	         type: 'danger',
	         align: 'center',
	         width: 'auto',
	         allow_dismiss: false
	     });
	 }, 1);
</script>
<?php }	}
	} ?>
<div class="wrapper wrapper-content animated fadeInRight">
	<div class="row">
		<div class="col-lg-12">
			<div class="ibox float-e-margins">
				<div class="ibox-title">
					<h5>Update User</h5>
				</div>
				<div class="ibox-content">
					<form  method="post" action="<?php echo $this->config->base_url();?>users_content/main_admin_update_user" class="form-horizontal" id="update_user_form" name="update_user_form"  enctype="multipart/form-data">
						<div class="form-group">
							<label class="col-sm-2 control-label">Name*</label>
							<div class="col-sm-4">
								<input type="text" placeholder="First Name" class="form-control"  name="first_name" id="name" value="<?php echo $result->first_name; ?>" >
							</div>
							<label class="col-sm-2 control-label">Last Name*</label>
							<div class="col-sm-4">
								<input type="text" placeholder="Last Name" class="form-control"  name="last_name" id="last_name" value="<?php echo $result->last_name; ?>">
							</div>
						</div>
						<div class="form-group">
							<label class="col-sm-2 control-label">Username*</label>
							<div class="col-sm-4">
							<!-- <span>
								<div class='input-group'>
							 -->		
							 <input class='form-control' name="email" id="email" placeholder="Email" value="<?php echo str_replace("@sita.aero", "", $result->email); ?>" id="email"/>
									<!-- <span class='input-group-addon'>@sita.aero</span> -->
								<!-- </div> -->
							<!-- </span> -->
							</div>
							<label class="col-sm-2 control-label">Password</label>
							<div class="col-sm-4">
								<input type="password" autocomplete="new-password" placeholder="Password" class="form-control"  name="password" id="password">
							</div>
						</div>
						<div class="form-group">
							<label class="col-sm-2 control-label">Category*</label>
							<div class="col-sm-4">
								<select class="form-control m-b" name="user_category" id="user_category">
									<option value="" <?php if(isset($result->user_category) && $$result->user_category=='') {echo "selected";}?>>Select User Category</option>
									<option value="ews" <?php if(isset($result->user_category) && $result->user_category=='ews') {echo "selected";}?>>ews</option>
									<option value="aws" <?php if(isset($result->user_category) && $result->user_category=='aws') {echo "selected";}?>>aws</option>
								</select>
							</div>
							</div>
						<div class="form-group" style="display: none">
							<label class="col-sm-2 control-label">Status*</label>
							<div class="col-sm-4">
								<select name="user_type" class="form-control">
									<option  selected value="">Select Type</option>
									<option value="client" <?php if($result->user_type=="user"){echo "SELECTED";}?>>User</option>
									<option value="main_admin" <?php if($result->user_type=="smain_admin"){echo "SELECTED";}?>>Main Admin</option>
								</select>
							</div>
						</div>
						<div class="hr-line-dashed"></div>
						<div class="form-group">
							<div class="col-sm-7 col-sm-offset-2 pull-right">
								<a href="<?php echo $this->config->base_url(); ?>allusers/view" class="btn btn-white" >Cancel</a>
									<input type="hidden" name="user_id" id="user_id" value="<?php echo $result->id;?>">  
									<button class="btn btn-primary" type="submit">Update</button>
							</div>
						</div>
					</form>
				</div>
			</div>
		</div>
	</div>
</div>
<script type="text/javascript">
	$.validator.addMethod("alpha", function(value, element) {
	  return this.optional(element) |/^[a-zA-Z]+$/.test(value);
	 }, "Only Alphabets Allowed");
	
	 $.validator.addMethod("alpha_space", function(value, element) {
	  return this.optional(element) |/^[a-zA-Z\s]+$/.test(value);
	 }, "Only Alphabets and spaces Allowed");
	 
	 $.validator.addMethod("character", function(value, element) {
	  return this.optional(element) |/^[0-9]+$/.test(value);
	 }, "Only Number Allowed");
	
	$.validator.addMethod("floats", function(value, element) {
	  return this.optional(element) |/^[0.0-9]+$/.test(value);
	 }, "Only fload value Allowed");
	
	$.validator.addMethod("Email", function(value, element) {
	  return this.optional(element) |/^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/.test(value);
	 }, "Valid email only");
	
	
	
	
	   $("#update_user_form").validate({
	       rules: {
	        first_name: {required: true},
	        last_name: {required: true},
	        email: {required: true,Email:true},
	        status: {required: true},
	        },
	  messages: {
	                firstname:{required: "First Name Field is Required"},
	                last_name:{required: "Last Name Field is Required"},
	                email:{required: "Username Field is Required",Email:"Username Not Valid"},
	                status:{required: "Status Field is Required"},
	                user_type:{required: "User Type Field is Required"},
	     }       ,
	            tooltip_options: {
	       
	            }
	});
</script>