<?php
if (!defined('BASEPATH')) exit('No direct script access allowed');

class Terms_content extends MY_Controller {
    	 
		
	public function index() {

		$this -> load -> model('terms_content/terms_content_model');
		$success_message=$this->session->flashdata('success_message');
		$error_message=$this->session->flashdata('error_message');
		$data['error_message']= $error_message;
		$data['success_message']= $success_message;
		$data['user_add_data']=$this->session->flashdata('user_add_data');
		$data['user_login_data']=$this->session->flashdata('user_login_data');
		$data['issue_data']=$this->session->flashdata('issue_data');
		$data['feedback_data']=$this->session->flashdata('feedback_data');
		$this->load->view('terms_content',$data);
    }	

   public function submit_request(){
		$this -> load -> helper('terms_content/terms_content');
		$this -> load -> model('terms_content/terms_content_model');
		$request_validation = request_validation();
		if ($request_validation) {
			$user_id=$this -> terms_content_model -> submit_request();
			if($user_id){
				
			header("Location:" . $this->config->base_url());
   			exit;	
			}
			
		    header("Location:" . $_SERVER['HTTP_REFERER']);
   			exit;
		}else{
			$this -> session -> set_flashdata('userdata',"");
			header("Location:" . $_SERVER['HTTP_REFERER']);
			exit;
		}
   }
  

}
?>
