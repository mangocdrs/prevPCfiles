<?php

class Forgotpassword_content_model extends MY_Model {
	public function __construct() {
		
		parent::__construct("");
	}
	
	
	public function send_password(){
		$email=$this->input->post('email');
		$result = $this->findOneBy(array(
			"email" => $this->input->post('email'),
		),'users');
		$random_string=$this ->generateRandomString();
		if(isset($result->id)){
			$update_in_user=array(
			'pw_reset_string'=>$random_string
		);
		
		$this ->update($update_in_user,"email='$email'",'users');
		
		$reset_link=$this->config->base_url().'forgotpassword/change?reset='.$random_string;
	    $email_content=$this ->get_email_template('reset_password');
		if(empty($email_content)){
				
		    $email_contentt_full='Please click on following link to Change your password<br> '.$reset_link ;
				
		}else{
				
			$email_contentt_full=str_replace('{link}', $reset_link, $email_content->html_body);
				
		}
		echo $email;
			
		$this ->send_email($email_content->subject,$email_contentt_full,$email ,$email_content->sender_name,$email_content->sender_email);
		
		$this->session->set_flashdata('success_message','Please Check your email for reset link');
		$this->session->set_flashdata('error_message','');
		}
		else{
			$data = array(
	        	
	            'email' => $email,
	           
	    		);
			$this->session->set_flashdata('user_add_data', $data);	
			$this->session->set_flashdata('success_message','');
			$this->session->set_flashdata('error_message','Email Not Registered');
			return false;
		}
		
		
	}
	
	public function change_password(){
	
	$reset=$this->input->post('reset');
	$new_password=$this->input->post('password');
	$result = $this->findOneBy(array(
			"pw_reset_string" => $reset,	
		),'users');
		
	if($result->id){	
	$insert_in_user=array(
			'pw_reset_string'=>'',
			'password'=>hash('sha256',$new_password)
		);
		
		$this->update($insert_in_user,"id='$result->id'",'users');
		
		return true;	
	}
	
	return false;
	
 }


}
?>
