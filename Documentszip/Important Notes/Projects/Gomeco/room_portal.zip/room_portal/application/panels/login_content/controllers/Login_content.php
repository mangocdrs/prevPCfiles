<?php
if (!defined('BASEPATH')) exit('No direct script access allowed');

class Login_content extends MY_Controller {
    	 
		
	public function index() {

		$this -> load -> model('login_content/login_content_model');
		$ver_str=$this->input->get('verify');
		if($ver_str!=''){
			$user_id=$this -> login_content_model -> verify_user();
		}
		$success_message=$this->session->flashdata('success_message');
		$error_message=$this->session->flashdata('error_message');
		$data['error_message']= $error_message;
		$data['success_message']= $success_message;
		$data['user_add_data']=$this->session->flashdata('user_add_data');
		$data['user_login_data']=$this->session->flashdata('user_login_data');
		$data['issue_data']=$this->session->flashdata('issue_data');
		$data['feedback_data']=$this->session->flashdata('feedback_data');
		$this->load->view('login_content',$data);
    }	


   public function user_login(){
   		$this -> load -> helper('login_content/signup_content');
		$this -> load -> model('login_content/login_content_model');
		$validate_singin = singin_validation();
		if ($validate_singin) {
			$validate = $this -> login_content_model -> login_user();
			//print_r($validate->email);exit;
			if($validate){
				save_user_session($validate);
				$this -> session -> set_flashdata('success_message', "Login Successfully");
				if($validate->user_type == "main_admin"){
					header("Location:" . $this -> config -> base_url() . "allusers/view");
					exit;
				}else{
					header("Location:" . $this -> config -> base_url() . "rooms/view");
					exit;
				}
		 	}
			else{
				
			header("Location:" . $this->config->base_url()."login");
				exit;	
			}
			
			header("Location:" . $this->config->base_url());
			
			exit;
		
		}else{
			$this -> session -> set_flashdata('error_message',"Error");
		    
			header("Location:" . $this->config->base_url()."login");
			exit;
		}
   }




	public function logout() {
		if (isset($_COOKIE[session_name()]))
			setcookie(session_name(), "", time() - 3600, "/");
		$_SESSION = array();
		$this->session->unset_userdata('user_id');				
		$this->session->unset_userdata('first_name');				
	    $this->session->unset_userdata('last_name');				
	    $this->session->unset_userdata('email');				
	    $this->session->unset_userdata('status');				
	    $this->session->unset_userdata('user_type');
		$this->session->unset_userdata('user_latitude');
		$this->session->unset_userdata('user_longitude');
		$this->session->unset_userdata('home_city');
		unset($this -> session -> userdata);
		$this -> session -> sess_destroy();
		 header("Location:" . $this->config->base_url());
		exit ;
	}


}
?>
