<?php

class Reports_content_model extends MY_Model {
	public function __construct() {
		parent::__construct("rooms");
	}


	public function get_all_reports_count(){
		
		$where = "";
		$where_search = array();
		
		if($this->uri->slash_segment(2)=="search/"  || $this->uri->slash_segment(2)=="export/")
		{
			if(!$_POST)
			{
				$time_period= $this->session->userdata("time_period");
				$from_time= $this->session->userdata("from_time");
				$to_time= $this->session->userdata("to_time");
				$rooms= $this->session->userdata("rooms");
				$event_name= $this->session->userdata("event_name");
			
			}else{
			
				$time_period=$this->input->post("time_period");
				$from_time=$this->input->post("from_time");
				$to_time=$this->input->post("to_time");
				$rooms=$this->input->post("rooms");
				$event_name=$this->input->post("event_name");
				$newdata = array(
						'time_period'  => $time_period,
						'from_time'  => $from_time,
						'to_time'  => $to_time,
						'rooms'  => $rooms,
						'event_name'  => $event_name,
				);
				$this->session->set_userdata($newdata);
			}	
			
			if($time_period == "week"){
				$date = date('Y-m-d H:i:s', strtotime('today - 7 days'));
				$date = new \DateTime('7 days ago');
				$where_search[] = "start_date >= '$date'";
			}
			
			if($time_period == "month"){
				$date = date('Y-m-d H:i:s', strtotime('today - 30 days'));
				$date = new \DateTime('7 days ago');
				$where_search[] = "start_date >= '$date'";
			}
			if($time_period == "year"){
				$date = date('Y-m-d H:i:s', strtotime('today - 365 days'));
				$date = new \DateTime('7 days ago');
				$where_search[] = "start_date >= '$date'";
			
        	}
			if($rooms){
				$where_search[] = "room_id = '$rooms'";
        	}
			
			if($event_name){
				$where_search[] = "subject = '$event_name'";
        	}
			
			
			if($time_period == "custom"){
			
				if(strlen($from_time)){
					$from_time =$this->convert_date_new($from_time);
					$where_search[] = "start_date >= '$from_time'";
        		}
				if(strlen($to_time)){
					$to_time =$this->convert_date_new($to_time);
					$where_search[] = "end_date <= '$to_time'";
        	
				}
			}
			
			
			$where_search = implode(" and ", $where_search);
			
			if(strlen($where_search)){
				if($where){
					$where = $where." and ".$where_search;
				}else{
					$where = $where_search;
				}
			
			}
			
		}
		
		
		$result= $this->count($where,"meetings");
		
		
		
		
		return $result;
	}


	public function get_all_reports_detail($offset,$limit){
	
		$where = "";

		$where_search = array();
		$params=array(
			'select'=>"*",
			'from'=> "meetings",
			"page" => $offset,
        	"limit" => $limit,
        	"order_by" =>"id DESC",
			);
		
		/*******/

		if($this->uri->slash_segment(2)=="search/"  || $this->uri->slash_segment(2)=="export/")
		{
			if(!$_POST)
			{
				$time_period= $this->session->userdata("time_period");
				$from_time= $this->session->userdata("from_time");
				$to_time= $this->session->userdata("to_time");
				$rooms= $this->session->userdata("rooms");
				$event_name= $this->session->userdata("event_name");
			
			}else{
			
				$time_period=$this->input->post("time_period");
				$from_time=$this->input->post("from_time");
				$to_time=$this->input->post("to_time");
				$rooms=$this->input->post("rooms");
				$event_name=$this->input->post("event_name");
				$newdata = array(
						'time_period'  => $time_period,
						'from_time'  => $from_time,
						'to_time'  => $to_time,
						'rooms'  => $rooms,
						'event_name'  => $event_name,
				);
				$this->session->set_userdata($newdata);
			}	
			
			if($time_period == "week"){
				$date = date('Y-m-d H:i:s', strtotime('today - 7 days'));
				$where_search[] = "start_date >= '$date'";
			}
			
			if($time_period == "month"){
				$date = date('Y-m-d H:i:s', strtotime('today - 30 days'));
				$where_search[] = "start_date >= '$date'";
			}
			if($time_period == "year"){
				$date = date('Y-m-d H:i:s', strtotime('today - 365 days'));
				$where_search[] = "start_date >= '$date'";
			
        	}
			if($rooms){
				$where_search[] = "room_id = '$rooms'";
        	}
			
			if($event_name){
				$where_search[] = "subject = '$event_name'";
        	}
			
			
			if($time_period == "custom"){
			
				if(strlen($from_time)){
					$from_time =$this->convert_date_new($from_time);
					$where_search[] = "start_date >= '$from_time'";
        		}
				if(strlen($to_time)){
					$to_time =$this->convert_date_new($to_time);
					$where_search[] = "end_date <= '$to_time'";
        	
				}
			}
			
			
			$where_search = implode(" and ", $where_search);
			
			if(strlen($where_search)){
				if($where){
					$where = $where." and ".$where_search;
				}else{
					$where = $where_search;
				}
			
			}
		}else{
			$this->session->unset_userdata("time_period");
			$this->session->unset_userdata("from_time");
			$this->session->unset_userdata("to_time");
			$this->session->unset_userdata("rooms");
			$this->session->unset_userdata("rooms");
		}
		/********/
		
		if(strlen($where)){
			$params['where']=$where;
		}
		$result=$this->find($params);
		
		
		$index = 0;
		foreach ($result as $key => $value) {
			$users = $this->findOneBy(array(
				"Id" => $value->room_id,
			),'rooms');
			
			$result[$index]->room_name = $users->name;
			$result[$index]->start_date = $this->revert_date_new($value->start_date);
			$result[$index]->end_date = $this->revert_date_new($value->end_date);
			
			
			$index++;
		}
		
		return $result;
		/*******/
	}
	// public function convert_date($date){
		// if(strlen($date)){
			// $to_array = explode(" ", $date);
	 	 	// $to_date = $to_array[0];
	 	 	// $to_time = $to_array[1];
	 	 	// $to_date = explode("/", $to_date);
	 	 	// $date = $to_date[2]."-".$to_date[0]."-".$to_date[1]." ".$to_time;	
// 				
			// $date = date_create($date);
	 		// $date = date_format($date, "Y-m-d H:i:s");
			// return  $date;	
		// }else{
			// return null;
		// }	
// 			
	// }
// 	
// 	
	
	public function get_rooms_detail()
	{
		$params=array(
			'select'=>"Id, name",
			'from'=> "rooms"
			);
		$result=$this->find($params);
		
		return $result;
	}
	
}
?>
