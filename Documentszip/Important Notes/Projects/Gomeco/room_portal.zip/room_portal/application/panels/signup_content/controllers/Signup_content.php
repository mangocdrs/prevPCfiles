<?php
if (!defined('BASEPATH')) exit('No direct script access allowed');

class Signup_content extends MY_Controller {
    	 
		
	public function index() {

		$this -> load -> model('signup_content/signup_content_model');
		$success_message=$this->session->flashdata('success_message');
		$error_message=$this->session->flashdata('error_message');
		$data['error_message']= $error_message;
		$data['success_message']= $success_message;
		$data['user_add_data']=$this->session->flashdata('user_add_data');
		$data['user_login_data']=$this->session->flashdata('user_login_data');
		$data['issue_data']=$this->session->flashdata('issue_data');
		$data['feedback_data']=$this->session->flashdata('feedback_data');
		$this->load->view('signup_content',$data);
    }	

   public function user_singup(){
		$this -> load -> helper('signup_content/signup_content');
		$this -> load -> model('signup_content/signup_content_model');
		$validate_singup = singup_validation();
		if ($validate_singup) {
			$user_id=$this -> signup_content_model -> add_user();
			if($user_id){
				
			header("Location:" . $this->config->base_url());
   			exit;	
			}
			
		    header("Location:" . $_SERVER['HTTP_REFERER']);
   			exit;
		}else{
			$this -> session -> set_flashdata('userdata',"");
			header("Location:" . $_SERVER['HTTP_REFERER']);
			exit;
		}
   }
  
   




  public function forgot_password()
   {
	$this -> load -> model('signup_content/signup_content_model');
	$send_forgot_mail = $this -> signup_content_model -> send_forgot_mail();
	if ($send_forgot_mail) {
		//$this -> session -> set_flashdata('success_message',"Please check your email for Password reset link");
	}
	else{
			header("Location:" . $_SERVER['HTTP_REFERER']);
			exit;
		}
      header("Location:" . $_SERVER['HTTP_REFERER']);
   }
public function reset_password(){
	
		$this -> load -> model('signup_content/signup_content_model');
		$reset_password = $this -> signup_content_model ->reset_password();
		
		 header("Location:" . $this->config->base_url());	
}



}
?>
