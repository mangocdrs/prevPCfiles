<?php

class Rooms_content_model extends MY_Model {
	public function __construct() {
		parent::__construct("rooms");
	}



	public function get_user_rooms($unique_name = NULL){
		$params=array(
			'select'=>"Id,name,unique_name,email,capacity,support_email",
			'from'=> "rooms",
		);
		if($unique_name != NULL){
			$params['where'] = "unique_name = '$unique_name'";
		}
		$result=$this->find($params);
		return $result;
		/*******/
	}


	public function get_service_account_detail(){
		$params=array(
			'select'=>"*",
			'from'=> "services_account_detail",
		);
		$result=$this->find($params);
		return $result;
		/*******/
	}
	

	function submit_bug() {
		
		//$CI =& get_instance();
		$data=array(
		"name"=>$this->input->post("name"),
		"email" => $this->input->post("email"),
		"message" => $this->input->post("cancel_message"),
		"location_unique_id" => $this->input->post("room_id")
		);
		
		$this->insert($data,"report_bug");
		return 1;
				
	}
	function update_refresh_token($id,$token) {
		
		//$CI =& get_instance();
		$data=array(
			"refresh_token"=>$token,
			"date_updated" => date("Y-m-d H:i:s")
		);
		
		$this->update($data,'id = '.$id,"organizations");
		return TRUE;
				
	}
	

	
	
	public function get_token($refresh_token){
		
		// scope="openid+
				// offline_access+
				// profile+
				// https://outlook.office.com/calendars.readwrite+
				// https://outlook.office.com/calendars.readwrite.shared+
				// https://outlook.office.com/contacts.readwrite+
				// https://outlook.office.com/contacts.readwrite.shared+
				// https://outlook.office.com/tasks.readwrite+
				// https://outlook.office.com/tasks.readwrite.shared+
				// https://outlook.office.com/user.readbasic.all"
		
		$result = $this->findOneBy(array(
			"slug" => "outlook_client_id"
		),'site_settings');
				
		$outlook_client_id = $result->value;
		
		$result = $this->findOneBy(array(
			"slug" => "outlook_client_secret_key"
		),'site_settings');
		$outlook_client_secret_key = $result->value;
		
		$url = 'https://login.microsoftonline.com/common/oauth2/v2.0/token';
		$fields = array(
			'grant_type' => "refresh_token",
			// 'redirect_uri' => "https://login.live.com/oauth20_desktop.srf",
			'refresh_token' => $refresh_token,
			'client_id' => $outlook_client_id,
			'scope' => "openid+offline_access+profile+https://outlook.office.com/calendars.readwrite+https://outlook.office.com/calendars.readwrite.shared+https://outlook.office.com/contacts.readwrite+https://outlook.office.com/contacts.readwrite.shared+https://outlook.office.com/tasks.readwrite+https://outlook.office.com/tasks.readwrite.shared+https://outlook.office.com/user.readbasic.all"
		);
		
		//url-ify the data for the POST
		$fields_string = "";
		foreach($fields as $key=>$value) {
			 $fields_string .= $key.'='.$value.'&'; 
		}
		rtrim($fields_string, '&');
		
		//open connection
		$ch = curl_init();
		//set the url, number of POST vars, POST data
		curl_setopt($ch,CURLOPT_URL, $url);
	    curl_setopt($ch,CURLOPT_RETURNTRANSFER,true);
		curl_setopt($ch,CURLOPT_POST, count($fields));
		curl_setopt($ch,CURLOPT_POSTFIELDS, $fields_string);
		//execute post
		$result = curl_exec($ch);
		
		//close connection
		curl_close($ch);

		return json_decode($result);
	}
	
	public function get_organization($email){
		$result = $this->findOneBy(array(
			"email" => $email
		),'organizations');
		return $result;
	}
	
	
	
	
	public function get_all_rooms_count(){

		$result= $this->count(' user_id = '.$this->session->user_id,"rooms");
		return $result;
	}
	
	
	public function get_all_rooms_detail($offset,$limit){
        $user_id=$this->session->user_id;
		$params=array(
			'select'=>"*",
			'from'=> "rooms",
			"page" => $offset,
        	"limit" => $limit,
        	"where" => "  user_id=$user_id "
        	// "order_by" =>"id DESC",
		);
		
		$result=$this->find($params);
		return $result;
		/*******/
	}
	
	
	
	public function add_room(){
		$uid=$this->session->user_id;
		$count = $this->count(" user_id=$uid ","rooms");
		
		if($count >= ROOMS_LIMIT){
			$this->session->set_flashdata('user_add_data',array());
			$this->session->set_flashdata('error_message','You have reached your license limit. Please email support@gomeco.com');
			return FALSE;
		}
		$room_name=$this->input->post("room_name");
		$room_unique_name=$this->input->post("room_unique_name");
		$email=$this->input->post("email");
		// $password=$this->input->post("password");
		$capacity=$this->input->post("capacity");
		$info=$this->input->post("info");
		$support_email = $this->input->post("support_email");
		
		$wheres=' "random_num" NOT IN (SELECT unique_id FROM rooms )';
        $paramsn=array(
			'select'=>" FLOOR(RAND() * 999999)+100000 AS random_num ",
			'from'=> "rooms",
        	"limit" => 1,
			);
		
		if(strlen($wheres)){
			$paramsn['where']=$wheres;
		}
		$resultluk=$this->find($paramsn);
		if(isset($resultluk[0]->random_num)){
			
			$unique_id=$resultluk[0]->random_num;
		}
		else{
			
			$unique_id=rand(100000, 999999);
		}
			
	
		$insert_in_user=array(
			'name'=>$room_name,
			'unique_name'=>$room_unique_name,
			'date_created'=>date("Y-m-d H:i:s"),
			'email'=>$email,
			'capacity'=>$capacity,
			'info'=>$info,
			'support_email' =>$support_email,
			'unique_id' => $unique_id,
			'user_id' => $this->session->user_id
            // 'password'=>base64_encode($password),
			);
		
		$result_inserted=$this->insert($insert_in_user,'rooms');
		return $result_inserted;
	}
	
	
	public function update_room(){
			
		$room_name=$this->input->post("room_name");
		$room_unique_name=$this->input->post("room_unique_name");
		$email=$this->input->post("email");
		// $password=$this->input->post("password");
		$room_id=$this->input->post("room_id");
		$capacity=$this->input->post("capacity");
		$info=$this->input->post("info");
		$support_email = $this->input->post("support_email");
		
	
		$insert_in_user=array(
			'name'=>$room_name,
			'unique_name'=>$room_unique_name,
			'date_updated'=>date("Y-m-d H:i:s"),
			'email'=>$email,
			'capacity'=>$capacity,
			'info'=>$info,
			'support_email' =>$support_email,
            
			// 'password'=>base64_encode($password),
			);
		
		$this->update($insert_in_user,"Id = '$room_id'","rooms");
		return TRUE;
	}
	public function getroombyid($roomid){
		$params=array(
			'select'=>"Id,name,unique_name,email,capacity,info,support_email",
			'from'=> "rooms",
		);
		$params['where'] = "Id = '$roomid'";
		$result=$this->find($params);
		return $result;
		/*******/
	}
	
	
	public function get_room_stats($room_id){
		
		$start = date('Y-m-d H:i:s', strtotime('today - 30 days'));
			
		$params=array(
			'select'=>"*",
			'from'=> "meetings",
			'where'=> "room_id = '$room_id'
					 and start_date > '$start'"	
		);
		$result=$this->find($params);
		
		$attendee = 0;
		$meeting_lenght = 0;
		$peek_booking = array();
		
		$index = 0;
		foreach ($result as $key => $value) {
			$attendee += $value->attendees;
			$to_time = strtotime($value->end_date);
			$from_time = strtotime($value->start_date);
			$meeting_lenght += round(abs($to_time - $from_time) / 60,2);
			
			$peek_booking[] =  date('H', $from_time);			
			$index++;
		}
		// echo $meeting_lenght;
		$peek_booking = array_count_values($peek_booking);
		if(count($peek_booking)){
			foreach ($peek_booking as $key => $value) {
					
				if($value == 1){
					$peek_booking = "---";
					
				}else{
					
					if($key == 24){
						$peek_booking = $key." to 1";
					}else{
						
						$peek_booking = (string)$key. ' to ' .(string) ($key+1);
					}
					
				}
				
			}	
		}else{
			$peek_booking = "---";
		}
		
		// echo $index;
		if($index != 0){
			$data['attendee'] = round($attendee/$index);
			$data['meeting_lenght'] = round($meeting_lenght/$index)." Minutes";
		}else{
			$data['attendee'] = 0;
			$data['meeting_lenght'] = "0 Minute";
		}
		$data['peek_booking'] = $peek_booking;
		
		
		return $data;
	}


	public function get_all_room_meetings_count($roomid){
		$where = "room_id = ".$roomid;
		$result= $this->count($where,"meetings");
		return $result;
	}
	
	
	public function get_all_room_meetings_detail($roomid,$offset,$limit){

		$params=array(
			'select'=>"*",
			'from'=> "meetings",
			"page" => $offset,
        	"limit" => $limit,
        	"where" => "room_id = ".$roomid,
        	"order_by" =>"id DESC",
		);
		
		$result=$this->find($params);
		return $result;
		/*******/
	}
	public function delete_room($roomid)
	{
		$this->delete("Id = '".$roomid."'","rooms");
	}	
}
?>
