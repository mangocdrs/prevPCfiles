<?php if (isset($success_message) && $success_message!=""){ ?>
<script>
	setTimeout(function() {
	     $.bootstrapGrowl('<?php echo $success_message;?>', {
	         type: 'success',
	         align: 'center',
	         width: 'auto',
	         allow_dismiss: false
	     });
	 }, 1);
</script>
<?php } ?>
<?php
	if (isset($error_message) && $error_message!="" ){ 
		if(!isset($user_add_data['error_message'])){
		?>
	
	<script>
	       setTimeout(function() {
	            $.bootstrapGrowl('<?php echo $error_message;?>', {
	                type: 'danger',
	                align: 'center',
	                width: 'auto',
	                allow_dismiss: false
	            });
	        }, 1);
	    </script>
	   <?php
		
		}
		$error_message =  strip_tags($user_add_data['error_message']);
	    $error_message = str_replace(array("\r", "\n"), '', $error_message);
		$error_message= explode('.',$error_message);
	 	for($i=0; $i<count($error_message)-1; $i++){
  			$error = $error_message[$i];
        	if (isset($error)){ ?>
	        	
        		<script>
	       setTimeout(function() {
	            $.bootstrapGrowl("<?php echo $error;?>", {
	                type: 'danger',
	                align: 'center',
	                width: 'auto',
	                allow_dismiss: false
	            });
	        }, 1);
	    </script>
        		
        		
        	<?php }	}
		 } ?>

<!-- <div id="page-wrapper" class="gray-bg"> -->

			<div class="wrapper wrapper-content animated fadeInRight">
        
            <div class="row">
                <div class="col-lg-12">
                    <div class="ibox float-e-margins">
                        <div class="ibox-title">
                            <h5>Update Services Account Detail</h5>
                        </div>
                        <div class="ibox-content">
                              <form  method="post" action="<?php echo $this->config->base_url();?>services_content/user_update_services" class="form-horizontal" id="create_admin_form" name="create_admin_form" enctype="multipart/form-data">
                               
                                
                                <div class="form-group">
                                	
                                	
                                	<div class="form-group">
	                                	<label class="col-sm-2 control-label">Display Option</label>
	                                    <div class="col-sm-10">
	                                    	<select class="form-control" name="display_option" id="display_option">
	                                    		<option value="name" <?php if(isset($services[0]) && $services[0]->type == "name"){echo "Selected";}?> >Organization Name</option>
	                                    		<option value="image" <?php if(isset($services[0]) && $services[0]->type == "image"){echo "Selected";}?> >Organization Image</option>
	                                    	</select>
	                                    </div>
	                                </div>
                                	
                                	<div class="form-group organization_name_div" <?php if(isset($services[0]) && $services[0]->type == "name"){echo "style=display:block";}else{echo "style=display:none";}?>>
	                                	<label class="col-sm-2 control-label">Organization Name</label>
	                                    <div class="col-sm-10"><input type="text" placeholder="Enter Organization Name" class="form-control"  name="organization_name" id="organization_name" value="<?php if(isset($services[0])){echo $services[0]->organization_name;} ?>" ></div>
	                                </div>
	                                
	                                <div class="form-group organization_image_div" <?php if(isset($services[0]) && $services[0]->type == "image"){echo "style=display:block";}else{echo "style=display:none";}?>>
	                                	<label class="col-sm-2 control-label">Organization Image</label>
	                                    <div class="col-sm-10"><input type="file" accept="image/*" class="form-control"  name="userfile" id="userfile">
	                                    <?php if(isset($services[0]) && $services[0]->image){?>
                                    		<img width="100" height="100" src="<?php echo $this->config->base_url().'uploads/logo/'.$services[0]->image; ?>"/>
                                    	<?php } ?>	
	                                    </div>
	                                </div>
									<div class="form-group">
	                                	<label class="col-sm-2 control-label">Auto Cancel Meeting Time in Minutes*</label>
	                                    <div class="col-sm-10"><input type="number" placeholder="Enter Auto Cancel Meeting Time in Minutes" class="form-control"  name="meeting_cancel_time" id="meeting_cancel_time" value="<?php if(isset($services[0])){echo $services[0]->meeting_cancel_time;} ?>" ></div>
	                              </div>
                                	<div class="form-group">
	                                	<label class="col-sm-2 control-label">Service Account*</label>
	                                    <div class="col-sm-10"><input type="text" placeholder="Enter Service Account Email" class="form-control"  name="email" id="email" value="<?php if(isset($services[0])){echo $services[0]->email;} ?>" ></div>
	                              </div>
	                                <div class="form-group">
	                                	<label class="col-sm-2 control-label">Service Account Password*</label>
	                                    <div class="col-sm-10"><input autocomplete="new-password" type="password" placeholder="Enter Service Account Password" class="form-control"  name="password" id="password" value="<?php if(isset($services[0])){echo base64_decode($services[0]->password);} ?>" >
										<input style="margin-right: 5px;" type="checkbox" id="show_password"/>Show Password</div></label>
									</div>
                                	<div class="form-group">
	                                	<label class="col-sm-2 control-label">Exchange Server's EWS address*</label>
	                                    <div class="col-sm-10"><input type="text" placeholder="Enter Exchange Server's EWS address" class="form-control"  name="service_url" id="service_url" value="<?php if(isset($services[0])){echo $services[0]->service_url;} ?>" ></div>
	                                </div>
	                                <div class="hr-line-dashed"></div>
	                             	<div class="form-group">
	                                    <div class="col-sm-7 col-sm-offset-2 pull-right">
	                                        <a href="<?php echo $this->config->base_url(); ?>rooms/view" class="btn btn-white" >Cancel</a>
	                                        <button class="btn btn-primary" type="submit">Update</button>
	                                    </div>
	                                </div>
                                	
                                	</div>
                                </form>
                        </div>
                    </div>
                </div>
            </div>
   
         </div> 
        
 <script type="text/javascript">

	  // $.validator.addMethod("Email", function(value, element) {
	            // return this.optional(element) |/^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/.test(value);
	        // }, "Invalid Email Address.");
	        
	    $("#create_admin_form").validate({
	        rules: {
		      	email:{ required:true},
              	password: { required:true},
		      	service_url: { required:true},
		      	organization_name: { required:true},
		      	meeting_cancel_time: {required:true}
		  },
		  messages: {
		                service_url:{required: "URL Required"},
		                email:{required:"Email Required"},
                        password:{required:"Password Required"},
                        organization_name:{required:"Organization Name Required"},
                        meeting_cancel_time: {required:"Cancel Meeting Required"}
		             },
		            tooltip_options: {
		            }
		});
		
		$("#show_password").change(function() {
	        if($(this).prop('checked') == true) {
	    		$("#password").prop('type', 'text');
	        } else {
        		$("#password").prop('type', 'password');
        }
    });
    
    $('#display_option').change(function(){
    	var display_option = $('#display_option').val();
    	if(display_option == "name"){
    		$(".organization_name_div").show();
    		$(".organization_image_div").hide();
    		
    	}else{
    		$(".organization_image_div").show();
    		$(".organization_name_div").hide();
    		
    	}
    });
   
</script> 

