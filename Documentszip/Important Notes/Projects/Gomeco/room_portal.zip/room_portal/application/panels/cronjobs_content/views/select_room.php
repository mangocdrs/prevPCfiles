<div class="content-container">
				<div class="container-fluid">
					<div class="row">
						<div class="col-sm-6"><div class="logo"><h1>City of Abbotsford</h1></h1></div></div>
					</div>	<!-- /end row -->
					<div class="row">
						<div class="col-sm-12">
							<div class="login-container">
								<div class="panel panel-default">
								  	<div class="panel-heading">
								    	<h3 class="panel-title">Please Select Room</h3>
								 	</div>
								  	<div class="panel-body">
								  		<form method="post"  action="<?php echo $this->config->base_url(); ?>rooms_content/submit_selected_room">
								    	
								    	 <div class="form-group">
               								<select id="select_room" name="select_room" class="form-control" >
									    		<?php foreach ($rooms as $key => $value) {?>
													<option value="<?php echo $value->unique_name ?>"><?php echo $value->name; ?></option>
											<?php	} ?>
								    		</select>
								    	</div>
								    	 <div class="form-group">
               						    	<button  class="form-control btn btn-success" type="submit">Submit</button>
										</div>
								    	</form>
								    </div>
								</div>
							</div>	<!-- /end login-container -->
						</div>
					</div>
				</div>
				</div>	<!-- /end container-fluid -->
			</div>	<!-- /end content-container -->