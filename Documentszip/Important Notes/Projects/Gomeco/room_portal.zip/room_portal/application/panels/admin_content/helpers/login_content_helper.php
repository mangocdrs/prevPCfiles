<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

if ( ! function_exists('login_validation'))
{
    function login_validation()
    {
    	
    	$CI =& get_instance();
    	////////////////form validation ///////////////////////

    	$CI->load->helper(array('form', 'url','file'));
    	$CI->load->library('form_validation');
    	$CI->form_validation->set_rules('username', 'username', 'required');
     	$CI->form_validation->set_rules('password', 'password', 'required');
			 if ($CI->form_validation->run() == FALSE){
                 
                 $data = array(	
                 	'username' => set_value('username'),
	                'password' => set_value('password'),
	                'error_message' => validation_errors(),
    	        );
             
            	$CI->session->set_flashdata('error_message', "Field insertion error");
		    }
            else
            {
                $data = array(
                'username' => set_value('username'),
                'valid' => 1,
                'error_message' => "no validation error"
            );
			
			}
      		$CI->session->set_flashdata('user_add_data', $data);
			return $data['valid'];
			
			
    }
        
}


if ( ! function_exists('set_remember_cookie'))
{
    function set_remember_cookie($remember_me = '')
    {
    	
        $CI =& get_instance();
        if ($remember_me == "on"){
            $CI->load->helper('cookie');
           $cookie = array(
                'name'   => 'remember',
                'value'  => $CI->input->post('username'),
                'expire' => 86500,
                'secure' => FALSE
            );
            $CI->input->set_cookie($cookie);
        }
        else{
            $cookie = array(
                'name'   => 'remember',
                'value'  => $CI->input->post('username'),
                'secure' => FALSE
            );
            $CI->input->set_cookie($cookie);
        }
    }   
}



if ( ! function_exists('save_user_session'))
{
    function save_user_session($username,$userdata)
    {
    
        $CI =& get_instance();
		$key="RneMXqHt1h8dvPz4Ey53FOxyz";
		$guid="248b46ea-d297d5e66b6a-f046c0de5bd0";
		$pass=$CI->input->post("password");
		$password = hash("sha1",$pass,False);
		
		$bstr = $username . ":" . $password;
		$auth = "Basic " . base64_encode($bstr);
        $data = array(
        		'username'=>$username,
                'email' => $userdata->email,
                'is_logged_in' => 1,
                'user_type' => $userdata->system_name,
                'user_id' => $userdata->user_id,
                'first_name' => $userdata->first_name,
                'last_name' => $userdata->last_name,
                'user_type_front_name'=>$userdata->front_name,
            );
         
        $CI->session->set_userdata($data);
    }
}
 if ( ! function_exists('save_promotion_info'))
 {
     function save_promotion_info()
     {
     	$CI =& get_instance();
		
    	 $data = array(
                 'is_promotion' => 1
             );
          
		$CI->session->set_userdata($data);
     }
}

if ( ! function_exists('emailvalidation'))
 {
 	function emailvalidation(){
		$CI =& get_instance();
    	////////////////form validation ///////////////////////

    	$CI->load->helper(array('form', 'url','file'));
    	$CI->load->library('form_validation');
    	$CI->form_validation->set_rules('useremail', 'email', 'required|valid_email');
			 if ($CI->form_validation->run() == FALSE){
                 
                 $data = array(	
	                'useremail' => set_value('useremail'),
	                'valid'=>0,
	                'error_message' => validation_errors(),
    	        );
             
            	$CI->session->set_flashdata('error_message', "Field insertion error");
		    }
            else
            {
                $data = array(
                'useremail' => set_value('useremail'),
                'valid' => 1,
                'error_message' => "no validation error"
            );
			
			}
			$CI->session->set_flashdata('user_add_data', $data);
			return $data['valid'];
		 
	 }
 }
 
 if ( ! function_exists('passwordvalidation'))
 {
 	function passwordvalidation(){
		$CI =& get_instance();
    	////////////////form validation ///////////////////////

    	$CI->load->helper(array('form', 'url','file'));
    	$CI->load->library('form_validation');
    	$CI->form_validation->set_rules('pass1', 'Password', 'required|min_length[8]|max_length[15]');
		$CI->form_validation->set_rules('confirmPassword', 'Confirm Password', 'required|min_length[8]|max_length[15]|matches[pass1]');
			 if ($CI->form_validation->run() == FALSE){
                 
                 $data = array(	
	                'email' => set_value('useremail'),
	                'valid'=>0,
	                'error_message' => validation_errors(),
    	        );
             
            	$CI->session->set_flashdata('error_message', "Password Validation Failed");
		    }
            else
            {
                $data = array(
                'valid' => 1,
                'error_message' => "no validation error"
            );
			
			}
			return $data['valid'];
		 
	 }
 }
 
  if ( ! function_exists('signupvalidation'))
 {
 	function signupvalidation(){
 		$CI =& get_instance();
    	$CI->load->helper(array('form', 'url','file'));
    	$CI->load->library('form_validation');
    	$CI->form_validation->set_rules('username', 'User Name', 'required');
		$CI->form_validation->set_rules('firstname', 'First Name', 'required');
		$CI->form_validation->set_rules('lastname', 'Last Name', 'required');
		$CI->form_validation->set_rules('signup_email', 'Email', 'required|valid_email|check_unique_email_in_system');
		$CI->form_validation->set_rules('signup_password', 'Password', 'required|min_length[8]|max_length[15]');
		$CI->form_validation->set_rules('signup_confirm_password', 'Confirm Password', 'required|min_length[8]|max_length[15]|matches[signup_password]');
		$CI->form_validation->set_rules('city', 'City', 'required');
		$CI->form_validation->set_rules('state', 'State', 'required');
		$CI->form_validation->set_rules('zipcode', 'ZipCode', 'required');
		$CI->form_validation->set_rules('country', 'Country', 'required');
		if ($CI->form_validation->run() == FALSE){
             $data = array(	
                'signup_email' => set_value('signup_email'),
                //'signup_password' => set_value('signup_password'),
                'username' => set_value('username'),
                'firstname' => set_value('firstname'),
                'lastname' => set_value('lastname'),
                'city' => set_value('city'),
                'state' => set_value('state'),
                'zipcode' => set_value('zipcode'),
                'country' => set_value('country'),
                'valid'=>0,
                'error_message' => validation_errors(),
	       	 );

             
            	$CI->session->set_flashdata('error_message', "Password Validation Failed");
		    }
            else
            {
                $data = array(
                'valid' => 1,
                'error_message' => "no validation error"
            );
			
			}

			$CI->session->set_flashdata('user_add_data', $data);
			return $data['valid'];
 	}
 }

