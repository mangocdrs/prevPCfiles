<?php if (isset($success_message) && $success_message!=""){ ?>
<script>
	setTimeout(function() {
	     $.bootstrapGrowl('<?php echo $success_message;?>', {
	         type: 'success',
	         align: 'center',
	         width: 'auto',
	         allow_dismiss: false
	     });
	 }, 1);
</script>
<?php } ?>
<?php
	if (isset($error_message) && $error_message!="" ){ 
		if(!isset($user_add_data['error_message'])){
		?>
	
	<script>
	       setTimeout(function() {
	            $.bootstrapGrowl('<?php echo $error_message;?>', {
	                type: 'danger',
	                align: 'center',
	                width: 'auto',
	                allow_dismiss: false
	            });
	        }, 1);
	    </script>
	   <?php
		
		}
		$error_message =  strip_tags($user_add_data['error_message']);
	    $error_message = str_replace(array("\r", "\n"), '', $error_message);
		$error_message= explode('.',$error_message);
	 	for($i=0; $i<count($error_message)-1; $i++){
  			$error = $error_message[$i];
        	if (isset($error)){ ?>
	        	
        		<script>
	       setTimeout(function() {
	            $.bootstrapGrowl("<?php echo $error;?>", {
	                type: 'danger',
	                align: 'center',
	                width: 'auto',
	                allow_dismiss: false
	            });
	        }, 1);
	    </script>
        		
        		
        	<?php }	}
		 } ?>


<div class="content-container">
				<div class="container-fluid">
					<div class="row">
						<div class="col-sm-6">
								<div class="logo">
									<?php if($this->session->userdata('organization_type') == "image"){
									?>
										<img src="<?php echo $this->session->userdata('organization_image');?>" class="organization_name_set"/>
									<?php }else{ ?>
									<h1><?php echo $this->session->userdata('organization_name');?>
									</h1>
									<?php } ?>
								</div>
							</div>
						</div>	<!-- /end row -->
					<div class="row">
						<div class="col-sm-12">
							<div class="login-container">
								<div class="panel panel-default">
								  	<div class="panel-heading">
								    	<h3 class="panel-title">Please Select Room</h3>
								 	</div>
								  	<div class="panel-body">
								  		<form method="post"  action="<?php echo $this->config->base_url(); ?>rooms_content/submit_selected_room">
								    	
								    	 <div class="form-group">
               								<select id="select_room" name="select_room" class="form-control" >
									    		<?php foreach ($rooms as $key => $value) {?>
													<option value="<?php echo $value->unique_name ?>"><?php echo $value->name; ?></option>
											<?php	} ?>
								    		</select>
								    	</div>
								    	 <div class="form-group">
               						    	<button  class="form-control btn btn-success" type="submit">Submit</button>
										</div>
								    	</form>
								    </div>
								</div>
							</div>	<!-- /end login-container -->
						</div>
					</div>
				</div>
				</div>	<!-- /end container-fluid -->
			</div>	<!-- /end content-container -->