<?php
if (!defined('BASEPATH')) exit('No direct script access allowed');

class Cronjobs_content extends MY_Controller {
	
	
	public function import_today_schedule(){
		
		$this -> load -> model('cronjobs_content/cronjobs_content_model');
		$this -> load -> model('rooms_content/rooms_content_model');
		$rooms = $this ->cronjobs_content_model-> get_all_rooms();
		$this->load->library("EwsCustom");
		$service_account = $this->rooms_content_model->get_service_account_detail();
		if(!isset($service_account[0])){
			echo "Not Service Account exists";	
			exit;
		}
		
		
	
		
		foreach ($rooms as $room_key => $room_value) {
		
			$username_room = $room_value->email;
			$password = base64_decode($service_account[0]->password);
			$username = $service_account[0]->email;
			
			$resp = $this->ewscustom->get_event($username_room,$username,$password,date("Y-m-d")."T00:00:00Z",date("Y-m-d", strtotime(' +1 day'))."T23:59:60Z");
			if($resp){
					
				foreach ($resp as $key => $value) {
					$meeting_id=$value->id;
					$changekey=$value->changekey;
					$room_id= $room_value->Id;
					$start = date('Y-m-d H:i:s', $value->start);
					$start = date('Y-m-d H:i:s', strtotime($start." ".UTC_TIME_DIFF_add));
					
					$end = date('Y-m-d H:i:s', $value->end);
					$end = date('Y-m-d H:i:s', strtotime($end." ".UTC_TIME_DIFF_add));
				
					$subject = 	$value->subject;
					$attendees = count($value->people);
					$is_cancelled = "0";
					if(trim($subject) == "Not Checked In"){
						$is_cancelled = "1";
					}
					$params = array();
					
					
					$count = $this ->cronjobs_content_model-> check_meeting_exist($meeting_id,$changekey);
					
					if($count == 0){
						$params['meeting_id'] = $meeting_id;
						$params['change_key'] = $changekey;
						$params['room_id'] = $room_id;
						$params['start_date'] = $start;
						$params['end_date'] = $end;
						$params['subject'] = $subject;
						$params['attendees'] = $attendees;
						$params['is_cancelled'] = $is_cancelled;
						$params['date_created'] = date('Y-m-d H:i:s');
						
						$this ->cronjobs_content_model-> add_meeting($params);
					}
					
				}	
	    	}
			
			
						
			
		}
		
	echo "done";
	exit;
	}
	
	
	
}