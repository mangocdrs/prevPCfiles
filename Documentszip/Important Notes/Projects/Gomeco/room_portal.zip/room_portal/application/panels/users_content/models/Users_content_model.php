<?php
error_reporting(E_ERROR);
class Users_content_model extends MY_Model {
	public function __construct() {
		parent::__construct("app_user");
	}

	public function get_users_by_id($user_id){
		$result = $this->findOneBy(array(
			"id" => $user_id
		),'users');
		return $result;
	}

	public function insert_user() {

		
		$password=$this->input->post('password');
		$hased_pass=hash("sha256",$password,False);

		$insert=array(
	   			'first_name'=>$this->input->post('first_name'),
	   			'last_name'=>$this->input->post('last_name'),
				'email'=>$this->input->post('email'),
				'password'=>$hased_pass,
				'user_type'=>$this->input->post('user_type'),
				'date_created'=>date('Y-m-d H:i:s')
			);
	
			$result_inserted=$this->insert($insert,'users');
			return $result_inserted;
 }
	
	public function main_admin_insert_user() {

		
		$password=$this->input->post('password');
		$hased_pass=hash("sha256",$password,False);

		$insert=array(
	   			'first_name'=>$this->input->post('first_name'),
	   			'last_name'=>$this->input->post('last_name'),
				'email'=>$this->input->post('email'),
				'password'=>$hased_pass,
				'user_type'=>$this->input->post('user_type'),
				'user_category'=>$this->input->post('user_category'),
				'status'=>'active',
				'date_created'=>date('Y-m-d H:i:s')
			);
	
			$result_inserted=$this->insert($insert,'users');
			return $result_inserted;
 }

 	public function update_user() {


 		$user_id=$this->input->post('user_id');
		
		$params = $this->get_users_by_id($user_id);

		$password=$this->input->post('password');
	 	
		$update=array(
	   			'first_name'=>$this->input->post('first_name'),
				'last_name'=>$this->input->post('last_name'),
				'email'=>$this->input->post('email'),
				'user_category'=>$this->input->post('user_category'),
				'date_updated'=>date('Y-m-d H:i:s')
			);
			
			if($password!='') {
	 			$update['password'] =hash("sha256",$password,False);
	 		}
			
			
			
			$result_updated=$this->update($update,"id=$user_id","users");
			return $result_updated;
  }

 	public function get_all_users_count() {
 		$params = array(
 			"select"=>"*",
 			"from"=>"users"
 			);
			
		 $where = ""	;
		if($this->uri->slash_segment(2)=="search/")
		{
			if(!$_POST)
			{
				$search_user_name=$this->session->userdata("search_user_name");
				$search_email= $this->session->userdata("search_email");
				$per_page= $this->session->userdata("per_page");
				$search_status= $this->session->userdata("search_status");

			}
			else{

				$search_user_name=$this->input->post("search_user_name");
				$search_email=$this->input->post("search_email");
			 	$per_page=$this->input->post("per_page");
			 	$search_status=$this->input->post("search_status");
				$newdata = array(
						'search_user_name'  => $search_user_name,
						'search_email'  => $search_email,
						'per_page'  => $per_page,
						'search_status'  => $search_status,
						);
				$this->session->set_userdata($newdata);
			}	
			$where_search = array();
			
			if(isset($search_email) && $search_email!=""){
				$where_search[] = "email like '%".$search_email."%'";
			}

			
			if(isset($search_status) && $search_status!=""){
				$where_search[] = "user_type = '".$search_status."'";
			}
			
			$where_search = implode(" and ", $where_search);
			if(strlen($where_search)){
			  	$where = $where_search;
			}	
		}	
			
		if(strlen($where)){
			$params['where']=$where;
		}	
			
 		$result = $this->find($params);

 		if($result) {
 			return count($result);
 		}else{
 			return False;
 		}

 	}

 	public function get_all_users($offset,$limit){
	
         $where = ""	;
		if($this->uri->slash_segment(2)=="search/")
		{
			if(!$_POST)
			{
				$search_user_name=$this->session->userdata("search_user_name");
				$search_email= $this->session->userdata("search_email");
				$per_page= $this->session->userdata("per_page");
				$search_status= $this->session->userdata("search_status");

			}
			else{

				$search_user_name=$this->input->post("search_user_name");
				$search_email=$this->input->post("search_email");
			 	$per_page=$this->input->post("per_page");
			 	$search_status=$this->input->post("search_status");
				$newdata = array(
						'search_user_name'  => $search_user_name,
						'search_email'  => $search_email,
						'per_page'  => $per_page,
						'search_status'  => $search_status,
						);
				$this->session->set_userdata($newdata);
			}	
			$where_search = array();
			
			if(isset($search_email) && $search_email!=""){
				$where_search[] = "email like '%".$search_email."%'";
			}

			

			if(isset($search_status) && $search_status!=""){
				$where_search[] = "user_type = '".$search_status."'";
			}
			
			$where_search = implode(" and ", $where_search);
			if(strlen($where_search)){
			  	$where = $where_search;
			}	
		}

		else{
			$this->session->unset_userdata("search_user_name");
			$this->session->unset_userdata("search_email");
			$this->session->unset_userdata("per_page");
			$this->session->unset_userdata("search_status");
			}

		$params=array(
			'select'=>"*",
			'from'=> "users",
			"page" => $offset,
        	"limit" => $limit,
			);
		
		if(strlen($where)){
			$params['where']=$where;
		}
		$result=$this->find($params);

        return $result;

	}
		








	public function checkuniqueemailinsystem($email,$user_id = NULL){
		$where = "email = '$email'";
		if($user_id){
			$where .= " and id != '$user_id'";
		}
		$result = $this->count($where,'users');
		return $result;
	}


public function delete_user() {
 		$user_id = $this->input->get('id');
		
		$this->delete("id = '$user_id'","users");
	}











}
