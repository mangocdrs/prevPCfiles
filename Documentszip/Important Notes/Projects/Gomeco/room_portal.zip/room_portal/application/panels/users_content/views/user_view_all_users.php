<?php
	if (isset($success_message) && $success_message!=""){ ?>
	<script>
	       setTimeout(function() {
	            $.bootstrapGrowl('<?php echo $success_message;?>', {
	                type: 'success',
	                align: 'center',
	                width: 'auto',
	                allow_dismiss: false
	            });
	        }, 1);
	    </script>
<?php } ?>

<?php
	if (isset($error_message) && $error_message!="" ){ 
		if(!isset($user_add_data['error_message'])){
		?>
	
	<script>
	       setTimeout(function() {
	            $.bootstrapGrowl('<?php echo $error_message;?>', {
	                type: 'danger',
	                align: 'center',
	                width: 'auto',
	                allow_dismiss: false
	            });
	        }, 1);
	    </script>
	   <?php
		
		}
		if(isset($user_add_data['error_message'])){
		$error_message =  strip_tags($user_add_data['error_message']);
	    $error_message = str_replace(array("\r", "\n"), '', $error_message);
		$error_message= explode('.',$error_message);
	 	for($i=0; $i<count($error_message)-1; $i++){
  			$error = $error_message[$i];
        	if (isset($error)){ ?>
	        	
        		<script>
	       setTimeout(function() {
	            $.bootstrapGrowl("<?php echo $error;?>", {
	                type: 'danger',
	                align: 'center',
	                width: 'auto',
	                allow_dismiss: false
	            });
	        }, 1);
	    </script>
        		
        	<?php }	}
		 }} ?>

<div class="row">
                <div class="col-lg-12">
                    <div class="ibox float-e-margins">
                        <div class="ibox-title">
				<h5>All Users</h5>
			<!-- <div class="pull-right"><a href="<?php echo $this->config->base_url()?>users/add"><button class="btn btn-primary btn-xs">Add User</button> </a> </div> -->
</div>
                        <div class="ibox-content">
					   
					   <form method="post" action="<?php echo $this->config->base_url()?>users/search">
						
						
				
						<div class="col-sm-4">
							<div class="form-group">
								<input type="text" id="search_admin_email" value="<?php echo $this->session->userdata('search_email');?>" name="search_email" placeholder="Search Username" class="form-control" >
						
							</div>
						</div>
						
						<!-- <div class="col-sm-4">
							<div class="form-group">
								<select name="search_status" class="form-control">
									<option  selected value="">Select Type</option>
									<option value="client" <?php if($this->session->userdata('search_status')=="client"){echo "SELECTED";}?>>Client</option>
									<option value="super_admin" <?php if($this->session->userdata('search_status')=="super_admin"){echo "SELECTED";}?>>Super Admin</option>
								</select>
							</div>
						</div> -->
						
						<div class="col-sm-4">
							<div class="form-group pull-left">
								<input type="submit" class="btn btn-primary"  value="Search"/>
							</div>
						</div>
						</form>
                        <div class="ibox-content">
                        <div class="table-responsive">
                            <table class="footable table table-stripped toggle-arrow-tiny" data-page-size="8">
                                <thead>
                                
                                <tr>
                                    <th data-hide="all">Name</th>
                                    <th data-hide="all">Username</th>
                                    <!-- <th data-hide="all">User Type</th> -->
                                    <th data-hide="all">Status</th>
                                </tr>
                                </thead>
                                <tbody>
                                    <?php if(!empty($all_users)){
                                    foreach ($all_users as $key) { ?>
                                <tr>
                                    <td><?php echo $key->first_name." ".$key->last_name; ?></td>
                                    <td><?php echo $key->email ; ?></td>
                                     <!-- <td>
                                    	<?php if($key->user_type=="super_admin")
										{
											echo "Super Admin";
										} else{
											echo "Client";
										} ?>
                                    </td>   -->
                                   
                                    <td>
                                        <a href="<?php echo $this->config->base_url();?>users/edit?id=<?php echo $key->id; ?> " class="btn btn-primary btn-xs" data-toggle="tooltip" title="Edit">
                                        <span class="glyphicon glyphicon-pencil"></span>
                                        </a>
                                    </td>
                                </tr>
                                
                                <?php   }
                                    }?>
                                </tbody>
                                 <tr>
                                	<td colspan="7">Total Records<b> <?php echo $total; ?></b></td>
                                </tr>
                                <tfoot>
                                	<?php if(!empty($paginglinks)){ ?>
		                                <tr>
		                                    <td colspan="7">
		                                        <div class="pagination_ci" style="float:right;"> <?php echo $paginglinks; ?></div>
												<div class="pagination_ci" style="float:left;"> <?php echo (!empty($pagermessage) ? $pagermessage : ''); ?></div>
		                                    </td>
		                                </tr>
		                            <?php } ?>
                                </tfoot>
                            </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>