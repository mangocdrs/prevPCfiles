		<div class="footer">
            
            <div>
               <strong>Gomeco</strong>  &copy; 2018
            </div>
        </div>
        
 <script>
	  $('a.lic').click(function(e) {
	     if ( $('body' ).hasClass( "mini-navbar" ) )
		 { 		
			e.PreventDefault();
	     }
	    });
    
  $('a').click(function(e) {
    	//$(this).addClass("active");	
    });

</script>