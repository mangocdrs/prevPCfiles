<?php

class Left_content_model extends MY_Model {
	
	function get_user_detail(){
		$user_id = $this->session->userdata('user_id');
		$result = $this->findOneBy(array(
			"userid" => $user_id
		),'users');
		return $result;
	}

}
?>
