<?php if (isset($success_message) && $success_message!=""){ ?>
<script>
	setTimeout(function() {
	     $.bootstrapGrowl('<?php echo $success_message;?>', {
	         type: 'success',
	         align: 'center',
	         width: 'auto',
	         allow_dismiss: false
	     });
	 }, 1);
</script>
<?php } ?>
<?php
	if (isset($error_message) && $error_message!="" ){ 
		if(!isset($user_add_data['error_message'])){
		?>
	
	<script>
	       setTimeout(function() {
	            $.bootstrapGrowl('<?php echo $error_message;?>', {
	                type: 'danger',
	                align: 'center',
	                width: 'auto',
	                allow_dismiss: false
	            });
	        }, 1);
	    </script>
	   <?php
		
		}
		$error_message =  strip_tags($user_add_data['error_message']);
	    $error_message = str_replace(array("\r", "\n"), '', $error_message);
		$error_message= explode('.',$error_message);
	 	for($i=0; $i<count($error_message)-1; $i++){
  			$error = $error_message[$i];
        	if (isset($error)){ ?>
	        	
        		<script>
	       setTimeout(function() {
	            $.bootstrapGrowl("<?php echo $error;?>", {
	                type: 'danger',
	                align: 'center',
	                width: 'auto',
	                allow_dismiss: false
	            });
	        }, 1);
	    </script>
        		
        		
        	<?php }	}
		 } ?>


<div class="content-container">
				<div class="container-fluid">
					<div class="row">
						<div class="col-sm-6">
							<div class="logo">
								<?php if($this->session->userdata('organization_type') == "image"){
								?>
									<img src="<?php echo $this->session->userdata('organization_image');?>" class="organization_name_set"/>
								<?php }else{ ?>
								<h1><?php echo $this->session->userdata('organization_name');?>
								</h1>
								<?php } ?>
							</div>
						</div>
					</div>	<!-- /end row -->
					<div class="row">
						<div class="col-sm-12">
							<div class="login-container">
								<div class="panel panel-default">
								  	<div class="panel-heading">
								    	<h3 class="panel-title">Please sign in</h3>
								 	</div>
								  	<div class="panel-body">
								    	<form accept-charset="UTF-8" role="form" action="<?php $this->config->base_url() ?>login_content/login_validate" method="post">
					                    <fieldset>
								    	  	<div class="form-group">
								    		    <input class="form-control" placeholder="Username" name="username" id="username" type="text">
								    		</div>
								    		<div class="form-group">
								    			<input class="form-control" placeholder="Password" name="password" id="password" type="password" >
								    		</div>
								    		<div class="checkbox">
								    	    	<label>
								    	    		<input name="remember" type="checkbox" value="Remember Me"> Remember Me
								    	    	</label>
								    	    </div>
								    		
								    		<input class="btn btn-success form-control" type="submit" value="Login">
								    		
								    	</fieldset>
								      	</form>
								    </div>
								</div>
							</div>	<!-- /end login-container -->
						</div>
					</div>
				</div>
				</div>	<!-- /end container-fluid -->
			</div>	<!-- /end content-container -->