<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="apple-mobile-web-app-capable" content="yes">
    <title>Gomeco | <?php echo $this->session->userdata('organization_name');?></title>
    <!-- Bootstrap -->
	<link href="<?php echo $this->config->base_url(); ?>r/css/bootstrap.css" rel="stylesheet">
	<link href="<?php echo $this->config->base_url(); ?>r/css/styles.css" rel="stylesheet" type="text/css">

	<script src="<?php echo $this->config->base_url(); ?>r/js/jquery-1.11.3.min.js"></script>
	<!-- <script src="<?php echo $this->config->base_url();?>r/js/bootstrap.min.js"></script> -->

	<script src="<?php echo $this->config->base_url();?>r/js/jquery.blockUI.js"></script>
	<!-- Include all compiled plugins (below), or include individual files as needed --> 
	<script src="<?php echo $this->config->base_url(); ?>r/js/bootstrap.js"></script>
	
	<script src="<?php echo $this->config->base_url();?>r/js/jquery.bootstrap-growl.js" type="text/javascript"></script>

</head>
