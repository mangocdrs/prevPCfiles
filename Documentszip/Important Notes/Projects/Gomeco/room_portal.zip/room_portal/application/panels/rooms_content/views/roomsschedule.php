<?php if (isset($success_message) && $success_message!=""){ ?>
<script>
	setTimeout(function() {
	     $.bootstrapGrowl('<?php echo $success_message;?>', {
	         type: 'success',
	         align: 'center',
	         width: 'auto',
	         allow_dismiss: false
	     });
	 }, 1);
</script>
<?php } ?>
<?php if (isset($error_message) && $error_message!=""){ ?>
<script>
	setTimeout(function() {
	     $.bootstrapGrowl('<?php echo $error_message;?>', {
	         type: 'danger',
	         align: 'center',
	         width: 'auto',
	         allow_dismiss: false
	     });
	 }, 1);
</script>
<?php } ?>
<?php if($room_status=="Available"){?>
<div class="main-content" style="background: rgba(83, 112, 55, 0.97);">
<div class="content-container">
				<div class="container-fluid">
					<div class="row">
					<div class="col-sm-6">
							<div class="logo">
								<?php if($this->session->userdata('organization_type') == "image"){
								?>
									<img src="<?php echo $this->session->userdata('organization_image');?>" class="organization_name_set"/>
								<?php }else{ ?>
								<h1><?php echo $this->session->userdata('organization_name');?>
								</h1>
								<?php } ?>
							</div>
						</div></div>	<!-- /end row -->
					<div class="row">
						<div class="col-sm-12">
							<div class="message">
								<span type="" class="btn-small btn-meeting-status button-available">AVAILABLE</span>
								<h1><?php echo $this->session->userdata('room_display_name'); ?></h1>
								<?php if($available_minutes==0){?>
									
									<p class="big">Available all day</p>
								<?php } else {?>
									<p class="big">Available for next <?php echo $available_minutes; ?>.</p>	
								<?php } ?>
								
								<!-- <button class="btn btn-primary" data-toggle="modal" data-target="#available_form">Start Meeting Now</button> -->
								<div class="meeting-options">
									<ul>
										<li class="start"><span>START</span></li>
										<li><a name="submit1" id="a1" data-value="15" href="#">15 <span>min</span></a></li>
										<li><a name="submit1" data-value="30" href="#">30 <span>min</span></a></li>
										<li><a name="submit1" data-value="45" href="#">45 <span>min</span></a></li>
										<li><button class="btn btn-default meeting-time-more" data-toggle="modal" data-target="#available_form">More</button></li>
									</ul>
								</div>
								<!--<button type="button" class="btn btn-danger btn-large btn-end-meeting">End Meeting</button>-->
							</div> <!-- /end message -->
						</div>
					</div>
				</div>
				</div>	<!-- /end container-fluid -->
			</div>	<!-- /end content-container -->
		</div>	

<?php } else if($room_status=="in_use"){
	?>
	

<div class="main-content">
<div class="content-container">
				<div class="container-fluid">
					<div class="row">
						<div class="col-sm-6">
							<div class="logo">
								<?php if($this->session->userdata('organization_type') == "image"){
								?>
									<img src="<?php echo $this->session->userdata('organization_image');?>" class="organization_name_set"/>
								<?php }else{ ?>
								<h1><?php echo $this->session->userdata('organization_name');?>
								</h1>
								<?php } ?>
							</div>
						</div>	
					</div>	<!-- /end row -->
					<div class="row">
						<div class="col-sm-12">
							<div class="message">
								<span class="btn-small btn-meeting-status btn-meeting-inuse">IN USE</span>
								
								<!--<button type="button" class="btn btn-danger btn-small btn-meeting-status button-inuse">IN USE</button>-->
								<h1><?php echo $this->session->userdata('room_display_name'); ?></h1>
								<p class="meeting_name big"><?php echo $meeting_name; ?></p>
								<p class="meeting_time_interval big" style="text-transform: uppercase;"><?php echo $start_time." - ".$end_time; ?></p>
								
								<div class="meeting-options">
									<ul>
										<li class="extend"><span>EXTEND</span></li>
										<li><a name="submit2" id="a2" data-value="15" href="#">15 <span>min</span></a></li>
										<li><a name="submit2" data-value="30" href="#">30 <span>min</span></a></li>
										<li><a name="submit2" data-value="45" href="#">45 <span>min</span></a></li>
										<li><button class="btn btn-default meeting-time-more" data-toggle="modal" data-target="#extend_form">More</button></li>
									</ul>
								</div>
								
							</div> <!-- /end message -->
							<!-- <button type="button"  class="btn btn-primary btn-large btn-end-meeting">Extend Meeting</button> -->
							<form role="form" name="submit_cancel_schedule" method="post" action="<?php echo $this->config->base_url().'rooms_content/submit_cancel_schedule'; ?>">
							<input type="hidden" name="meeting_id" id="meeting_id" value="<?php echo $meeting_id; ?>" />
							<input type="hidden" name="changekey" id="changekey" value="<?php echo $changekey; ?>" />
							<input type="hidden" name="end_date_ews" id="end_date_ews" value="<?php echo $end_date_ews; ?>" />
							<input type="hidden" name="start_date_ews" id="start_date_ews" value="<?php echo $start_date_ews; ?>" />
							<button type="submit" class="btn btn-danger btn-large button-end-meeting">End meeting</button>
							</form>
						</div>
					</div>
				</div>
				</div>	<!-- /end container-fluid -->
			</div>	<!-- /end content-container -->
		</div>	

	<script>
	
	
	
	 $('a[name="submit2"]').click(function(event){
 		$('.submit2_click').show();
 		var selected_value = $(this).data("value");
   	  	setTimeout(function(){ submit2_click(selected_value); }, 300);
	 });
	 
	 
	 
	function submit2_click(selected_value){
			i=selected_value;
			$.ajax({
            url: "<?php echo site_url('/rooms_content/submit_ajax_extend_schedule'); ?>",
            data: { 
      				schedule_time: i,
      				meeting_id: "<?php echo $meeting_id; ?>",
      				changekey:"<?php echo $changekey; ?>", 
					start_date_ews:"<?php echo $start_date_ews; ?>", 
					end_date_ews:"<?php echo $end_date_ews; ?>" 
					},
            	method: 'POST',
            	dataType: "json",

		      success: function(response) {
		      	console.log(response);
		      	location.reload();
		      	
		        },
		        error: function(response) {
		        	
		            console.log(response);
		        }
      });
	}
</script>
	
	
	
<?php } else{?>

<div class="main-content" style="background: rgba(221, 174, 34, 0.97)">
<div class="content-container">
				<div class="container-fluid">
					<div class="row">
					<div class="col-sm-6">
							<div class="logo">
								<?php if($this->session->userdata('organization_type') == "image"){
								?>
									<img src="<?php echo $this->session->userdata('organization_image');?>" class="organization_name_set"/>
								<?php }else{ ?>
								<h1><?php echo $this->session->userdata('organization_name');?>
								</h1>
								<?php } ?>
							</div>
						</div>
					</div>	<!-- /end row -->
					<div class="row">
						<div class="col-sm-12">
							<div class="message">
								<span class="btn-small btn-meeting-status btn-meeting-book">BOOKED</span>
								<!--<button type="button" class="btn btn-danger btn-small btn-meeting-status button-inuse">IN USE</button>-->
								<h1><?php echo $this->session->userdata('room_display_name'); ?></h1>
								<p class="big meeting_name"><?php echo $meeting_name; ?></p>
								<p class="meeting_time_interval big" style="text-transform: uppercase;"><?php echo $start_time." - ".$end_time; ?></p>
								
								</div> <!-- /end message -->
							<!-- <button type="button"  class="btn btn-primary btn-large btn-end-meeting">Extend Meeting</button> -->
							<form role="form" name="submit_cancel_schedule" method="post" action="<?php echo $this->config->base_url().'rooms_content/start_booked_meeting'; ?>">
							<input type="hidden" name="meeting_id" id="meeting_id" value="<?php echo $meeting_id; ?>" />
							<input type="hidden" name="changekey" id="changekey" value="<?php echo $changekey; ?>" />
                 			<button type="submit" class="btn btn-warning btn-large button-start-meeting">Start meeting now</button>
							</form>
						</div>
					</div>
				</div>
				</div>	<!-- /end container-fluid -->
			</div>	<!-- /end content-container -->
		</div>




<?php } ?>
<div class="modal fade" id="available_form" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
		<div class="modal-dialog" role="document">
			<div class="modal-content schedule_meeting_more">
				<div class="modal-header">
					<h2>Start a meeting now</h2>
				</div>
				<!-- Modal Body -->
            <div class="modal-body">
                
                <form role="form" name="submit_current_schedule" method="POSt" action="<?php echo $this->config->base_url().'rooms_content/submit_current_schedule'; ?>">
                  <div class="form-group">
                  <!-- <label for="exampleInputEmail1">Subject</label>
                  <input class="form-control" type="text" name="subject" value="Schedule" readonly /> -->
                  </div>
                  <div class="form-group">
                    <label for="exampleInputEmail1">Select Time</label>
                      <select class="form-control" name="schedule_time">
                      	<option value="15">15 Minutes</option>
                      	<option value="30">30 Minutes</option>
                      	<option value="45">45 Minutes</option>
                      	<option value="60">60 Minutes</option>
                      	<option value="75">75 Minutes</option>
                      	<option value="90">90 Minutes</option>
                      	<option value="105">105 Minutes</option>
                      	<option value="120">120 Minutes</option>
                      	<option value="135">135 Minutes</option>
                      	<option value="150">150 Minutes</option>
                      </select>
                  </div>
                  
                  
                
                
                
            </div>
            <div class="modal-footer">
            	<button type="button" class="btn btn-default button-popup-close" data-dismiss="modal" aria-hidden="true">Close</button>
            	<button type="submit" class="btn btn-success button-popup-close create_meeting" aria-hidden="true">Submit</button>
            	
            	
            </div>
			</div>
			</form>
		</div>
		
	</div>


<div class="modal fade" id="extend_form" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
		<div class="modal-dialog" role="document">
			<div class="modal-content schedule_meeting_more">
				<div class="modal-header">
					<h2>Extend Meeting</h2>
				</div>
				<!-- Modal Body -->
            <div class="modal-body">
                
                <form role="form" name="submit_current_schedule" method="POSt" action="<?php echo $this->config->base_url().'rooms_content/extend_current_schedule'; ?>">
                  <div class="form-group">
                  	<input type="hidden" name="meeting_id" id="meeting_id" value="<?php echo $meeting_id; ?>" />
                  	<input type="hidden" name="changekey" id="changekey" value="<?php echo $changekey; ?>" />
                 	<input type="hidden" name="end_date_ews" id="end_date_ews" value="<?php echo $end_date_ews; ?>" />
					<input type="hidden" name="start_date_ews" id="start_date_ews" value="<?php echo $start_date_ews; ?>" />
									
                  <!-- <label for="exampleInputEmail1">Subject</label>
                  <input class="form-control" type="text" name="subject" value="Schedule" readonly /> -->
                  </div>
                  <div class="form-group">
                    <label for="exampleInputEmail1">Select Time</label>
                      <select class="form-control" name="schedule_time">
                      	<option value="15">15 Minutes</option>
                      	<option value="30">30 Minutes</option>
                      	<option value="45">45 Minutes</option>
                      	<option value="60">60 Minutes</option>
                      	<option value="75">75 Minutes</option>
                      	<option value="90">90 Minutes</option>
                      	<option value="105">105 Minutes</option>
                      	<option value="120">120 Minutes</option>
                      	<option value="135">135 Minutes</option>
                      	<option value="150">150 Minutes</option>
                      </select>
                  </div>          
            </div>
            <div class="modal-footer">
            	<button type="button" class="btn btn-default button-popup-close" data-dismiss="modal" aria-hidden="true">Close</button>
            	<button type="submit" class="btn btn-success button-popup-close extend_meeting"  aria-hidden="true">Submit</button>
            </div>
			</div>
			</form>
		</div>
		
	</div>

<!-- cancel event popup-->


	
<script>
	
	 $('.extend_meeting').click(function(){
	 	$('#extend_form').modal('hide');
 		$('.submit2_click').show();
 	 });
	 $('.create_meeting').click(function(){
	 	$('#available_form').modal('hide');
 		$('.submit1_click').show();
 	 });
	 $('a[name="submit1"]').click(function(event){
 		$('.submit1_click').show();
 		var selected_value = $(this).data("value");
   	  	setTimeout(function(){ submit1_click(selected_value); }, 300);
	 });
	function submit1_click(selected_value){
			i=selected_value;
	
	        $.ajax({
		
            url: "<?php echo site_url('/rooms_content/submit_ajax_current_schedule'); ?>",
            data: { 
      				schedule_time: i,	
					},
            	method: 'POST',
            	dataType: "json",

		      success: function(response) {
		      	console.log(response);
		      	//$("#wait").css("display", "none");
		      	location.reload();
		      	
		        },
		        error: function(response) {
		        	
		            console.log(response);
		        }
      });
	}
var timecheck = 0;
var ajax_call = function() {
   
   if(timecheck == 1){
   	   
   	   var current_room_status="<?php echo $room_status;?>";
	   var url="<?php echo $this->config->base_url(); ?>rooms_content/sync_room_screen";
	   $.ajax({
	   			url: url,
	   			
	   			data: {
	      			format: 'json'
	   			},
			   	error: function() {
			   		// alert("error@@@");
			   	},
			   	dataType: 'json',
			   	success: function(data) {
			   		if(data['booked_cancel']==1){
			   			// alert("ddd");
			   			window.location.href = "<?php echo $this->config->base_url();?>"+'rooms/view';
			   		}
			   		else if(data['room_status']==current_room_status && data['room_status']=="Available"){
			   			if(data['available_minutes']==0)
							$('p.big').html('Available all day');
						else
							$('p.big').html('Available for next '+ data['available_minutes']);
			   		}
			   		else if(data['room_status']==current_room_status && data['room_status']=="in_use"){
			   			$('p.meeting_time_interval').html(data['start_time']+' - '+ data['end_time']);
			   			$('p.meeting_name').html(data['meeting_name']);
			   		}
			   		
			   		else if(data['room_status']==current_room_status && data['room_status']=="booked"){
			   			$('p.meeting_time_interval').html(data['start_time']+' - '+ data['end_time']);
			   			$('p.meeting_name').html(data['meeting_name']);
			   		}
			   		
			   		else{
			   			
			   			window.location.href = "<?php echo $this->config->base_url();?>"+'rooms/view';
			   		}
			    },
			   	type: 'GET',
			   	async:false
			});
	   }
    timecheck  = 1;
    // alert("out");
};

var interval = 1000 * 30; // where X is your every X minutes
// var interval = 3600; // where X is your every X minutes

setInterval(ajax_call, interval);


</script>



