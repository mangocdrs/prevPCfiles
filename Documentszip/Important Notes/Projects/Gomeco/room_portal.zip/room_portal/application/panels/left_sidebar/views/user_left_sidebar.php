<nav class="navbar-default navbar-static-side" role="navigation">
        <div class="sidebar-collapse">
            <ul class="nav metismenu" id="side-menu">
                <li class="nav-header">
                    <div class="dropdown profile-element"> <span>
                            <a href="<?php echo $this->config->base_url(); ?>"><img alt="image" class="img-circle" height="80%" width="50%" src="<?php echo $this->config->base_url(); ?>/r/images/logo.png" /></a>
                             </span>
                            <span class="clear"> <span class="block m-t-xs"> <strong class="font-bold"><?php echo $this->session->userdata("firstName"); ?></strong>
                             </span> 
                        </div>
                    <div class="logo-element">
                        <span><a href="<?php echo $this->config->base_url(); ?>">Gomeco</a></span>
                    </div>
                </li>
                
                <li class="<?php if($page_name=='rooms') {echo "active"; }?>">
            		<a href="<?php echo $this->config->base_url() ?>rooms/view" class="lic"><i class="fa fa-bank"></i> <span class="nav-label">Rooms</span></a>
                </li>  
                 <li class="<?php if($page_name=='reports') {echo "active"; }?>">
            		<a href="<?php echo $this->config->base_url() ?>reports/view" class="lic"><i class="fa fa-bar-chart"></i> <span class="nav-label">Reports</span></a>
                </li>
                <?php if($this->session->category=='ews') { ?>
                <li class="<?php if($page_name=='services') {echo "active"; }?>">
            		<a href="<?php echo $this->config->base_url() ?>services/view" class="lic"><i class="fa fa-file"></i> <span class="nav-label">Settings</span></a>
                </li>  
                <?php } else {?>
                 <li class="<?php if($page_name=='refreshtoken') {echo "active"; }?>">
            		<a href="<?php echo $this->config->base_url() ?>refreshtoken/view" class="lic"><i class="fa fa-file"></i> <span class="nav-label">Refresh Token</span></a>
                </li>
                <?php } ?>  
                 <li class="<?php if($page_name=='users') {echo "active"; }?>">
            		<a href="<?php echo $this->config->base_url() ?>users/edit?id=<?php echo $this->session->user_id ?>" class="lic"><i class="fa fa-users"></i> <span class="nav-label">Profile</span></a>
                </li>        
            </ul>
        </div>
    </nav>