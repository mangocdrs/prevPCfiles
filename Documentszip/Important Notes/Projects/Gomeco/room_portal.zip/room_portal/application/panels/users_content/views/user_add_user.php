<?php if (isset($success_message) && $success_message!=""){ ?>
<script>
	setTimeout(function() {
	     $.bootstrapGrowl('<?php echo $success_message;?>', {
	         type: 'success',
	         align: 'center',
	         width: 'auto',
	         allow_dismiss: false
	     });
	 }, 1);
</script>
<?php } ?>
<?php
	if (isset($error_message) && $error_message!="" ){ 
		if(!isset($user_add_data['error_message'])){
		?>
<script>
	setTimeout(function() {
	     $.bootstrapGrowl('<?php echo $error_message;?>', {
	         type: 'danger',
	         align: 'center',
	         width: 'auto',
	         allow_dismiss: false
	     });
	 }, 1);
</script>
<?php
	}
	$error_message =  strip_tags($user_add_data['error_message']);
	   $error_message = str_replace(array("\r", "\n"), '', $error_message);
	$error_message= explode('.',$error_message);
		for($i=0; $i<count($error_message)-1; $i++){
				$error = $error_message[$i];
	      	if (isset($error)){ ?>
<script>
	setTimeout(function() {
	     $.bootstrapGrowl("<?php echo $error;?>", {
	         type: 'danger',
	         align: 'center',
	         width: 'auto',
	         allow_dismiss: false
	     });
	 }, 1);
</script>
<?php }	}
	} ?>
<div class="wrapper wrapper-content animated fadeInRight">
	<div class="row">
		<div class="col-lg-12">
			<div class="ibox float-e-margins">
				<div class="ibox-title">
					<h5>Add User</h5>
				</div>
				<div class="ibox-content">
					<form  method="post" action="<?php echo $this->config->base_url();?>users_content/user_create_user" class="form-horizontal" id="add_user_form" name="add_user_form" enctype="multipart/form-data">
						<div class="form-group">
							<label class="col-sm-2 control-label">Name*</label>
							<div class="col-sm-4">
								<input type="text" placeholder="First Name" class="form-control"  name="first_name" id="first_name"  value="<?php if(isset($user_add_data['first_name'])){ echo $user_add_data['first_name'];}?>" >
							</div>
							<label class="col-sm-2 control-label">Last Name*</label>
							<div class="col-sm-4">
								<input type="text" placeholder="Last Name" class="form-control"  name="last_name" id="last_name"  value="<?php if(isset($user_add_data['last_name'])){ echo $user_add_data['last_name'];}?>" >
							</div>
						</div>
						<div class="form-group">
							<label class="col-sm-2 control-label">Email*</label>
							<div class="col-sm-4">
									<input class='form-control' name="email" id="email" placeholder="Email" value="<?php if(isset($user_add_data['email'])){ echo $user_add_data['email'];}?>" id="email"/>
							</div>
							<label class="col-sm-2 control-label">Password*</label>
							<div class="col-sm-4">
								<input type="password" placeholder="Password" class="form-control"  name="password" id="password">
							</div>
						</div>
						<div class="form-group">
							
							<label class="col-sm-2 control-label">User Type*</label>
							<div class="col-sm-4">
								<select class="form-control m-b" name="user_type" id="user_type">
									<option value="" <?php if(isset($user_add_data['user_type']) && $user_add_data['user_type']=='') {echo "selected";}?>>Select User Type</option>
									<option value="client" <?php if(isset($user_add_data['user_type']) && $user_add_data['user_type']=='client') {echo "selected";}?>>Client</option>
									<option value="super_admin" <?php if(isset($user_add_data['user_type']) && $user_add_data['user_type']=='super_admin') {echo "selected";}?>>Super Admin</option>
								</select>
							</div>
						</div>
						
						<div class="hr-line-dashed"></div>
						<div class="form-group">
							<div class="col-sm-7 col-sm-offset-2 pull-right">
								<a href="<?php echo $this->config->base_url(); ?>users/view" class="btn btn-white" >Cancel</a>
								<button class="btn btn-primary" type="submit">Create</button>
							</div>
						</div>
					</form>
				</div>
			</div>
		</div>
	</div>
</div>
<script type="text/javascript">
	$.validator.addMethod("alpha", function(value, element) {
	  return this.optional(element) |/^[a-zA-Z]+$/.test(value);
	 }, "Only Alphabets Allowed");
	$.validator.addMethod("Email", function(value, element) {
	  return this.optional(element) |/^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/.test(value+"@sita.aero");
	 }, "Valid email only");
	
	
	   $("#add_user_form").validate({
	       rules: {
	        first_name: {required: true, alpha: true},
	        last_name: {required: true, alpha: true},
	        email: {required: true,Email:true},
	        password: {required: true},
	        status: {required: true},
	        user_type: {required: true},
	        },
	  messages: {
	                firstname:{required: "First Name is Required"},
	                last_name:{required: "Last Name is Required"},
	                email:{required: "Email Field is Required",Email:"Email Not Valid"},
	                password:{required: "Password is Required"},
	                status:{required: "Status is Required"},
	                user_type:{required: "User Type is Required"},
	     }       ,
	            tooltip_options: {
	       
	            }
	});
</script>