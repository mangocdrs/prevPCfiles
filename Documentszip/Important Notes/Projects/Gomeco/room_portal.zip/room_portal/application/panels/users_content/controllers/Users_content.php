<?php
if (!defined('BASEPATH'))
	exit('No direct script access allowed');

class Users_content extends MY_Controller {

	public function __construct() {
		parent::__construct();

	}

	public function index() {
		exit ;
	}
	
	public function user_view_all_user() {
		$access = $this->check_user();
		$this->panels_check_permission($access);
		$this->load->model('users_content_model');
		$success_message=$this->session->flashdata('success_message');
		$error_message=$this->session->flashdata('error_message');
		$user_add_data=$this->session->flashdata('user_add_data');
    	$data['error_message']= $error_message;
		$data['success_message']= $success_message;
		$data['user_add_data']=$user_add_data;

		$this->load->library("pagination");
		$offset = ($this->uri->segment(3) != '' ? $this -> uri -> segment(3): 1);
		$per_page = 10;
		
		$totalUser=$this->users_content_model->get_all_users_count();
		if($this->uri->slash_segment(2)=="search/"){
			$url= $this -> config -> base_url() ."users/search"; 
    	}
    	else{
    		$url= $this -> config -> base_url() ."users/view"; 
    	}	
		$pagination_detail = $this->pagination->pagination($totalUser, $per_page, $offset, $url);
		$data['paginglinks'] = $pagination_detail['paginationLinks'];
		$data['pagermessage'] = $pagination_detail ['paginationMessage'];
		$data['total']=$totalUser;
		$data['all_users'] = $this->users_content_model->get_all_users($offset,$per_page);
		
		$this -> load -> view('user_view_all_users', $data);

	}


	public function user_edit_user() {
		$access=$this->check_user();
		$this->panels_check_permission($access);

		$this->load->model('users_content_model');
		$user_id = $this->input->get('id');
		$data['result'] = $this-> users_content_model-> get_users_by_id($user_id);

		$success_message=$this->session->flashdata('success_message');
		$error_message=$this->session->flashdata('error_message');
		$user_add_data=$this->session->flashdata('user_add_data');
    	$data['error_message']= $error_message;
		$data['success_message']= $success_message;
		$data['user_add_data']=$user_add_data;
		$this->load->view('user_update_user', $data);
	}

	public function user_add_user(){
		$access=$this->check_user();
		$this->panels_check_permission($access);

		$success_message=$this->session->flashdata('success_message');
		$error_message=$this->session->flashdata('error_message');
		$user_add_data=$this->session->flashdata('user_add_data');
    	$data['error_message']= $error_message;
		$data['success_message']= $success_message;
		$data['user_add_data']=$user_add_data;
		$this->load->view('user_add_user',$data);
	}

	public function user_create_user(){
		$this->load->model('users_content/users_content_model');
		$this -> load -> helper('users_content/user_content');

		$validation=validation();
			if($validation){
				$result = $this->users_content_model->insert_user();
				if($result) {
					$this->session->set_flashdata('success_message','User Added Successfully');
					header("Location:" . $this -> config -> base_url() . "users/view");

				}else{
					$this->session->set_flashdata('error_message', "User has not been added Successfully");
					header("Location:" . $_SERVER['HTTP_REFERER']);
				}
			}else{
				header("Location:" . $_SERVER['HTTP_REFERER']);
			}
	}

	public function user_update_user() {
		$access=$this->check_user();
		$this->panels_check_permission($access);

		$this->load->model('users_content_model');
		$this -> load -> helper('users_content/user_content');

		$validation=update_validation();
			if($validation){
				$result = $this->users_content_model->update_user();
				if($result) {
					$this->session->set_flashdata('success_message','Profile Updated');
					header("Location:" . $this -> config -> base_url() . "users/edit?id=".$this->input->post('user_id'));

				}else{
					$this->session->set_flashdata('error_message', "User has not been Updated Successfully");
					header("Location:" . $_SERVER['HTTP_REFERER']);
				}
			}else{
				header("Location:" . $_SERVER['HTTP_REFERER']);
			}
		}
	
	public function main_admin_view_all_user() {
		$access = $this->check_mainadmin();
		$this->panels_check_permission($access);
		$this->load->model('users_content_model');
		$success_message=$this->session->flashdata('success_message');
		$error_message=$this->session->flashdata('error_message');
		$user_add_data=$this->session->flashdata('user_add_data');
    	$data['error_message']= $error_message;
		$data['success_message']= $success_message;
		$data['user_add_data']=$user_add_data;

		$this->load->library("pagination");
		$offset = ($this->uri->segment(3) != '' ? $this -> uri -> segment(3): 1);
		$per_page = 10;
		
		$totalUser=$this->users_content_model->get_all_users_count();
		if($this->uri->slash_segment(2)=="search/"){
			$url= $this -> config -> base_url() ."users/search"; 
    	}
    	else{
    		$url= $this -> config -> base_url() ."users/view"; 
    	}	
		$pagination_detail = $this->pagination->pagination($totalUser, $per_page, $offset, $url);
		$data['paginglinks'] = $pagination_detail['paginationLinks'];
		$data['pagermessage'] = $pagination_detail ['paginationMessage'];
		$data['total']=$totalUser;
		$data['all_users'] = $this->users_content_model->get_all_users($offset,$per_page);
		
		$this -> load -> view('main_admin_view_all_users', $data);

	}
	
	public function main_admin_edit_user() {
		$access=$this->check_mainadmin();
		$this->panels_check_permission($access);

		$this->load->model('users_content_model');
		$user_id = $this->input->get('id');
		$data['result'] = $this-> users_content_model-> get_users_by_id($user_id);

		$success_message=$this->session->flashdata('success_message');
		$error_message=$this->session->flashdata('error_message');
		$user_add_data=$this->session->flashdata('user_add_data');
    	$data['error_message']= $error_message;
		$data['success_message']= $success_message;
		$data['user_add_data']=$user_add_data;
		$this->load->view('main_admin_update_user', $data);
	}

	public function main_admin_add_user(){
		$access=$this->check_mainadmin();
		$this->panels_check_permission($access);

		$success_message=$this->session->flashdata('success_message');
		$error_message=$this->session->flashdata('error_message');
		$user_add_data=$this->session->flashdata('user_add_data');
    	$data['error_message']= $error_message;
		$data['success_message']= $success_message;
		$data['user_add_data']=$user_add_data;
		$this->load->view('main_admin_add_user',$data);
	}

	public function main_admin_create_user(){
		$this->load->model('users_content/users_content_model');
		$this -> load -> helper('users_content/user_content');

		$validation=validation();
			if($validation){
				$result = $this->users_content_model->main_admin_insert_user();
				if($result) {
					$this->session->set_flashdata('success_message','User Added Successfully');
					header("Location:" . $this -> config -> base_url() . "allusers/view");

				}else{
					$this->session->set_flashdata('error_message', "User has not been added Successfully");
					header("Location:" . $_SERVER['HTTP_REFERER']);
				}
			}else{
				header("Location:" . $_SERVER['HTTP_REFERER']);
			}
	}

	public function main_admin_update_user() {
		$access=$this->check_mainadmin();
		$this->panels_check_permission($access);

		$this->load->model('users_content_model');
		$this -> load -> helper('users_content/user_content');

		$validation=update_validation();
			if($validation){
				$result = $this->users_content_model->update_user();
				if($result) {
					$this->session->set_flashdata('success_message','Profile Updated');
					header("Location:" . $this -> config -> base_url() . "allusers/edit?id=".$this->input->post('user_id'));

				}else{
					$this->session->set_flashdata('error_message', "User has not been Updated Successfully");
					header("Location:" . $_SERVER['HTTP_REFERER']);
				}
			}else{
				header("Location:" . $_SERVER['HTTP_REFERER']);
			}
		}
public function main_admin_delete_user() {
		$access = $this->check_mainadmin();
		$this->panels_check_permission($access);
		$this->load->model('users_content_model');
		$this->users_content_model->delete_user();
		$this->session->set_flashdata('success_message','User Deleted Successfully');
		header("Location:" . $_SERVER['HTTP_REFERER']);
		exit;
		}		

}