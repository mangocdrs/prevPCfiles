<?php if (isset($success_message) && $success_message!=""){ ?>
<script>
	setTimeout(function() {
	     $.bootstrapGrowl('<?php echo $success_message;?>', {
	         type: 'success',
	         align: 'center',
	         width: 'auto',
	         allow_dismiss: false
	     });
	 }, 1);
</script>
<?php } ?>
<?php
	if (isset($error_message) && $error_message!="" ){ 
		if(!isset($user_add_data['error_message'])){
		?>
	
	<script>
	       setTimeout(function() {
	            $.bootstrapGrowl('<?php echo $error_message;?>', {
	                type: 'danger',
	                align: 'center',
	                width: 'auto',
	                allow_dismiss: false
	            });
	        }, 1);
	    </script>
	   <?php
		
		}
		$error_message =  strip_tags($user_add_data['error_message']);
	    $error_message = str_replace(array("\r", "\n"), '', $error_message);
		$error_message= explode('.',$error_message);
	 	for($i=0; $i<count($error_message)-1; $i++){
  			$error = $error_message[$i];
        	if (isset($error)){ ?>
	        	
        		<script>
	       setTimeout(function() {
	            $.bootstrapGrowl("<?php echo $error;?>", {
	                type: 'danger',
	                align: 'center',
	                width: 'auto',
	                allow_dismiss: false
	            });
	        }, 1);
	    </script>
        		
        		
        	<?php }	}
		 } ?>

<!-- <div id="page-wrapper" class="gray-bg"> -->

			<div class="wrapper wrapper-content animated fadeInRight">
        
            <div class="row">
                <div class="col-lg-12">
                    <div class="ibox float-e-margins">
                        <div class="ibox-title">
                            <h5>
                            	<?php if($refresh=='yes'){ ?>
                            	Update Refresh Token
                            	<?php }else{
                            		?>
                            		Create Refresh Token
									<?php
                            	} ?>
                            	</h5>
                        </div>
                        <div class="ibox-content">
                                <a href="<?php echo $loginurl; ?>" class="btn btn-primary" ><?php if($refresh=='yes'){ ?>
                            	Update Refresh Token
                            	<?php }else{
                            		?>
                            		Create Refresh Token
									<?php
                            	} ?></a>
                             	<div class="hr-line-dashed"></div>
                             	
                                <div class="form-group">
                                    <div class="col-sm-7 col-sm-offset-2 pull-right">
                                       
                                     
                                      
                                                                          
                                    </div>
                                </div>
                           
                        </div>
                    </div>
                </div>
            </div>
        </div>


 <script type="text/javascript">

	  $.validator.addMethod("Email", function(value, element) {
	            return this.optional(element) |/^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/.test(value);
	        }, "Invalid Email Address.");
	        
	    $("#create_admin_form").validate({
	        rules: {
		        room_name: { required: true},
                room_unique_name: { required: true},
             	email:{ required:true ,Email:true},
              	capacity: { required:true},
		      	info: { required:true},
		      	support_email: { required:true ,Email:true},
		  },
		  messages: {
		                room_name:{required: "Room Name Required"},
		                room_unique_name:{required: "Room Location Required"},
		                email:{required:"Email Required",
                        		Email:"Email Not Valid"},
                        info:{required:"Info Required"},
		                capacity:{required:"Capacity Required"},
		                support_email: {required:"Email Required",
                        		Email:"Email Not Valid"},
		             },
		            tooltip_options: {
		            }
		});
</script> 


