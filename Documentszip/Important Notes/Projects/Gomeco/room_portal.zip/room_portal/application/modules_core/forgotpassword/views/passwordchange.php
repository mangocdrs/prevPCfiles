<?php echo Modules::run('header/header/frontheader'); ?>

	<?php echo Modules::run('forgotpassword_content/forgotpassword_content/change'); ?>


<?php echo Modules::run('footer/footer/frontfooter'); ?>