<?php echo Modules::run('header/Header/user'); ?>
<?php //echo Modules::run('additional_js/additional_js/investor'); ?>

<body class="pace-done">
<div id="wrapper">
	<?php echo Modules::run('left_sidebar/left_sidebar/main_admin'); ?>
    

        <div id="page-wrapper" class="gray-bg">
        	<?php echo Modules::run('top_menu/top_menu/user'); ?> 
            <?php echo Modules::run('users_content/users_content/main_admin_view_all_user'); ?> 
            <?php echo Modules::run('footer/footer/investor'); ?> 
        </div>
</div>
</body>
</html>