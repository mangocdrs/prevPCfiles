<?php echo Modules::run('header/Header/user'); ?>
<?php //echo Modules::run('additional_js/additional_js/user'); ?>

<body class="pace-done">
<div id="wrapper">
	<?php echo Modules::run('left_sidebar/left_sidebar/user'); ?>
    

        <div id="page-wrapper" class="gray-bg">
        	<?php echo Modules::run('top_menu/top_menu/user'); ?> 
        			<?php echo Modules::run('rooms_content/rooms_content/user_view_all_rooms'); ?>
		     <?php echo Modules::run('footer/footer/user'); ?> 
        </div>
</div>
</body>
</html>