<!DOCTYPE html>
<html>
<?php echo Modules::run('header/Header/homepage'); ?>
<body>
	<div class="wrapper">
			<?php echo Modules::run('rooms_content/rooms_content/roomsschedule'); ?>
			<?php echo Modules::run('footer/footer/homepage'); ?>
		</div>
		<!-- end off all content -->
		 
		
	</div>
</body>
</html>