<?php
if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Services extends MY_Controller {
    public function  __construct(){
	parent::__construct();
        $this->no_cache();
        $this->add_page_title("Services | EWS");
    }
    
  
    public function view(){
    
		$allow_usertypes = array(1 => 'user');
    	$user_type=$this->check_usertype_modules_core($allow_usertypes);
		$this->load->view($user_type.'_view_services');

   	} //end of the function index to show the login page for the admin  module 
   	

   	 
}
