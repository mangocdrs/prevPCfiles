<?php
if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Cronjobs extends MY_Controller {
    public function  __construct(){
	parent::__construct();
        $this->no_cache();
        $this->add_page_title("Rooms | EWS");
    }
    
    public function import_today_schedule(){
    	
		$this->load->view('import_today_schedule');
	}
    
  
}
