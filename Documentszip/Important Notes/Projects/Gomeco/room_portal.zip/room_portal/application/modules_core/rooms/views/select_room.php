<!DOCTYPE html>
<html>
<?php echo Modules::run('header/Header/homepage'); ?>
<body>
	<div class="wrapper">
		<div class="main-content">
			<?php echo Modules::run('rooms_content/rooms_content/select_room'); ?>
			<?php //echo Modules::run('footer/footer/homepage'); ?> 
		</div>
	</div>
</body>
</html>