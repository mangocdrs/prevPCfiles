<?php
if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Allusers extends MY_Controller {
    public function  __construct(){
	parent::__construct();

		}

	 public function view(){
      $allow_usertypes = array(1 => 'main_admin');
      $user_type=$this->check_usertype_modules_core($allow_usertypes);
      $this->load->view($user_type.'_view_all_users');
   	} //end of the function index to show the login page for the admin  module 

    public function add(){
      $allow_usertypes = array(1 => 'main_admin');
      $user_type=$this->check_usertype_modules_core($allow_usertypes);
    	$this->load->view($user_type.'_add_user');
    }//end of module core function view to view the record on the dashbord 


    public function edit(){

      $allow_usertypes = array(1 => 'main_admin');
      $user_type=$this->check_usertype_modules_core($allow_usertypes);
      $this->load->view($user_type.'_edit_user');
   	} //end of the function index to show the login page for the admin  module 

    public function search(){
	    $allowed_user_types=array(
	      1=>'main_admin'
	    );
	    $user_types=$this->check_usertype_modules_core($allowed_user_types);
	    $this->load->view($user_types.'_view_all_users');
    }//end of module core function view to view the record on the dashbord 
	
	
}
