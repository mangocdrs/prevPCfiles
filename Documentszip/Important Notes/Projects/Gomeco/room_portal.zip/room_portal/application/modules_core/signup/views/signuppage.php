<?php echo Modules::run('header/header/frontheader'); ?>

	<?php echo Modules::run('signup_content/signup_content/index'); ?>


<?php echo Modules::run('footer/footer/frontfooter'); ?>