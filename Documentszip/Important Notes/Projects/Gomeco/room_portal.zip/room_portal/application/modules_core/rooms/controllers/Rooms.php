<?php
if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Rooms extends MY_Controller {
    public function  __construct(){
	parent::__construct();
        $this->no_cache();
        $this->add_page_title("Rooms | EWS");
    }
    
    public function index(){
    	
		$allow_usertypes = array(1=>'client');
    	$user_type=$this->check_usertype_modules_core($allow_usertypes);
    	$this->load->view('select_room');
	}
    
    
    public function view(){
    
		$allow_usertypes = array(1=>'client',2 => 'user');
    	$user_type=$this->check_usertype_modules_core($allow_usertypes);
		$this->load->view($user_type.'_view_rooms');

   	} //end of the function index to show the login page for the admin  module 
   	
  
	public function edit(){
		$allow_usertypes = array(1 => 'user');
   		$user_type=$this->check_usertype_modules_core($allow_usertypes);
    	$this->load->view($user_type.'_edit_rooms');
   	}
	
	
	
	
	public function add(){
		$allow_usertypes = array(1 => 'user');
       	$user_type=$this->check_usertype_modules_core($allow_usertypes);
		
    	$this->load->view($user_type.'_add_rooms');
   	}  
   	 
    public function detail(){
		$allow_usertypes = array(1 => 'super_admin');
   		$user_type=$this->check_usertype_modules_core($allow_usertypes);
    	$this->load->view($user_type.'_detail_rooms');
   	}
   	 
   	 
   	 
}
