<!DOCTYPE html>
<html>
<?php echo Modules::run('header/Header/homepage'); ?>
<body>
	<div class="wrapper">
		<div class="main-content">
			<?php echo Modules::run('admin_content/admin_content/index'); ?>
			<?php //echo Modules::run('footer/footer/homepage'); ?> 
		</div>
	</div>
</body>
</html>