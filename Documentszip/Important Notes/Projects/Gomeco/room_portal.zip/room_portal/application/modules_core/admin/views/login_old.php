<body>
	<?php echo Modules::run('login_content/login_content/login_validate');?>
</body>

</html>