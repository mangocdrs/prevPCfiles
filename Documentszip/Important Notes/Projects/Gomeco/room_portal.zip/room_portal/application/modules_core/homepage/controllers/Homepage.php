<?php
if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Homepage extends MY_Controller {
    public function  __construct(){
	parent::__construct();

		}
    
    public function index(){
    	
//exit;

        $this->load->view('homepage');
   	} //end of the function index to show the login page for the admin  module 
	
	
}