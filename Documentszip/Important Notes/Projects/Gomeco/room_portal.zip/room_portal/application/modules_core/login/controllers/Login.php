<?php
if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Login extends MY_Controller {
    public function  __construct(){
	parent::__construct();

		}
    
    public function index(){
    	
//exit;

        $this->load->view('loginpage');
   	} //end of the function index to show the login page for the admin  module 
	
	
}