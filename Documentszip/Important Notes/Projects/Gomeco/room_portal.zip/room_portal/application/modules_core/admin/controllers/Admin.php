<?php
if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Admin extends MY_Controller {
    public function  __construct(){
	parent::__construct();
        $this->no_cache();
        $this->add_page_title("Login | ecommerce");
    }
	
	public function index(){
		$this->load->view('login');
		
	}
	
       	 
}
