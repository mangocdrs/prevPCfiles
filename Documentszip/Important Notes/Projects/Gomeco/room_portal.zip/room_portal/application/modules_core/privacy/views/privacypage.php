<?php echo Modules::run('header/header/frontheader'); ?>

	<?php echo Modules::run('privacy_content/privacy_content/index'); ?>


<?php echo Modules::run('footer/footer/frontfooter'); ?>