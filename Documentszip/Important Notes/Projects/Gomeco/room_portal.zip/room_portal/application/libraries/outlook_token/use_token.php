<?php
//old
//define('CLIEND_ID', 'c2061632-fce2-498c-afe0-4e0bdbb3e077');
//define('CLIEND_SECRET', 'jsgaunLM07[)$nXPHZJ850]');
require('outlook.php');
//new gapp
define('CLIEND_ID', '4d235ed6-c0da-4cd2-a134-3ee9c9edf65a');
define('CLIEND_SECRET', 'bescXHRB22!:sklFBX214};');

 		$servername = "localhost";
		$username = "root";
		$password = "53cr3t";
		$dbname = "outlook";
		
		

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 

$sql = "SELECT * from refresh_tokens  WHERE id=(
    SELECT max(id) FROM refresh_tokens
    )";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
       $refresh_token=$row["refresh_token"];
    }
} else {
    echo "0 results";
}
$conn->close();
// echo $refresh_token;
//exit;
 //$code = $_GET["code"];

    $curl = curl_init();

    curl_setopt_array($curl, array(
        CURLOPT_URL => "https://login.microsoftonline.com/common/oauth2/v2.0/token",
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_ENCODING => "",
        CURLOPT_MAXREDIRS => 10,
        CURLOPT_TIMEOUT => 30,
        CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
        CURLOPT_CUSTOMREQUEST => "POST",
        CURLOPT_HTTPHEADER => array(
            "Content-type"=>"application/x-www-form-urlencoded",
            "Content-Length"=>144
        ),
        CURLOPT_POSTFIELDS => array(
            "grant_type" => "refresh_token",
            "client_id" => CLIEND_ID,
            "client_secret" => CLIEND_SECRET,
            "refresh_token" => $refresh_token,
            "scope" => 'openid profile offline_access User.Read Mail.Read User.Read.All User.ReadBasic.All Calendars.Read Calendars.Read.Shared',
            "redirect_uri" => "http://localhost/outlook-login/authorize.php"),
    ));

    $response = curl_exec($curl);
	//print_r($response);
    $err = curl_error($curl);

    curl_close($curl);

    if ($err) {
        echo "cURL Error #:" . $err;
    } else {
        $response_arr= json_decode($response);
		$token=$response_arr->access_token;
		
		$messages = OutlookService::getMessages($token);
		
		var_dump($messages);
		
		exit;
	    // $url='https://outlook.office.com/api/v2.0/me/messages';
		// $ch = curl_init();
		// curl_setopt($ch, CURLOPT_URL, $url);
		// curl_setopt($ch, CURLOPT_CUSTOMREQUEST, 'GET');
		// curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
		// curl_setopt($ch, CURLOPT_ENCODING, "gzip");
		// curl_setopt($ch, CURLOPT_HTTPHEADER, [
		// 'Authorization: Bearer '.$token
		// ]);	
		// $resp = curl_exec($ch);
		// echo "innnnn";
		//	print_r($token);
//exit;
		// $resp = json_decode($token);
		// Create a stream
// $opts = [
    // "https" => [
        // "method" => "GET",
         // "Authorization"=> "Bearer $token"
    // ]
// ];
// 
// $context = stream_context_create($opts);
// 
// // Open the file using the HTTP headers set above
// $filename = file_get_contents('https://outlook.office.com/api/v2.0/me', false, $context);
// 		
		// //$result=file_get_contents($filename);
// 		
		// print_r($filename);
		// exit;
		curl_close($ch);
	    $ch = curl_init();
        curl_setopt_array($ch, array(
        CURLOPT_URL => 'https://outlook.office.com/api/v2.0/me/messages',
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_ENCODING => "",
        CURLOPT_MAXREDIRS => 10,
        CURLOPT_TIMEOUT => 30,
        CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
        CURLOPT_CUSTOMREQUEST => "GET",
        CURLOPT_HTTPHEADER => array(
            // "Prefer: outlook.body-content-type"=>"text",
            // "Content-Length"=>"0",
            "Authorization"=> "Bearer $token"
			
			
	       
			),
         // CURLOPT_POSTFIELDS => array(),
           //  "grant_type" => "refresh_token",
           // "client_id" => CLIEND_ID,
          //   "client_secret" => CLIEND_SECRET,
          //   "refresh_token" => $refresh_token,
           //  "redirect_uri" => "http://localhost/outlook-login/authorize.php"),
     ));

    $responsed = curl_exec($ch);
	print_r($responsed);
    $errd = curl_error($ch);

    curl_close($ch);

    if ($errd) {
        echo "cURL Error #:" . $errd;
    } else {
        var_dump($responsed);
		
		//print_r($response_arr);
		//exit;
		 
		
	   // print_r($response_arr->id_token);
		
	  
	}
		
	
		
	   // print_r($response_arr->id_token);
		
	  
	}

?>