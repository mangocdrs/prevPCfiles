<?php 

include "init.php";

$ec = new ExchangeClient();
$ec->init("user1@qibla.org", "P@ssw0rd");

$start_date = new DateTime('2018-02-19 12:00 AM');
$end_date = new DateTime('2018-02-19 11:30 PM');


// $data = $ec->create_event("Hashar test",$start_date->format('c'),$end_date->format('c'),"Room1");
$data = $ec->get_events($start_date->format('c'),$end_date->format('c'));
echo "<pre>";
print_r($data);
exit;

echo "here";
exit;




?>
