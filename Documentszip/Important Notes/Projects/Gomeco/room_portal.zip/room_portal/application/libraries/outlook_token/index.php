<?php
require_once 'vendor/autoload.php';

//old
//define('CLIEND_ID', 'c2061632-fce2-498c-afe0-4e0bdbb3e077');
//define('CLIEND_SECRET', 'jsgaunLM07[)$nXPHZJ850]');

//new gapp
define('CLIEND_ID', '4d235ed6-c0da-4cd2-a134-3ee9c9edf65a');
define('CLIEND_SECRET', 'bescXHRB22!:sklFBX214};');





$authenticator = new Outlook\Authorizer\Authenticator(CLIEND_ID, CLIEND_SECRET, $redirectUri = "http://localhost/outlook-login/authorize.php");

$token = $authenticator->getToken();

if (!$token) {
    $loginurl= $authenticator->getLoginUrl();
	echo '<a href="'.$loginurl.'">Login url </a>';
	//header('location:'.$loginurl);
} else {
    var_dump($token);
}

?>