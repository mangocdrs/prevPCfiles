<?php

define('EXCHANGE_ROOT', realpath(dirname(__FILE__)));

include EXCHANGE_ROOT . "/lib/NTLMStream.php";
include EXCHANGE_ROOT . "/lib/NTLMSoapClient.php";
include EXCHANGE_ROOT . "/lib/ExchangeClient.php";
include EXCHANGE_ROOT . "/lib/ExchangeNTLMStream.php";

