<?php
//old
//define('CLIEND_ID', 'c2061632-fce2-498c-afe0-4e0bdbb3e077');
//define('CLIEND_SECRET', 'jsgaunLM07[)$nXPHZJ850]');

//new gapp
define('CLIEND_ID', '4d235ed6-c0da-4cd2-a134-3ee9c9edf65a');
define('CLIEND_SECRET', 'bescXHRB22!:sklFBX214};');

 $code = $_GET["code"];

    $curl = curl_init();

    curl_setopt_array($curl, array(
        CURLOPT_URL => "https://login.microsoftonline.com/common/oauth2/v2.0/token",
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_ENCODING => "",
        CURLOPT_MAXREDIRS => 10,
        CURLOPT_TIMEOUT => 30,
        CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
        CURLOPT_CUSTOMREQUEST => "POST",
        CURLOPT_HTTPHEADER => array(
            "Content-type"=>"application/x-www-form-urlencoded",
            "Content-Length"=>144
        ),
        CURLOPT_POSTFIELDS => array(
            "grant_type" => "authorization_code",
            "client_id" => CLIEND_ID,
            "client_secret" => CLIEND_SECRET,
            "code" => $code,
           
            "redirect_uri" => "http://localhost/outlook-login/authorize.php"),
    ));

    $response = curl_exec($curl);
    $err = curl_error($curl);

    curl_close($curl);

    if ($err) {
        echo "cURL Error #:" . $err;
    } else {
        $response_arr= json_decode($response);
     
	    $refresh_token=$response_arr->refresh_token;
		
	    $servername = "localhost";
		$username = "root";
		$password = "53cr3t";
		$dbname = "outlook";
		
		// Create connection
		$conn = new mysqli($servername, $username, $password, $dbname);
		// Check connection
		if ($conn->connect_error) {
		    die("Connection failed: " . $conn->connect_error);
		} 
		
		$sql = "INSERT INTO refresh_tokens (refresh_token)
		VALUES ('$refresh_token')";
		
		if ($conn->query($sql) === TRUE) {
		    echo "Refresh Token Added";
			echo "<a href='use_token.php'>Use Token</a>";
		} else {
		    echo "Error: " . $sql . "<br>" . $conn->error;
		}
		
		$conn->close();
	}

?>