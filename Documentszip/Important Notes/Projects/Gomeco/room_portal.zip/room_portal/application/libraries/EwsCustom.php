<?php 


define('EXCHANGE_ROOT', realpath(dirname(__FILE__)));

include EXCHANGE_ROOT . "/ews/lib/NTLMStream.php";
include EXCHANGE_ROOT . "/ews/lib/NTLMSoapClient.php";
include EXCHANGE_ROOT . "/ews/lib/ExchangeClient.php";
include EXCHANGE_ROOT . "/ews/lib/ExchangeNTLMStream.php";	
class EwsCustom {
	
	// private $username = "user1@qibla.org";
	// private $password = "P@ssw0rd";
	
	public function get_event($delegate,$username,$password,$start_date,$end_date){
		$ec = new ExchangeClient();
		$ec->init($username, $password,$delegate);
		
		$start_date = new DateTime($start_date);
		$end_date = new DateTime($end_date);

		// $data = $ec->create_event("Hashar test",$start_date->format('c'),$end_date->format('c'),"Room1");
		$data = $ec->get_events($start_date->format('c'),$end_date->format('c'));
		// echo "<pre>";
		// print_r($data);
		// exit;
		
		return $data;
	}
	
	
	public function create_event($delegate,$username,$password,$subject,$start_date,$end_date,$room){
		
		$ec = new ExchangeClient();
		$ec->init($username, $password,$delegate);
		
		$start_date = new DateTime($start_date);
		$end_date = new DateTime($end_date);
		
		return $ec->create_event($subject,$start_date->format('c'),$end_date->format('c'),$room);	
	}

	public function cancel_event($delegate,$username,$password,$meeting_id,$changekey){
				
		$ec = new ExchangeClient();
		$ec->init($username, $password,$delegate);
		
		$ec->cancel_event($meeting_id,$changekey);
		return TRUE;	
	}
	
	public function update_event($delegate,$username,$password,$meeting_id,$changekey,$update_list){
		ini_set("soap.wsdl_cache_enabled", 0);		
		$ec = new ExchangeClient();
		$ec->init($username, $password,$delegate);
		$ec->update_event($meeting_id,$changekey,$update_list);
		return TRUE;	
	}
	
}
?>