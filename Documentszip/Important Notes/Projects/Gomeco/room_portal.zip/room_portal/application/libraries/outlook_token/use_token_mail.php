<?php
define('CLIEND_ID', 'c2061632-fce2-498c-afe0-4e0bdbb3e077');
define('CLIEND_SECRET', 'jsgaunLM07[)$nXPHZJ850]');


 		$servername = "localhost";
		$username = "root";
		$password = "53cr3t";
		$dbname = "outlook";
		
		

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 

$sql = "SELECT * from refresh_tokens ";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
       $refresh_token=$row["refresh_token"];
    }
} else {
    echo "0 results";
}
$conn->close();
//exit;
 //$code = $_GET["code"];

    $curl = curl_init();

    curl_setopt_array($curl, array(
        CURLOPT_URL => "https://outlook.office.com/api/v2.0/me/MailFolders/Inbox/messages",
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_ENCODING => "",
        CURLOPT_MAXREDIRS => 10,
        CURLOPT_TIMEOUT => 30,
        CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
        CURLOPT_CUSTOMREQUEST => "POST",
        CURLOPT_HTTPHEADER => array(
            "Content-type"=>"application/x-www-form-urlencoded",
            "Content-Length"=>144,
            "Authorization"=> "Bearer eyJ0eXAiOiJKV1QiLCJhbGciOiJSUzI1NiIsImtpZCI6IjFMVE16YWtpaGlSbGFfOHoyQkVKVlhlV01xbyJ9.eyJ2ZXIiOiIyLjAiLCJpc3MiOiJodHRwczovL2xvZ2luLm1pY3Jvc29mdG9ubGluZS5jb20vOTE4ODA0MGQtNmM2Ny00YzViLWIxMTItMzZhMzA0YjY2ZGFkL3YyLjAiLCJzdWIiOiJBQUFBQUFBQUFBQUFBQUFBQUFBQUFGUEo3NkZpa0lfdExYQnN2dkNnSmxFIiwiYXVkIjoiYzIwNjE2MzItZmNlMi00OThjLWFmZTAtNGUwYmRiYjNlMDc3IiwiZXhwIjoxNTM5MDgzMjEyLCJpYXQiOjE1Mzg5OTY1MTIsIm5iZiI6MTUzODk5NjUxMiwidGlkIjoiOTE4ODA0MGQtNmM2Ny00YzViLWIxMTItMzZhMzA0YjY2ZGFkIiwiYWlvIjoiRGZMQmhxRzRNdmJIUCFSMFgzV3BrWmRNY1NONUZxVlZPT2Z2NjhzS3UwRGRid3VKTzh4bSpBOTdzOU42aFdaSzloS2ZDYzhKU3ZOOFVMWUp4RU1YeW8haGdhamV5a00qUGEqOEZHNU5RMkl4S3NpaXRpTlN3cFNwYURRY1oyKmlRNTU4TE5MQXF6WWhxT2Z0V0xLbjgzbyQifQ.MWO9D3OYWCDOyFLT4UzoVCqXju-TovYBUdLx2QnOUGUfuB1O5Jflw1cq_SWXmumSudU5ynKiyzNC6m5VQmdhBq4KITAJJyVKn3345nPyg5Z8aV1tN3sGXZBUbakywBueF5HQ3cGkdvysKM1NCdSrQzxeFwJMp5Y5co0mkVspTNpckbEs4cdxYZA7uv_4_XsavV09r6BuqXcKNqy7u8eB9iTxoB_hjTNDRKEl4Fsy6bWmIO9-mpYJ7S872jUMxN_qUk2eeQTdIpBYgS75x9vSqsGzw6IANhm_lZbauj8ClbU7OMLNDCG_W_MUCXRt7RMsc8EvtvK03Q4qXuqkknkn2Q"),
         
         //CURLOPT_POSTFIELDS => array(
           //  "grant_type" => "refresh_token",
           // "client_id" => CLIEND_ID,
          //   "client_secret" => CLIEND_SECRET,
          //   "refresh_token" => $refresh_token,
           //  "redirect_uri" => "http://localhost/outlook-login/authorize.php"),
     ));

    $response = curl_exec($curl);
    $err = curl_error($curl);

    curl_close($curl);

    if ($err) {
        echo "cURL Error #:" . $err;
    } else {
        var_dump($response);
		
		//print_r($response_arr);
		//exit;
		 
		
	   // print_r($response_arr->id_token);
		
	  
	}

?>